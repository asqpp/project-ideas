<?php
/**
 * Lightweight smoke tests for the key controllers.
 * Run with: php tests/smoke/run_feature_tests.php
 */

$endpoints = [
    'insurance/policy_management',
    'hr/employee_management',
    'accounting/bank_reconciliation',
    'clients/index/customer',
    'clients/index/supplier',
    'clients/index/staff',
    'clients/index/agent',
    'clients/index/broker',
    'reports/balance_sheet',
    'reports/quotation_book',
    'reports/sales_summary',
    'reports/premium_analysis',
    'reports/customer_ageing',
    'reports/outstanding_report'
];

$phpBinary = PHP_BINARY;
$exitCode = 0;

foreach ($endpoints as $endpoint) {
    $command = sprintf('%s index.php %s', escapeshellcmd($phpBinary), escapeshellarg($endpoint));
    echo "Running {$command}\n";
    exec($command, $output, $status);

    if ($status !== 0) {
        echo "❌ Endpoint {$endpoint} failed with status {$status}\n";
        $exitCode = 1;
    } else {
        echo "✅ {$endpoint} rendered successfully\n";
    }
}

exit($exitCode);
