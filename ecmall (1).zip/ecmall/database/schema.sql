-- =====================================================
-- Insurance Management System v2.0 - Database Schema
-- Database: cybor432_erpnew
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

-- =====================================================
-- 0. AUTHENTICATION & AUDIT TABLES
-- =====================================================
CREATE TABLE IF NOT EXISTS `roles` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) NOT NULL,
  `description` text DEFAULT NULL,
  `permissions` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code` varchar(191) NOT NULL,
  `username` varchar(191) NOT NULL,
  `email` varchar(191) DEFAULT NULL,
  `password` varchar(191) NOT NULL,
  `first_name` varchar(191) DEFAULT NULL,
  `last_name` varchar(191) DEFAULT NULL,
  `role_id` int(10) UNSIGNED DEFAULT NULL,
  `branch_id` int(10) UNSIGNED DEFAULT NULL,
  `usertype` varchar(191) DEFAULT 'USER',
  `phone` varchar(191) DEFAULT NULL,
  `avatar_url` text DEFAULT NULL,
  `status` varchar(191) DEFAULT 'active',
  `last_login` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `users_role_id_foreign` (`role_id`),
  CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `audit_logs_user_id_foreign` (`user_id`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed essential roles (idempotent)
INSERT INTO `roles` (`id`, `name`, `description`, `permissions`)
VALUES
  (1, 'Admin', 'System Administrator', '{"all": true}'),
  (2, 'Manager', 'Branch Manager', '{"manage_users": true, "view_reports": true}'),
  (3, 'Accountant', 'Accountant', '{"manage_accounts": true, "view_reports": true}'),
  (4, 'User', 'Regular User', '{"view_own_data": true}')
ON DUPLICATE KEY UPDATE
  `description` = VALUES(`description`),
  `permissions` = VALUES(`permissions`);

-- Seed default admin user (password: admin123)
INSERT INTO `users` (`code`, `username`, `email`, `password`, `first_name`, `last_name`, `role_id`, `usertype`, `status`)
VALUES
  ('USR-2025-0001', 'admin', 'admin@example.com', '$2y$10$hIB4Etgi98K5TemqY5i/AuQ2QruojMpbqMyPsUDr9ePs0Fu9Dzq7K', 'Admin', 'User', 1, 'ADMIN', 'active')
ON DUPLICATE KEY UPDATE
  `email` = VALUES(`email`),
  `password` = VALUES(`password`),
  `role_id` = VALUES(`role_id`),
  `status` = VALUES(`status`);

-- =====================================================
-- 1. ACCOUNTS TABLE (Chart of Accounts)
-- =====================================================
CREATE TABLE IF NOT EXISTS `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_code` varchar(50) NOT NULL,
  `account_name` varchar(255) NOT NULL,
  `account_type` enum('asset','liability','equity','income','expense') NOT NULL,
  `description` text,
  `is_system` tinyint(1) DEFAULT 0,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_code` (`account_code`),
  KEY `account_type` (`account_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 2. AGENT TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `agent` (
  `agent_id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_code` varchar(50) DEFAULT NULL,
  `agent_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `address` text,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `salesman_code` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`agent_id`),
  UNIQUE KEY `agent_code` (`agent_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 3. AGENT_COMMISSION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `agent_commission` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `commission_amount` decimal(15,2) NOT NULL,
  `commission_rate` decimal(5,2) NOT NULL,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `payment_status` enum('unpaid','partial','paid') DEFAULT 'unpaid',
  `last_payment_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_notes` text,
  PRIMARY KEY (`commission_id`),
  KEY `agent_id` (`agent_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 4. BROKER TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `broker` (
  `broker_id` int(11) NOT NULL AUTO_INCREMENT,
  `broker_code` varchar(50) DEFAULT NULL,
  `broker_name` varchar(255) NOT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `mobile` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `address` text,
  `commission_rate` decimal(5,2) DEFAULT 0.00,
  `salesman_code` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`broker_id`),
  UNIQUE KEY `broker_code` (`broker_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 5. BROKER_COMMISSION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `broker_commission` (
  `commission_id` int(11) NOT NULL AUTO_INCREMENT,
  `broker_id` int(11) NOT NULL,
  `invoice_id` int(11) NOT NULL,
  `commission_amount` decimal(15,2) NOT NULL,
  `commission_rate` decimal(5,2) NOT NULL,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `payment_status` enum('unpaid','partial','paid') DEFAULT 'unpaid',
  `last_payment_date` date DEFAULT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_notes` text,
  PRIMARY KEY (`commission_id`),
  KEY `broker_id` (`broker_id`),
  KEY `invoice_id` (`invoice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 6. CATEGORY_LIST TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `category_list` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_code` varchar(50) DEFAULT NULL,
  `category_name` varchar(255) NOT NULL,
  `description` text,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`category_id`),
  UNIQUE KEY `uniq_category_code` (`category_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. COLLECTION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `product_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_code` varchar(50) NOT NULL,
  `group_name` varchar(255) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description` text,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_group_code` (`group_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `product_subgroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subgroup_code` varchar(50) NOT NULL,
  `subgroup_name` varchar(255) NOT NULL,
  `group_id` int(11) DEFAULT NULL,
  `description` text,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_subgroup_code` (`subgroup_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 7. COLLECTION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `collection` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `collection_date` date NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `discount_amount` decimal(15,2) DEFAULT 0.00,
  `received_amount` decimal(15,2) NOT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `details` text,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 8. CONTRA TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `contra` (
  `contra_id` int(11) NOT NULL AUTO_INCREMENT,
  `contra_date` date NOT NULL,
  `from_account` varchar(50) NOT NULL,
  `to_account` varchar(50) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `narration` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`contra_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9. CUSTOMER_INFORMATION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `customer_information` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(255) NOT NULL,
  `customer_mobile` varchar(20) NOT NULL,
  `customer_email` varchar(100) DEFAULT NULL,
  `customer_address_1` text,
  `customer_address_2` text,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(15,2) DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `salesman_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  KEY `customer_mobile` (`customer_mobile`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9b. CLIENTS TABLE (Unified Master Snapshot)
-- =====================================================
CREATE TABLE IF NOT EXISTS `clients` (
  `code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `ctype` enum('C','S','F','A') NOT NULL DEFAULT 'C',
  `grp` varchar(50) DEFAULT NULL,
  `account_group` varchar(50) DEFAULT NULL,
  `bshead` varchar(50) DEFAULT NULL,
  `addr1` varchar(255) DEFAULT NULL,
  `addr2` varchar(255) DEFAULT NULL,
  `addr3` varchar(255) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `pin` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `route` varchar(50) DEFAULT NULL,
  `carea` varchar(50) DEFAULT NULL,
  `distance` decimal(10,2) DEFAULT NULL,
  `telephone` varchar(50) DEFAULT NULL,
  `mobile` varchar(50) DEFAULT NULL,
  `homemobile` varchar(50) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `tin` varchar(30) DEFAULT NULL,
  `cst` varchar(30) DEFAULT NULL,
  `panadhar` varchar(50) DEFAULT NULL,
  `religion` varchar(50) DEFAULT NULL,
  `notes` text,
  `smcode` varchar(50) DEFAULT NULL,
  `cocode` varchar(50) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `care_of_name` varchar(255) DEFAULT NULL,
  `care_of_party` enum('Y','N') DEFAULT 'N',
  `pcard` varchar(50) DEFAULT NULL,
  `pcardno` varchar(50) DEFAULT NULL,
  `oppcardpoints` decimal(10,2) DEFAULT NULL,
  `salary` decimal(18,2) DEFAULT NULL,
  `cutrate` decimal(10,2) DEFAULT NULL,
  `commission_pct` decimal(10,2) DEFAULT NULL,
  `colncomn` decimal(10,2) DEFAULT NULL,
  `staff_commission` decimal(10,2) DEFAULT NULL,
  `id_number` varchar(100) DEFAULT NULL,
  `pospwd` varchar(100) DEFAULT NULL,
  `approval` varchar(100) DEFAULT NULL,
  `agent` enum('Y','N') DEFAULT 'N',
  `agentcode` varchar(50) DEFAULT NULL,
  `contract_date` date DEFAULT NULL,
  `adate` date DEFAULT NULL,
  `duedate` date DEFAULT NULL,
  `opbalance` decimal(18,2) DEFAULT 0.00,
  `opbalanceb` decimal(18,2) DEFAULT 0.00,
  `balance_type` enum('dr','cr') DEFAULT 'cr',
  `secondary_balance_type` enum('dr','cr') DEFAULT 'cr',
  `control` tinyint DEFAULT 1,
  `removed` enum('Y','N') DEFAULT 'N',
  `blocked` enum('Y','N') DEFAULT 'N',
  `display` enum('Y','N') DEFAULT 'Y',
  `link_phonebook` enum('Y','N') DEFAULT 'N',
  `print_card` enum('Y','N') DEFAULT 'N',
  `show_camera` enum('Y','N') DEFAULT 'N',
  `update_foreign` enum('Y','N') DEFAULT 'N',
  `agent_staff` enum('Y','N') DEFAULT 'N',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`code`),
  UNIQUE KEY `uniq_clients_agentcode` (`agentcode`),
  KEY `idx_clients_mobile` (`mobile`),
  KEY `idx_clients_id_number` (`id_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 9c. HR EMPLOYEES TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `hr_employees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `employee_code` varchar(50) NOT NULL,
  `full_name` varchar(191) NOT NULL,
  `department` varchar(100) DEFAULT NULL,
  `designation` varchar(100) DEFAULT NULL,
  `joining_date` date DEFAULT NULL,
  `work_email` varchar(191) DEFAULT NULL,
  `mobile` varchar(20) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Active',
  `notes` text,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_hr_employee_code` (`employee_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 10. DAYBOOK TABLE (Journal Entries)
-- =====================================================
CREATE TABLE IF NOT EXISTS `daybook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `account_code` varchar(50) NOT NULL,
  `debit` decimal(15,2) DEFAULT 0.00,
  `credit` decimal(15,2) DEFAULT 0.00,
  `narration` text,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `account_code` (`account_code`),
  KEY `reference` (`reference_type`,`reference_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 11. INVOICE TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `invoice` (
  `invoice_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` varchar(100) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `vat` decimal(15,2) DEFAULT 0.00,
  `grand_total` decimal(15,2) NOT NULL,
  `total_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `paid_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `due_amount` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_status` enum('unpaid','partial','paid') DEFAULT 'unpaid',
  `broker_id` int(11) DEFAULT NULL,
  `agent_id` int(11) DEFAULT NULL,
  `sales_by` int(11) DEFAULT NULL,
  `sales_date` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`invoice_id`),
  UNIQUE KEY `invoice` (`invoice`),
  KEY `customer_id` (`customer_id`),
  KEY `date` (`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 12. INVOICE_DETAILS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `invoice_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `total_price` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 13. JOURNAL TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `journal` (
  `journal_id` int(11) NOT NULL AUTO_INCREMENT,
  `journal_date` date NOT NULL,
  `narration` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`journal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 14. OPENING_BALANCE TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `opening_balance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_code` varchar(50) NOT NULL,
  `opening_balance` decimal(15,2) NOT NULL,
  `opening_date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `account_code` (`account_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 15. PDC TABLE (Post-Dated Cheques)
-- =====================================================
CREATE TABLE IF NOT EXISTS `pdc` (
  `pdc_id` int(11) NOT NULL AUTO_INCREMENT,
  `cheque_no` varchar(100) NOT NULL,
  `cheque_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `cheque_type` enum('received','issued') NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) DEFAULT NULL,
  `status` enum('pending','cleared','bounced','cancelled') DEFAULT 'pending',
  `cleared_date` date DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`pdc_id`),
  KEY `cheque_date` (`cheque_date`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 16. PRODUCT_INFORMATION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `product_information` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `product_model` varchar(100) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `group_id` int(11) DEFAULT NULL,
  `subgroup_id` int(11) DEFAULT NULL,
  `unit_id` int(11) DEFAULT NULL,
  `default_qty` decimal(10,2) DEFAULT 1.00,
  `price` decimal(15,2) NOT NULL,
  `supplier_price` decimal(15,2) DEFAULT 0.00,
  `quantity` decimal(10,2) DEFAULT 0.00,
  `min_stock` decimal(10,2) DEFAULT 0.00,
  `tax_percent` decimal(5,2) DEFAULT 0.00,
  `taxable` tinyint(1) DEFAULT 1,
  `no_discount` tinyint(1) DEFAULT 0,
  `product_details` text,
  `image` varchar(255) DEFAULT NULL,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `uniq_product_code` (`product_code`),
  KEY `category_id` (`category_id`),
  KEY `group_id` (`group_id`),
  KEY `subgroup_id` (`subgroup_id`),
  KEY `unit_id` (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 17. PRODUCT_PURCHASE TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `product_purchase` (
  `purchase_id` int(11) NOT NULL AUTO_INCREMENT,
  `chalan_no` varchar(100) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `line_discount_total` decimal(15,2) DEFAULT 0.00,
  `purchase_discount` decimal(15,2) DEFAULT 0.00,
  `total_discount` decimal(15,2) DEFAULT 0.00,
  `vat` decimal(15,2) DEFAULT 0.00,
  `grand_total_amount` decimal(15,2) NOT NULL,
  `paid_amount` decimal(15,2) DEFAULT 0.00,
  `due_amount` decimal(15,2) DEFAULT 0.00,
  `payment_type` varchar(50) DEFAULT NULL,
  `payment_summary` text,
  `details` text,
  `payment_status` enum('unpaid','partial','paid') DEFAULT 'unpaid',
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`purchase_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `purchase_date` (`purchase_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 18. PRODUCT_PURCHASE_DETAILS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `product_purchase_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` decimal(10,2) NOT NULL,
  `rate` decimal(15,2) NOT NULL,
  `discount_pct` decimal(6,3) DEFAULT 0.000,
  `discount_value` decimal(15,2) DEFAULT 0.00,
  `vat_pct` decimal(6,3) DEFAULT 0.000,
  `vat_value` decimal(15,2) DEFAULT 0.00,
  `batch_no` varchar(50) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `total_amount` decimal(15,2) NOT NULL,
  `line_total` decimal(15,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 19. QUOTATION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `quotation` (
  `quotation_id` int(11) NOT NULL AUTO_INCREMENT,
  `quotation_no` varchar(100) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `quotation_date` date NOT NULL,
  `valid_until` date DEFAULT NULL,
  `subtotal` decimal(15,2) NOT NULL,
  `vat` decimal(15,2) DEFAULT 0.00,
  `grand_total` decimal(15,2) NOT NULL,
  `items` text,
  `notes` text,
  `status` enum('pending','converted','rejected') DEFAULT 'pending',
  `converted_invoice_id` int(11) DEFAULT NULL,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`quotation_id`),
  UNIQUE KEY `quotation_no` (`quotation_no`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 20. RECEIPT TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `receipt` (
  `receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `customer_id` int(11) NOT NULL,
  `receipt_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_method` enum('cash','bank','cheque','pdc') DEFAULT 'cash',
  `cheque_no` varchar(100) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `discount` decimal(15,2) DEFAULT 0.00,
  `notes` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`receipt_id`),
  KEY `invoice_id` (`invoice_id`),
  KEY `customer_id` (`customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 21. SUPPLIER_INFORMATION TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `supplier_information` (
  `supplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `supplier_name` varchar(255) NOT NULL,
  `supplier_mobile` varchar(20) NOT NULL,
  `supplier_email` varchar(100) DEFAULT NULL,
  `supplier_address_1` text,
  `supplier_address_2` text,
  `city` varchar(100) DEFAULT NULL,
  `state` varchar(100) DEFAULT NULL,
  `zip` varchar(20) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `contact` varchar(100) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `credit_limit` decimal(15,2) DEFAULT 0.00,
  `status` tinyint(1) DEFAULT 1,
  `salesman_code` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 22. SUPPLIER_PAYMENT TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `supplier_payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_id` int(11) DEFAULT NULL,
  `supplier_id` int(11) NOT NULL,
  `payment_date` date NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_method` enum('cash','bank','cheque','pdc') DEFAULT 'cash',
  `cheque_no` varchar(100) DEFAULT NULL,
  `cheque_date` date DEFAULT NULL,
  `bank` varchar(255) DEFAULT NULL,
  `discount` decimal(15,2) DEFAULT 0.00,
  `notes` text,
  `created_at` timestamp DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `purchase_id` (`purchase_id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- 23. UNIT TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS `unit` (
  `unit_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit_name` varchar(100) NOT NULL,
  `unit_short_name` varchar(20) NOT NULL,
  `status` tinyint(1) DEFAULT 1,
  PRIMARY KEY (`unit_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- END OF SCHEMA
-- =====================================================
