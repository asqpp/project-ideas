-- ============================================================
-- Client Master Sample Records (Customers/Suppliers/Staff/Agents)
-- ------------------------------------------------------------
-- These inserts provide one sample record for each client type
-- so QA can validate:
--   * auto-code prefixes (C, S, F, A)
--   * duplicate phone detection (all share a mobile number)
--   * permissions against userd/accountm
--   * cross-table sync between master tables and accountm
--
-- Run with:  mysql -u root -p cybor432_erpnew < database/seeds/client_master_samples.sql
-- The statements are idempotent via ON DUPLICATE KEY UPDATE.
-- ============================================================

INSERT INTO `customer_information`
    (`customer_id`, `customer_code`, `customer_name`, `customer_mobile`, `customer_email`,
     `customer_address_1`, `city`, `state`, `zip`, `country`, `contact`, `salesman_code`)
VALUES
    (9001, 'C9001', 'Sample Customer', '7777777777', 'customer.demo@example.com',
     '100 Demo Street', 'Demo City', 'Demo State', '90001', 'Demo Country', 'Jane Demo', 'SM-DEMO')
ON DUPLICATE KEY UPDATE
    `customer_name` = VALUES(`customer_name`),
    `customer_mobile` = VALUES(`customer_mobile`),
    `customer_email` = VALUES(`customer_email`),
    `customer_address_1` = VALUES(`customer_address_1`);

INSERT INTO `supplier_information`
    (`supplier_id`, `supplier_code`, `supplier_name`, `supplier_mobile`, `supplier_email`,
     `supplier_address_1`, `city`, `state`, `zip`, `country`, `contact`, `salesman_code`)
VALUES
    (9001, 'S9001', 'Sample Supplier', '7777777777', 'supplier.demo@example.com',
     '200 Demo Avenue', 'Demo City', 'Demo State', '90002', 'Demo Country', 'John Demo', 'SM-DEMO')
ON DUPLICATE KEY UPDATE
    `supplier_name` = VALUES(`supplier_name`),
    `supplier_mobile` = VALUES(`supplier_mobile`),
    `supplier_email` = VALUES(`supplier_email`),
    `supplier_address_1` = VALUES(`supplier_address_1`);

INSERT INTO `hr_employees`
    (`id`, `employee_code`, `full_name`, `department`, `designation`, `joining_date`,
     `work_email`, `mobile`, `phone`, `status`)
VALUES
    (9001, 'F9001', 'Sample Staff', 'Sales', 'Sales Executive', '2020-01-01',
     'staff.demo@example.com', '7777777777', '7777777778', 'Active')
ON DUPLICATE KEY UPDATE
    `full_name` = VALUES(`full_name`),
    `mobile` = VALUES(`mobile`),
    `work_email` = VALUES(`work_email`);

INSERT INTO `agent`
    (`agent_id`, `agent_code`, `agent_name`, `mobile`, `email`, `address`, `commission_rate`, `salesman_code`)
VALUES
    (9001, 'A9001', 'Sample Agent', '7777777777', 'agent.demo@example.com',
     '300 Demo Road', 5.00, 'SM-DEMO')
ON DUPLICATE KEY UPDATE
    `agent_name` = VALUES(`agent_name`),
    `mobile` = VALUES(`mobile`),
    `commission_rate` = VALUES(`commission_rate`);

INSERT INTO `broker`
    (`broker_id`, `broker_code`, `broker_name`, `mobile`, `email`, `address`, `commission_rate`, `salesman_code`)
VALUES
    (9001, 'B9001', 'Sample Broker', '7777777777', 'broker.demo@example.com',
     '400 Demo Lane', 2.50, 'SM-DEMO')
ON DUPLICATE KEY UPDATE
    `broker_name` = VALUES(`broker_name`),
    `mobile` = VALUES(`mobile`),
    `commission_rate` = VALUES(`commission_rate`);

INSERT INTO `clients`
    (`code`, `name`, `ctype`, `grp`, `account_group`, `bshead`, `addr1`, `city`, `state`,
     `pin`, `country`, `mobile`, `email`, `smcode`, `opbalance`, `balance_type`,
     `salary`, `agentcode`, `contract_date`, `adate`, `duedate`)
VALUES
    ('C9001', 'Sample Customer', 'C', 'CUSTOMER', 'SUNDB', 'SUNDB', '100 Demo Street', 'Demo City', 'Demo State', '90001', 'Demo Country', '7777777777', 'customer.demo@example.com', 'SM-DEMO', -500.00, 'dr', NULL, NULL, CURDATE(), CURDATE(), CURDATE()),
    ('S9001', 'Sample Supplier', 'S', 'SUPPLIER', 'SUNCR', 'SUNCR', '200 Demo Avenue', 'Demo City', 'Demo State', '90002', 'Demo Country', '7777777777', 'supplier.demo@example.com', 'SM-DEMO', 750.00, 'cr', NULL, NULL, CURDATE(), CURDATE(), CURDATE()),
    ('F9001', 'Sample Staff', 'F', 'STAFF', 'SUNCR', 'SUNCR', 'HQ', 'Demo City', 'Demo State', '90003', 'Demo Country', '7777777777', 'staff.demo@example.com', 'SM-DEMO', 0, 'cr', 4500.00, NULL, CURDATE(), CURDATE(), CURDATE()),
    ('A9001', 'Sample Agent', 'A', 'BROKER', 'SUNCR', 'SUNCR', '300 Demo Road', 'Demo City', 'Demo State', '90004', 'Demo Country', '7777777777', 'agent.demo@example.com', 'SM-DEMO', 0, 'cr', NULL, 'A9001', CURDATE(), CURDATE(), CURDATE())
ON DUPLICATE KEY UPDATE
    `name` = VALUES(`name`),
    `mobile` = VALUES(`mobile`),
    `email` = VALUES(`email`),
    `smcode` = VALUES(`smcode`);

INSERT INTO `accountm`
    (`accode`, `name`, `actype1`, `actype2`, `grcode`, `bshead`, `opbal`, `control`, `hlp`)
VALUES
    ('CUST-C9001', 'Sample Customer (C9001)', 'A', 'C', 'SUNDB', 'SUNDB', -500.00, 1, 1),
    ('SUPP-S9001', 'Sample Supplier (S9001)', 'L', 'S', 'SUNCR', 'SUNCR', 750.00, 1, 1),
    ('STAFF-F9001', 'Sample Staff (F9001)', 'L', 'F', 'SUNCR', 'SUNCR', 0.00, 1, 1),
    ('AGNT-A9001', 'Sample Agent (A9001)', 'L', 'A', 'SUNCR', 'SUNCR', 0.00, 1, 1)
ON DUPLICATE KEY UPDATE
    `name` = VALUES(`name`),
    `opbal` = VALUES(`opbal`);

-- ============================================================
-- End of client master samples
-- ============================================================
