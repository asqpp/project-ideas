-- =====================================================
-- Insurance Management System v2.0 - Sample Data
-- Database: cybor432_erpnew
-- =====================================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";

-- =====================================================
-- 1. SYSTEM ACCOUNTS (Chart of Accounts)
-- =====================================================
INSERT INTO `accounts` (`account_code`, `account_name`, `account_type`, `description`, `is_system`, `status`) VALUES
('CASH', 'Cash on Hand', 'asset', 'Cash available at office', 1, 1),
('BANK', 'Bank Account', 'asset', 'Main bank account', 1, 1),
('PDCREC', 'PDC Receivable', 'asset', 'Post-dated cheques received from customers', 1, 1),
('PDCPAY', 'PDC Payable', 'liability', 'Post-dated cheques issued to suppliers', 1, 1),
('SALES', 'Sales Revenue', 'income', 'Revenue from sales', 1, 1),
('PURCHASE', 'Purchase Cost', 'expense', 'Cost of purchases', 1, 1),
('DISCALL', 'Discount Allowed', 'expense', 'Discounts given to customers', 1, 1),
('DISCREC', 'Discount Received', 'income', 'Discounts received from suppliers', 1, 1),
('VAT-OUT', 'VAT Output', 'liability', 'VAT collected from customers', 1, 1),
('VAT-IN', 'VAT Input', 'asset', 'VAT paid to suppliers', 1, 1),
('CAPITAL', 'Capital', 'equity', 'Owner capital', 1, 1),
('SALARY', 'Salary Expense', 'expense', 'Employee salaries', 0, 1),
('RENT', 'Rent Expense', 'expense', 'Office rent', 0, 1),
('UTILITIES', 'Utilities Expense', 'expense', 'Electricity, water, internet', 0, 1),
('COMMISSION', 'Commission Expense', 'expense', 'Broker and agent commissions', 1, 1);

-- =====================================================
-- 2. CATEGORIES
-- =====================================================
INSERT INTO `category_list` (`category_code`, `category_name`, `description`, `status`) VALUES
('MOTOR', 'Motor Insurance', 'Vehicle insurance products', 1),
('HEALTH', 'Health Insurance', 'Medical and health insurance products', 1),
('PROPERTY', 'Property Insurance', 'Home and property insurance', 1),
('LIFE', 'Life Insurance', 'Life and term insurance products', 1),
('TRAVEL', 'Travel Insurance', 'Travel and trip insurance', 1),
('BUSINESS', 'Business Insurance', 'Commercial and business insurance', 1);

-- =====================================================
-- 3. UNITS
-- =====================================================
INSERT INTO `unit` (`unit_name`, `unit_short_name`, `status`) VALUES
('Policy', 'pol', 1),
('Unit', 'unit', 1),
('Piece', 'pc', 1),
('Set', 'set', 1),
('Package', 'pkg', 1);

-- Product groups & subgroups
INSERT INTO `product_groups` (`group_code`, `group_name`, `category_id`, `description`, `status`) VALUES
('MOTOR-CORE', 'Motor Comprehensive', 1, 'Core motor plans', 1),
('HEALTH-CORE', 'Health Individual', 2, 'Individual health plans', 1),
('PROPERTY-HOME', 'Home Coverage', 3, 'Home property plans', 1),
('TRAVEL-GLOBAL', 'Travel Protection', 5, 'Travel programs', 1);

INSERT INTO `product_subgroups` (`subgroup_code`, `subgroup_name`, `group_id`, `description`, `status`) VALUES
('MOTOR-FLEET', 'Fleet Vehicles', 1, 'Policies for fleet vehicles', 1),
('MOTOR-RETAIL', 'Retail Vehicles', 1, 'Retail car owners', 1),
('HEALTH-PREMIUM', 'Premium Cover', 2, 'Premium health in-patient plans', 1),
('HEALTH-OP', 'Outpatient Cover', 2, 'Outpatient policies', 1),
('PROPERTY-STD', 'Standard Home', 3, 'Standard homes', 1),
('TRAVEL-FAMILY', 'Family Travel', 4, 'Annual family packages', 1);

-- =====================================================
-- 4. CUSTOMERS
-- =====================================================
INSERT INTO `customer_information` (`customer_name`, `customer_mobile`, `customer_email`, `customer_address_1`, `city`, `state`, `country`, `contact`, `fax`, `credit_limit`, `status`, `salesman_code`) VALUES
('Ahmed Mohammed Ali', '+971-50-1234567', 'ahmed.ali@email.com', 'Al Nahda Street, Building 123', 'Dubai', 'Dubai', 'UAE', 'Imran N.', '+971-4-123-1111', 50000.00, 1, 'SM-CUST-01'),
('Fatima Hassan', '+971-55-2345678', 'fatima.hassan@email.com', 'Deira City Center, Office 456', 'Dubai', 'Dubai', 'UAE', 'Sameera A.', '+971-4-123-2222', 30000.00, 1, 'SM-CUST-02'),
('Mohammed Abdullah', '+971-50-3456789', 'mohammed.abdullah@email.com', 'Sheikh Zayed Road, Tower 789', 'Dubai', 'Dubai', 'UAE', 'Yasir K.', '+971-4-123-3333', 75000.00, 1, 'SM-CUST-03'),
('Sara Ibrahim', '+971-55-4567890', 'sara.ibrahim@email.com', 'Jumeirah Beach Road, Villa 12', 'Dubai', 'Dubai', 'UAE', 'Leila R.', '+971-4-123-4444', 40000.00, 1, 'SM-CUST-01'),
('Omar Khalid', '+971-50-5678901', 'omar.khalid@email.com', 'Business Bay, Floor 15', 'Dubai', 'Dubai', 'UAE', 'Nader S.', '+971-4-123-5555', 60000.00, 1, 'SM-CUST-04'),
('Aisha Rashid', '+971-55-6789012', 'aisha.rashid@email.com', 'Marina Walk, Apartment 234', 'Dubai', 'Dubai', 'UAE', 'Rania H.', '+971-4-123-6666', 35000.00, 1, 'SM-CUST-02'),
('Khalid Salem', '+971-50-7890123', 'khalid.salem@email.com', 'Al Barsha, Street 45', 'Dubai', 'Dubai', 'UAE', 'Saif B.', '+971-4-123-7777', 45000.00, 1, 'SM-CUST-05'),
('Mariam Youssef', '+971-55-8901234', 'mariam.youssef@email.com', 'JBR, Block A', 'Dubai', 'Dubai', 'UAE', 'Hiba L.', '+971-4-123-8888', 55000.00, 1, 'SM-CUST-03');

-- =====================================================
-- 5. SUPPLIERS
-- =====================================================
INSERT INTO `supplier_information` (`supplier_name`, `supplier_mobile`, `supplier_email`, `supplier_address_1`, `city`, `state`, `country`, `contact`, `fax`, `credit_limit`, `status`, `salesman_code`) VALUES
('Dubai Insurance Company LLC', '+971-4-1234567', 'info@dubaiinsurance.ae', 'Dubai World Trade Center', 'Dubai', 'Dubai', 'UAE', 'Rashid F.', '+971-4-655-1111', 500000.00, 1, 'SM-SUP-01'),
('Emirates Insurance Group', '+971-4-2345678', 'sales@emiratesinsurance.ae', 'DIFC Gate Avenue', 'Dubai', 'Dubai', 'UAE', 'Arif D.', '+971-4-655-2222', 750000.00, 1, 'SM-SUP-02'),
('Abu Dhabi National Insurance', '+971-2-3456789', 'contact@adnic.ae', 'Al Khaleej Al Arabi Street', 'Abu Dhabi', 'Abu Dhabi', 'UAE', 'Latifa P.', '+971-2-655-3333', 1000000.00, 1, 'SM-SUP-03'),
('Orient Insurance PJSC', '+971-4-4567890', 'info@orientinsurance.ae', 'Trade Center Road', 'Dubai', 'Dubai', 'UAE', 'Meera C.', '+971-4-655-4444', 600000.00, 1, 'SM-SUP-02'),
('Oman Insurance Company', '+971-4-5678901', 'sales@oman-insurance.ae', 'Bur Dubai', 'Dubai', 'Dubai', 'UAE', 'Farah V.', '+971-4-655-5555', 800000.00, 1, 'SM-SUP-01');

-- =====================================================
-- 6. BROKERS
-- =====================================================
INSERT INTO `broker` (`broker_code`, `broker_name`, `contact_person`, `mobile`, `email`, `fax`, `address`, `commission_rate`, `salesman_code`, `status`) VALUES
('BRK-0001', 'Gulf Insurance Brokers', 'Ali Hassan', '+971-50-1111111', 'ali@gulfbrokers.ae', '+971-4-700-1111', 'Sheikh Zayed Road, Dubai', 5.00, 'SM-BRK-01', 1),
('BRK-0002', 'Emirates Brokerage House', 'Fatima Ahmed', '+971-55-2222222', 'fatima@emiratesbroker.ae', '+971-4-700-2222', 'DIFC, Dubai', 4.50, 'SM-BRK-02', 1),
('BRK-0003', 'Middle East Insurance Brokers', 'Mohammed Said', '+971-50-3333333', 'mohammed@mebrokers.ae', '+971-4-700-3333', 'Business Bay, Dubai', 5.50, 'SM-BRK-03', 1),
('BRK-0004', 'Dubai Insurance Consultants', 'Sara Khalid', '+971-55-4444444', 'sara@dubaiinsuranceconsult.ae', '+971-4-700-4444', 'Deira, Dubai', 4.00, 'SM-BRK-01', 1);

-- =====================================================
-- 7. AGENTS
-- =====================================================
INSERT INTO `agent` (`agent_code`, `agent_name`, `contact_person`, `mobile`, `email`, `fax`, `address`, `commission_rate`, `salesman_code`, `status`) VALUES
('AGT-0001', 'Ahmed Insurance Services', 'Ahmed Ali', '+971-50-5555555', 'ahmed@ahmedinsurance.ae', '+971-4-711-1111', 'Al Nahda, Dubai', 3.00, 'SM-AGT-01', 1),
('AGT-0002', 'Khalid Agency', 'Khalid Omar', '+971-55-6666666', 'khalid@khalidagency.ae', '+971-4-711-2222', 'Sharjah', 3.50, 'SM-AGT-02', 1),
('AGT-0003', 'Aisha Insurance Agency', 'Aisha Mohammed', '+971-50-7777777', 'aisha@aishaagency.ae', '+971-4-711-3333', 'Ajman', 3.25, 'SM-AGT-03', 1),
('AGT-0004', 'Omar Consultants', 'Omar Hassan', '+971-55-8888888', 'omar@omarconsultants.ae', '+971-4-711-4444', 'Ras Al Khaimah', 2.75, 'SM-AGT-02', 1),
('AGT-0005', 'Mariam Insurance Hub', 'Mariam Saeed', '+971-50-9999999', 'mariam@mariamhub.ae', '+971-4-711-5555', 'Fujairah', 3.00, 'SM-AGT-01', 1);

-- =====================================================
-- 7b. CLIENTS MASTER SNAPSHOT
-- =====================================================
INSERT INTO `clients`
(`code`,`name`,`ctype`,`addr1`,`city`,`state`,`pin`,`country`,`telephone`,`mobile`,`email`,`tin`,`cst`,`panadhar`,`opbalance`,`opbalanceb`,`balance_type`,`secondary_balance_type`,`control`,`removed`,`salary`,`cocode`,`grp`,`adate`,`duedate`,`cutrate`,`commission_pct`,`staff_commission`,`route`,`carea`,`pcard`,`smcode`,`pospwd`,`agent`,`oppcardpoints`,`pcardno`,`approval`,`homemobile`,`distance`,`account_group`,`bshead`,`notes`,`link_phonebook`,`print_card`,`show_camera`,`update_foreign`,`agent_staff`,`agentcode`,`contract_date`,`care_of_party`)
VALUES
('C0001','John Doe','C','123 Main St','New York','NY','10001','USA','1234567890','9876543210','john@example.com','123GST','123CST','123PAN',-500.00,0.00,'dr','cr',1,'N',NULL,NULL,'CUSTOMER','2025-11-13','2025-12-13',0.00,0.00,0.00,'RT1','AREA1','CARD1','SM1',NULL,'N',100.00,'PCARD1','N',NULL,50.00,'SUNDB','SUNDB','Loyal customer with winter promo','Y','N','N','N','N',NULL,NULL,'N'),
('S0001','ABC Suppliers','S','456 Trade Ave','Chicago','IL','60601','USA','3125550101','8765432109','abc@example.com','456GST','456CST','456PAN',1000.00,0.00,'cr','cr',1,'N',NULL,NULL,'SUPPLIER','2025-11-13','2025-12-13',0.00,0.00,0.00,'RT2','AREA2',NULL,'SM2',NULL,'N',0.00,NULL,'N',NULL,75.00,'SUNCR','SUNCR','Preferred logistics partner','N','N','N','N','N',NULL,NULL,'N'),
('F0001','Jane Smith','F','789 Work Rd','Los Angeles','CA','90001','USA','2135550199','7654321098','jane@example.com','789GST','9876543210','789PAN',0.00,0.00,'cr','cr',1,'N',5000.00,NULL,'STAFF','2025-11-13','2025-12-13',2.50,0.00,1.00,'RT3','AREA3',NULL,'SM3','POS123','Y',0.00,NULL,'Y','9876543210',25.00,'SUNCR','SUNCR','Store manager with approval rights','Y','N','N','N','Y',NULL,NULL,'N'),
('A0001','XYZ Brokers','A','101 Market St','Miami','FL','33101','USA','3055550145','6543210987','xyz@example.com','012GST','012CST','012PAN',2000.00,0.00,'cr','cr',1,'N',NULL,NULL,'BROKER','2025-11-13','2025-12-13',0.00,3.00,NULL,'RT4','AREA4',NULL,'SM4',NULL,'Y',0.00,NULL,'N',NULL,100.00,'SUNCR','SUNCR','Broker with coastal coverage','Y','N','N','N','N','BRK-X-001','2025-10-01','N');

-- =====================================================
-- 7c. HR EMPLOYEES
-- =====================================================
INSERT INTO `hr_employees` (`employee_code`,`full_name`,`department`,`designation`,`joining_date`,`work_email`,`mobile`,`phone`,`status`,`notes`)
VALUES
('EMP-0001','Jane Smith','Sales','Store Manager','2023-06-01','jane.smith@demo.local','3456789012','1234567890','Active','Handles premium walk-in customers'),
('EMP-0002','Robert Brown','Support','Technician','2022-02-15','robert.brown@demo.local','4567890123','1231231234','Active','Backend installation expert'),
('EMP-0003','Priya Menon','Accounts','Accountant','2021-09-10','priya.menon@demo.local','5678901234',NULL,'Active','Supervises reconciliation'),
('EMP-0004','Liam Wright','Logistics','Driver','2020-01-20','liam.wright@demo.local','6789012345','9876543210','Inactive','On sabbatical leave');

-- =====================================================
-- 8. PRODUCTS (Insurance Policies)
-- =====================================================
INSERT INTO `product_information`
(`product_code`,`product_name`,`product_model`,`category_id`,`group_id`,`subgroup_id`,`unit_id`,`default_qty`,`price`,`supplier_price`,`quantity`,`min_stock`,`tax_percent`,`taxable`,`no_discount`,`product_details`,`status`)
VALUES
('PROD-00001','Comprehensive Motor Insurance','CMI-2024',1,1,2,1,1,2500.00,1750.00,50,10,5.00,1,0,'Full coverage motor insurance policy',1),
('PROD-00002','Third Party Motor Insurance','TPL-2024',1,1,1,1,1,850.00,500.00,100,20,5.00,1,0,'Third party liability motor insurance',1),
('PROD-00003','Individual Health Insurance','IHI-2024',2,2,3,1,1,5000.00,3200.00,75,15,5.00,1,0,'Individual health insurance coverage',1),
('PROD-00004','Family Health Insurance','FHI-2024',2,2,4,1,1,12000.00,9000.00,40,10,5.00,1,0,'Family floater health insurance',1),
('PROD-00005','Home Insurance - Basic','HBI-2024',3,3,5,1,1,1500.00,900.00,60,12,5.00,1,0,'Basic home insurance coverage',1),
('PROD-00006','Home Insurance - Comprehensive','HCI-2024',3,3,null,1,1,3500.00,2400.00,35,8,5.00,1,0,'Comprehensive home insurance',1),
('PROD-00007','Term Life Insurance','TLI-2024',4,null,null,1,1,8000.00,5000.00,30,5,0.00,0,0,'Term life insurance policy',1),
('PROD-00008','Whole Life Insurance','WLI-2024',4,null,null,1,1,15000.00,10000.00,20,5,0.00,0,1,'Whole life insurance coverage',1),
('PROD-00009','Travel Insurance - Single Trip','TST-2024',5,4,6,1,1,250.00,120.00,200,50,5.00,1,0,'Single trip travel insurance',1),
('PROD-00010','Travel Insurance - Annual','TAM-2024',5,4,6,1,1,1200.00,750.00,80,20,5.00,1,0,'Annual multi-trip travel insurance',1),
('PROD-00011','Business Liability Insurance','BLI-2024',6,null,null,1,1,10000.00,6400.00,25,5,5.00,1,1,'Commercial general liability',1),
('PROD-00012','Professional Indemnity','PIN-2024',6,null,null,1,1,7500.00,4300.00,30,5,5.00,1,0,'Professional indemnity insurance',1);

-- =====================================================
-- 9. SAMPLE INVOICES
-- =====================================================
INSERT INTO `invoice` (`invoice`, `customer_id`, `date`, `total`, `vat`, `grand_total`, `total_amount`, `paid_amount`, `due_amount`, `payment_status`, `broker_id`, `agent_id`, `sales_by`, `sales_date`) VALUES
('INV-2024-0001', 1, '2024-01-15', 5000.00, 250.00, 5250.00, 5250.00, 5250.00, 0.00, 'paid', 1, 1, 1, '2024-01-15 10:00:00'),
('INV-2024-0002', 2, '2024-01-18', 12000.00, 600.00, 12600.00, 12600.00, 6000.00, 6600.00, 'partial', 2, 2, 1, '2024-01-18 11:30:00'),
('INV-2024-0003', 3, '2024-01-22', 3500.00, 175.00, 3675.00, 3675.00, 0.00, 3675.00, 'unpaid', 1, 3, 1, '2024-01-22 09:15:00'),
('INV-2024-0004', 4, '2024-01-25', 8000.00, 400.00, 8400.00, 8400.00, 8400.00, 0.00, 'paid', 3, 1, 1, '2024-01-25 16:45:00'),
('INV-2024-0005', 5, '2024-02-01', 2500.00, 125.00, 2625.00, 2625.00, 1200.00, 1425.00, 'partial', 2, 4, 1, '2024-02-01 14:20:00'),
('INV-2024-0006', 6, '2024-02-05', 15000.00, 750.00, 15750.00, 15750.00, 0.00, 15750.00, 'unpaid', 4, 2, 1, '2024-02-05 10:30:00'),
('INV-2024-0007', 7, '2024-02-10', 1500.00, 75.00, 1575.00, 1575.00, 1575.00, 0.00, 'paid', 1, 5, 1, '2024-02-10 12:10:00'),
('INV-2024-0008', 8, '2024-02-15', 10000.00, 500.00, 10500.00, 10500.00, 5500.00, 5000.00, 'partial', 3, 3, 1, '2024-02-15 15:00:00');

-- =====================================================
-- 10. INVOICE DETAILS
-- =====================================================
INSERT INTO `invoice_details` (`invoice_id`, `product_id`, `quantity`, `rate`, `total_price`) VALUES
(1, 3, 1, 5000.00, 5000.00),
(2, 4, 1, 12000.00, 12000.00),
(3, 6, 1, 3500.00, 3500.00),
(4, 7, 1, 8000.00, 8000.00),
(5, 1, 1, 2500.00, 2500.00),
(6, 8, 1, 15000.00, 15000.00),
(7, 5, 1, 1500.00, 1500.00),
(8, 11, 1, 10000.00, 10000.00);

-- =====================================================
-- 11. SAMPLE PURCHASES
-- =====================================================
INSERT INTO `product_purchase` (`chalan_no`, `supplier_id`, `purchase_date`, `total_amount`, `vat`, `grand_total_amount`, `payment_status`) VALUES
('PUR-2024-0001', 1, '2024-01-10', 50000.00, 2500.00, 52500.00, 'paid'),
('PUR-2024-0002', 2, '2024-01-12', 75000.00, 3750.00, 78750.00, 'partial'),
('PUR-2024-0003', 3, '2024-01-20', 100000.00, 5000.00, 105000.00, 'unpaid'),
('PUR-2024-0004', 4, '2024-02-05', 60000.00, 3000.00, 63000.00, 'paid'),
('PUR-2024-0005', 5, '2024-02-12', 80000.00, 4000.00, 84000.00, 'partial');

-- =====================================================
-- 12. PURCHASE DETAILS
-- =====================================================
INSERT INTO `product_purchase_details` (`purchase_id`, `product_id`, `quantity`, `rate`, `total_amount`) VALUES
(1, 1, 20, 2000.00, 40000.00),
(1, 2, 10, 750.00, 7500.00),
(1, 9, 10, 200.00, 2000.00),
(2, 3, 15, 4500.00, 67500.00),
(2, 5, 5, 1500.00, 7500.00),
(3, 4, 10, 11000.00, 110000.00),
(4, 6, 10, 3200.00, 32000.00),
(4, 7, 5, 7500.00, 37500.00),
(5, 11, 8, 9500.00, 76000.00);

-- =====================================================
-- 13. SAMPLE RECEIPTS
-- =====================================================
INSERT INTO `receipt` (`invoice_id`, `customer_id`, `receipt_date`, `amount`, `payment_method`, `discount`, `notes`) VALUES
(1, 1, '2024-01-20', 5250.00, 'bank', 0.00, 'Full payment received'),
(2, 2, '2024-01-25', 6000.00, 'cash', 100.00, 'Partial payment with discount'),
(4, 4, '2024-02-01', 8400.00, 'cheque', 0.00, 'Payment by cheque'),
(5, 5, '2024-02-08', 1500.00, 'bank', 50.00, 'Advance payment'),
(7, 7, '2024-02-15', 1575.00, 'cash', 0.00, 'Cash payment'),
(8, 8, '2024-02-20', 5000.00, 'bank', 0.00, 'First installment');

-- =====================================================
-- 14. SAMPLE PAYMENTS
-- =====================================================
INSERT INTO `supplier_payment` (`purchase_id`, `supplier_id`, `payment_date`, `amount`, `payment_method`, `discount`, `notes`) VALUES
(1, 1, '2024-01-15', 52500.00, 'bank', 0.00, 'Full payment'),
(2, 2, '2024-01-20', 40000.00, 'bank', 500.00, 'Partial payment with discount'),
(4, 4, '2024-02-10', 63000.00, 'cheque', 0.00, 'Payment by cheque'),
(5, 5, '2024-02-18', 50000.00, 'bank', 1000.00, 'First installment');

-- =====================================================
-- 15. BROKER COMMISSIONS
-- =====================================================
INSERT INTO `broker_commission` (`broker_id`, `invoice_id`, `commission_amount`, `commission_rate`, `paid_amount`, `payment_status`) VALUES
(1, 1, 262.50, 5.00, 262.50, 'paid'),
(2, 2, 567.00, 4.50, 300.00, 'partial'),
(1, 3, 201.88, 5.50, 0.00, 'unpaid'),
(3, 4, 462.00, 5.50, 462.00, 'paid'),
(2, 5, 118.13, 4.50, 0.00, 'unpaid'),
(4, 6, 630.00, 4.00, 0.00, 'unpaid'),
(1, 7, 86.63, 5.50, 86.63, 'paid'),
(3, 8, 577.50, 5.50, 300.00, 'partial');

-- =====================================================
-- 16. AGENT COMMISSIONS
-- =====================================================
INSERT INTO `agent_commission` (`agent_id`, `invoice_id`, `commission_amount`, `commission_rate`, `paid_amount`, `payment_status`) VALUES
(1, 1, 157.50, 3.00, 157.50, 'paid'),
(2, 2, 441.00, 3.50, 200.00, 'partial'),
(3, 3, 119.44, 3.25, 0.00, 'unpaid'),
(1, 4, 252.00, 3.00, 252.00, 'paid'),
(4, 5, 72.19, 2.75, 0.00, 'unpaid'),
(2, 6, 551.25, 3.50, 0.00, 'unpaid'),
(5, 7, 47.25, 3.00, 47.25, 'paid'),
(3, 8, 341.25, 3.25, 150.00, 'partial');

-- =====================================================
-- 17. SAMPLE QUOTATIONS
-- =====================================================
INSERT INTO `quotation` (`quotation_no`, `customer_id`, `quotation_date`, `valid_until`, `subtotal`, `vat`, `grand_total`, `items`, `notes`, `status`) VALUES
('QT-2024-0001', 1, '2024-03-01', '2024-03-31', 5000.00, 250.00, 5250.00, '[{"product_id":3,"quantity":1,"rate":5000}]', 'Special offer for new customer', 'pending'),
('QT-2024-0002', 3, '2024-03-05', '2024-04-05', 15000.00, 750.00, 15750.00, '[{"product_id":8,"quantity":1,"rate":15000}]', 'Premium package quote', 'pending'),
('QT-2024-0003', 5, '2024-03-10', '2024-04-10', 2750.00, 137.50, 2887.50, '[{"product_id":1,"quantity":1,"rate":2500},{"product_id":9,"quantity":1,"rate":250}]', 'Motor + Travel bundle', 'pending');

-- =====================================================
-- 18. SAMPLE PDC (Post-Dated Cheques)
-- =====================================================
INSERT INTO `pdc` (`cheque_no`, `cheque_date`, `amount`, `bank`, `cheque_type`, `customer_id`, `supplier_id`, `status`, `reference_type`, `reference_id`, `notes`) VALUES
('CHQ-001-2024', '2024-04-15', 6600.00, 'Emirates NBD', 'received', 2, NULL, 'pending', 'invoice', 2, 'Balance payment for invoice INV-2024-0002'),
('CHQ-002-2024', '2024-04-20', 3675.00, 'ADCB', 'received', 3, NULL, 'pending', 'invoice', 3, 'Full payment PDC'),
('CHQ-003-2024', '2024-04-25', 15750.00, 'Mashreq Bank', 'received', 6, NULL, 'pending', 'invoice', 6, 'Full payment PDC'),
('CHQ-101-2024', '2024-04-10', 38750.00, 'Dubai Islamic Bank', 'issued', NULL, 2, 'pending', 'purchase', 2, 'Balance payment for purchase'),
('CHQ-102-2024', '2024-04-30', 105000.00, 'First Abu Dhabi Bank', 'issued', NULL, 3, 'pending', 'purchase', 3, 'Full payment PDC');

-- =====================================================
-- 19. DAYBOOK ENTRIES (Sample)
-- =====================================================
INSERT INTO `daybook` (`date`, `account_code`, `debit`, `credit`, `narration`, `reference_type`, `reference_id`) VALUES
-- Invoice 1
('2024-01-15', 'CUST_1', 5250.00, 0.00, 'Sales to Ahmed Mohammed Ali', 'invoice', 1),
('2024-01-15', 'SALES', 0.00, 5000.00, 'Sales revenue', 'invoice', 1),
('2024-01-15', 'VAT-OUT', 0.00, 250.00, 'VAT on sales', 'invoice', 1),
-- Receipt 1
('2024-01-20', 'BANK', 5250.00, 0.00, 'Receipt from Ahmed Mohammed Ali', 'receipt', 1),
('2024-01-20', 'CUST_1', 0.00, 5250.00, 'Payment received', 'receipt', 1),
-- Purchase 1
('2024-01-10', 'PURCHASE', 50000.00, 0.00, 'Purchase from Dubai Insurance Company', 'purchase', 1),
('2024-01-10', 'VAT-IN', 2500.00, 0.00, 'VAT on purchase', 'purchase', 1),
('2024-01-10', 'SUPP_1', 0.00, 52500.00, 'Purchase liability', 'purchase', 1),
-- Payment 1
('2024-01-15', 'SUPP_1', 52500.00, 0.00, 'Payment to Dubai Insurance Company', 'payment', 1),
('2024-01-15', 'BANK', 0.00, 52500.00, 'Payment made', 'payment', 1),
-- Commission entries
('2024-01-20', 'COMMISSION', 262.50, 0.00, 'Broker commission - Gulf Insurance Brokers', 'commission', 1),
('2024-01-20', 'BANK', 0.00, 262.50, 'Commission paid', 'commission', 1);

-- =====================================================
-- END OF SAMPLE DATA
-- =====================================================
