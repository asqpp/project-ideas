<?php
/**
 * =====================================================
 * NA-FIX ERP System - Schema Alteration Utility
 * =====================================================
 *
 * This helper will add the legacy accounting tables
 * (accountm, accountg, accountgbs) required by the
 * Account Position/Details modules when they are missing.
 *
 * Usage:
 *   php altertable.php
 *
 * NOTE: Run this after setup.php (database must exist).
 * The script is idempotent and safe to re-run.
 * =====================================================
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

define('APPPATH', __DIR__ . '/application/');
define('BASEPATH', __DIR__ . '/system/');
if (!defined('ENVIRONMENT')) {
    define('ENVIRONMENT', 'production');
}

require APPPATH . 'config/database.php';

if (!isset($db) || !isset($db['default'])) {
    exit("Database configuration not found.\n");
}

$config = $db['default'];
$mysqli = @new mysqli(
    $config['hostname'],
    $config['username'],
    $config['password'],
    $config['database']
);

if ($mysqli->connect_errno) {
    exit("Failed to connect to MySQL: " . $mysqli->connect_error . "\n");
}

echo "Connected to database {$config['database']}\n";

$queries = [
    "CREATE TABLE IF NOT EXISTS `accountgbs` (
        `hcode` VARCHAR(20) NOT NULL,
        `hname` VARCHAR(255) NOT NULL,
        `actype1` CHAR(1) NOT NULL DEFAULT 'A',
        `pos` INT DEFAULT 0,
        `reserve` ENUM('Y','N') DEFAULT 'N',
        `expand` ENUM('Y','N') DEFAULT 'N',
        `amount` DECIMAL(18,2) DEFAULT 0,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`hcode`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `accountg` (
        `grcode` VARCHAR(20) NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `reserve` ENUM('Y','N') DEFAULT 'N',
        `actype1` CHAR(1) NOT NULL DEFAULT 'A',
        `position` INT DEFAULT 0,
        `pos` INT DEFAULT 0,
        `grp` INT DEFAULT 0,
        `mgrp` VARCHAR(50) DEFAULT NULL,
        `bscode` VARCHAR(50) DEFAULT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`grcode`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `accountm` (
        `accode` VARCHAR(50) NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `actype1` CHAR(1) NOT NULL DEFAULT 'A',
        `actype2` CHAR(1) DEFAULT NULL,
        `reserve` ENUM('Y','N') DEFAULT 'N',
        `grcode` VARCHAR(20) DEFAULT NULL,
        `opbal` DECIMAL(18,2) DEFAULT 0,
        `opbalb` DECIMAL(18,2) DEFAULT 0,
        `control` TINYINT DEFAULT 1,
        `hlp` TINYINT DEFAULT 1,
        `amount` DECIMAL(18,2) DEFAULT 0,
        `tplpos` INT DEFAULT 0,
        `bshead` VARCHAR(20) DEFAULT NULL,
        `shepos` INT DEFAULT 0,
        `shedgrp` VARCHAR(50) DEFAULT NULL,
        `sp` TINYINT DEFAULT 0,
        `amount2` DECIMAL(18,2) DEFAULT 0,
        `removed` ENUM('Y','N') DEFAULT 'N',
        `blocked` ENUM('Y','N') DEFAULT 'N',
        `opdate` DATE DEFAULT NULL,
        `clbal` DECIMAL(18,2) DEFAULT 0,
        `aclink` VARCHAR(50) DEFAULT NULL,
        `acperc` DECIMAL(10,2) DEFAULT 0,
        `note` TEXT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`accode`),
        KEY `idx_accountm_grcode` (`grcode`),
        KEY `idx_accountm_bshead` (`bshead`),
        CONSTRAINT `fk_accountm_group` FOREIGN KEY (`grcode`) REFERENCES `accountg`(`grcode`) ON DELETE SET NULL,
        CONSTRAINT `fk_accountm_head` FOREIGN KEY (`bshead`) REFERENCES `accountgbs`(`hcode`) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `generali` (
        `code` VARCHAR(100) NOT NULL,
        `cvalue` TEXT NULL,
        `description` VARCHAR(255) DEFAULT NULL,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `generals` (
        `code` VARCHAR(100) NOT NULL,
        `cvalue` TEXT NULL,
        `description` VARCHAR(255) DEFAULT NULL,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `userd` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `user_code` VARCHAR(100) NOT NULL,
        `menu_item` VARCHAR(150) NOT NULL,
        `can_edit` TINYINT(1) DEFAULT 1,
        `can_delete` TINYINT(1) DEFAULT 1,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_user_menu` (`user_code`,`menu_item`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `phonebook` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `client_code` VARCHAR(50) NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `resaddress` TEXT NULL,
        `resphone` VARCHAR(50) NULL,
        `offphone` VARCHAR(50) NULL,
        `mobile` VARCHAR(50) NULL,
        `email` VARCHAR(150) NULL,
        `ptype` VARCHAR(50) NULL,
        `grp` VARCHAR(50) NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_phonebook_client` (`client_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `clientspict` (
        `client_code` VARCHAR(50) NOT NULL,
        `mime_type` VARCHAR(100) DEFAULT NULL,
        `picture` LONGBLOB,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`client_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `clients_advanced` (
        `client_code` VARCHAR(50) NOT NULL,
        `payload` LONGTEXT NULL,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`client_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",

    "CREATE TABLE IF NOT EXISTS `clients` (
        `code` VARCHAR(50) NOT NULL,
        `name` VARCHAR(255) NOT NULL,
        `ctype` ENUM('C','S','F','A') NOT NULL DEFAULT 'C',
        `grp` VARCHAR(50) DEFAULT NULL,
        `account_group` VARCHAR(50) DEFAULT NULL,
        `bshead` VARCHAR(50) DEFAULT NULL,
        `addr1` VARCHAR(255) DEFAULT NULL,
        `addr2` VARCHAR(255) DEFAULT NULL,
        `addr3` VARCHAR(255) DEFAULT NULL,
        `city` VARCHAR(100) DEFAULT NULL,
        `state` VARCHAR(100) DEFAULT NULL,
        `pin` VARCHAR(20) DEFAULT NULL,
        `country` VARCHAR(100) DEFAULT NULL,
        `route` VARCHAR(50) DEFAULT NULL,
        `carea` VARCHAR(50) DEFAULT NULL,
        `distance` DECIMAL(10,2) DEFAULT NULL,
        `telephone` VARCHAR(50) DEFAULT NULL,
        `mobile` VARCHAR(50) DEFAULT NULL,
        `homemobile` VARCHAR(50) DEFAULT NULL,
        `email` VARCHAR(150) DEFAULT NULL,
        `fax` VARCHAR(50) DEFAULT NULL,
        `tin` VARCHAR(30) DEFAULT NULL,
        `cst` VARCHAR(30) DEFAULT NULL,
        `panadhar` VARCHAR(50) DEFAULT NULL,
        `religion` VARCHAR(50) DEFAULT NULL,
        `notes` TEXT,
        `smcode` VARCHAR(50) DEFAULT NULL,
        `cocode` VARCHAR(50) DEFAULT NULL,
        `contact_person` VARCHAR(255) DEFAULT NULL,
        `care_of_name` VARCHAR(255) DEFAULT NULL,
        `care_of_party` ENUM('Y','N') DEFAULT 'N',
        `pcard` VARCHAR(50) DEFAULT NULL,
        `pcardno` VARCHAR(50) DEFAULT NULL,
        `oppcardpoints` DECIMAL(10,2) DEFAULT NULL,
        `salary` DECIMAL(18,2) DEFAULT NULL,
        `cutrate` DECIMAL(10,2) DEFAULT NULL,
        `commission_pct` DECIMAL(10,2) DEFAULT NULL,
        `colncomn` DECIMAL(10,2) DEFAULT NULL,
        `staff_commission` DECIMAL(10,2) DEFAULT NULL,
        `id_number` VARCHAR(100) DEFAULT NULL,
        `pospwd` VARCHAR(100) DEFAULT NULL,
        `approval` VARCHAR(100) DEFAULT NULL,
        `agent` ENUM('Y','N') DEFAULT 'N',
        `agentcode` VARCHAR(50) DEFAULT NULL,
        `contract_date` DATE DEFAULT NULL,
        `adate` DATE DEFAULT NULL,
        `duedate` DATE DEFAULT NULL,
        `opbalance` DECIMAL(18,2) DEFAULT 0,
        `opbalanceb` DECIMAL(18,2) DEFAULT 0,
        `balance_type` ENUM('dr','cr') DEFAULT 'cr',
        `secondary_balance_type` ENUM('dr','cr') DEFAULT 'cr',
        `control` TINYINT DEFAULT 1,
        `removed` ENUM('Y','N') DEFAULT 'N',
        `blocked` ENUM('Y','N') DEFAULT 'N',
        `display` ENUM('Y','N') DEFAULT 'Y',
        `link_phonebook` ENUM('Y','N') DEFAULT 'N',
        `print_card` ENUM('Y','N') DEFAULT 'N',
        `show_camera` ENUM('Y','N') DEFAULT 'N',
        `update_foreign` ENUM('Y','N') DEFAULT 'N',
        `agent_staff` ENUM('Y','N') DEFAULT 'N',
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`code`),
        UNIQUE KEY `uniq_clients_agentcode` (`agentcode`),
        KEY `idx_clients_mobile` (`mobile`),
        KEY `idx_clients_id_number` (`id_number`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `hr_employees` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `employee_code` VARCHAR(50) NOT NULL,
        `full_name` VARCHAR(191) NOT NULL,
        `department` VARCHAR(100) DEFAULT NULL,
        `designation` VARCHAR(100) DEFAULT NULL,
        `joining_date` DATE DEFAULT NULL,
        `work_email` VARCHAR(191) DEFAULT NULL,
        `mobile` VARCHAR(20) DEFAULT NULL,
        `phone` VARCHAR(20) DEFAULT NULL,
        `status` VARCHAR(50) DEFAULT 'Active',
        `notes` TEXT NULL,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_hr_employee_code` (`employee_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `product_groups` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `group_code` VARCHAR(50) NOT NULL,
        `group_name` VARCHAR(255) NOT NULL,
        `category_id` INT(11) DEFAULT NULL,
        `description` TEXT NULL,
        `status` TINYINT(1) DEFAULT 1,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_group_code` (`group_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `product_subgroups` (
        `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
        `subgroup_code` VARCHAR(50) NOT NULL,
        `subgroup_name` VARCHAR(255) NOT NULL,
        `group_id` INT UNSIGNED DEFAULT NULL,
        `description` TEXT NULL,
        `status` TINYINT(1) DEFAULT 1,
        `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        UNIQUE KEY `uniq_subgroup_code` (`subgroup_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `agent` (
        `agent_id` INT(11) NOT NULL AUTO_INCREMENT,
        `agent_code` VARCHAR(50) DEFAULT NULL,
        `agent_name` VARCHAR(255) NOT NULL,
        `contact_person` VARCHAR(255) DEFAULT NULL,
        `mobile` VARCHAR(20) NOT NULL,
        `email` VARCHAR(100) DEFAULT NULL,
        `fax` VARCHAR(50) DEFAULT NULL,
        `address` TEXT,
        `commission_rate` DECIMAL(5,2) DEFAULT 0.00,
        `salesman_code` VARCHAR(50) DEFAULT NULL,
        `status` TINYINT(1) DEFAULT 1,
        PRIMARY KEY (`agent_id`),
        UNIQUE KEY `uniq_agent_code` (`agent_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `broker` (
        `broker_id` INT(11) NOT NULL AUTO_INCREMENT,
        `broker_code` VARCHAR(50) DEFAULT NULL,
        `broker_name` VARCHAR(255) NOT NULL,
        `contact_person` VARCHAR(255) DEFAULT NULL,
        `mobile` VARCHAR(20) NOT NULL,
        `email` VARCHAR(100) DEFAULT NULL,
        `fax` VARCHAR(50) DEFAULT NULL,
        `address` TEXT,
        `commission_rate` DECIMAL(5,2) DEFAULT 0.00,
        `salesman_code` VARCHAR(50) DEFAULT NULL,
        `status` TINYINT(1) DEFAULT 1,
        PRIMARY KEY (`broker_id`),
        UNIQUE KEY `uniq_broker_code` (`broker_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `category_list` (
        `category_id` INT(11) NOT NULL AUTO_INCREMENT,
        `category_code` VARCHAR(50) DEFAULT NULL,
        `category_name` VARCHAR(255) NOT NULL,
        `description` TEXT,
        `status` TINYINT(1) DEFAULT 1,
        PRIMARY KEY (`category_id`),
        UNIQUE KEY `uniq_category_code` (`category_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `customer_information` (
        `customer_id` INT(11) NOT NULL AUTO_INCREMENT,
        `customer_code` VARCHAR(50) DEFAULT NULL,
        `customer_name` VARCHAR(255) NOT NULL,
        `customer_mobile` VARCHAR(20) NOT NULL,
        `customer_email` VARCHAR(100) DEFAULT NULL,
        `phone` VARCHAR(20) DEFAULT NULL,
        `vat_no` VARCHAR(50) DEFAULT NULL,
        `cr_no` VARCHAR(50) DEFAULT NULL,
        `customer_address_1` TEXT,
        `customer_address_2` TEXT,
        `city` VARCHAR(100) DEFAULT NULL,
        `state` VARCHAR(100) DEFAULT NULL,
        `zip` VARCHAR(20) DEFAULT NULL,
        `country` VARCHAR(100) DEFAULT NULL,
        `contact` VARCHAR(100) DEFAULT NULL,
        `fax` VARCHAR(50) DEFAULT NULL,
        `credit_limit` DECIMAL(15,2) DEFAULT 0.00,
        `salesman_code` VARCHAR(50) DEFAULT NULL,
        PRIMARY KEY (`customer_id`),
        UNIQUE KEY `uniq_customer_code` (`customer_code`),
        KEY `idx_customer_mobile` (`customer_mobile`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `supplier_information` (
        `supplier_id` INT(11) NOT NULL AUTO_INCREMENT,
        `supplier_code` VARCHAR(50) DEFAULT NULL,
        `supplier_name` VARCHAR(255) NOT NULL,
        `supplier_mobile` VARCHAR(20) NOT NULL,
        `supplier_email` VARCHAR(100) DEFAULT NULL,
        `phone` VARCHAR(20) DEFAULT NULL,
        `vat_no` VARCHAR(50) DEFAULT NULL,
        `cr_no` VARCHAR(50) DEFAULT NULL,
        `supplier_address_1` TEXT,
        `supplier_address_2` TEXT,
        `city` VARCHAR(100) DEFAULT NULL,
        `state` VARCHAR(100) DEFAULT NULL,
        `zip` VARCHAR(20) DEFAULT NULL,
        `country` VARCHAR(100) DEFAULT NULL,
        `contact` VARCHAR(100) DEFAULT NULL,
        `fax` VARCHAR(50) DEFAULT NULL,
        `salesman_code` VARCHAR(50) DEFAULT NULL,
        PRIMARY KEY (`supplier_id`),
        UNIQUE KEY `uniq_supplier_code` (`supplier_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `product_information` (
        `product_id` INT(11) NOT NULL AUTO_INCREMENT,
        `product_code` VARCHAR(50) DEFAULT NULL,
        `product_name` VARCHAR(255) NOT NULL,
        `product_model` VARCHAR(100) DEFAULT NULL,
        `category_id` INT(11) DEFAULT NULL,
        `group_id` INT(11) DEFAULT NULL,
        `subgroup_id` INT(11) DEFAULT NULL,
        `unit_id` INT(11) DEFAULT NULL,
        `default_qty` DECIMAL(10,2) DEFAULT 1.00,
        `price` DECIMAL(15,2) NOT NULL,
        `supplier_price` DECIMAL(15,2) DEFAULT 0.00,
        `quantity` DECIMAL(10,2) DEFAULT 0.00,
        `min_stock` DECIMAL(10,2) DEFAULT 0.00,
        `tax_percent` DECIMAL(5,2) DEFAULT 0.00,
        `taxable` TINYINT(1) DEFAULT 1,
        `no_discount` TINYINT(1) DEFAULT 0,
        `product_details` TEXT,
        `image` VARCHAR(255) DEFAULT NULL,
        `status` TINYINT(1) DEFAULT 1,
        PRIMARY KEY (`product_id`),
        UNIQUE KEY `uniq_product_code` (`product_code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `product_purchase` (
        `purchase_id` INT(11) NOT NULL AUTO_INCREMENT,
        `chalan_no` VARCHAR(100) NOT NULL,
        `supplier_id` INT(11) NOT NULL,
        `purchase_date` DATE NOT NULL,
        `total_amount` DECIMAL(15,2) NOT NULL,
        `vat` DECIMAL(15,2) DEFAULT 0.00,
        `grand_total_amount` DECIMAL(15,2) NOT NULL,
        `payment_status` ENUM('unpaid','partial','paid') DEFAULT 'unpaid',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`purchase_id`),
        KEY `idx_purchase_supplier` (`supplier_id`),
        KEY `idx_purchase_date` (`purchase_date`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `product_purchase_details` (
        `id` INT(11) NOT NULL AUTO_INCREMENT,
        `purchase_id` INT(11) NOT NULL,
        `product_id` INT(11) NOT NULL,
        `quantity` DECIMAL(10,2) NOT NULL,
        `rate` DECIMAL(15,2) NOT NULL,
        `total_amount` DECIMAL(15,2) NOT NULL,
        PRIMARY KEY (`id`),
        KEY `idx_ppurchase_purchase` (`purchase_id`),
        KEY `idx_ppurchase_product` (`product_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `payment` (
        `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
        `purchase_id` INT(11) NOT NULL,
        `payment_date` DATE NOT NULL,
        `amount` DECIMAL(15,2) NOT NULL,
        `payment_method` ENUM('cash','bank','cheque','pdc') DEFAULT 'cash',
        `bank` VARCHAR(255) DEFAULT NULL,
        `cheque_no` VARCHAR(100) DEFAULT NULL,
        `cheque_date` DATE DEFAULT NULL,
        `discount` DECIMAL(15,2) DEFAULT 0.00,
        `details` TEXT,
        `payment_voucher_no` VARCHAR(100) DEFAULT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`payment_id`),
        KEY `idx_payment_purchase` (`purchase_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `receipt` (
        `receipt_id` INT(11) NOT NULL AUTO_INCREMENT,
        `invoice_id` INT(11) DEFAULT NULL,
        `customer_id` INT(11) NOT NULL,
        `receipt_date` DATE NOT NULL,
        `amount` DECIMAL(15,2) NOT NULL,
        `payment_method` ENUM('cash','bank','cheque','pdc') DEFAULT 'cash',
        `cheque_no` VARCHAR(100) DEFAULT NULL,
        `cheque_date` DATE DEFAULT NULL,
        `bank` VARCHAR(255) DEFAULT NULL,
        `discount` DECIMAL(15,2) DEFAULT 0.00,
        `notes` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`receipt_id`),
        KEY `idx_receipt_invoice` (`invoice_id`),
        KEY `idx_receipt_customer` (`customer_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `supplier_payment` (
        `payment_id` INT(11) NOT NULL AUTO_INCREMENT,
        `purchase_id` INT(11) DEFAULT NULL,
        `supplier_id` INT(11) NOT NULL,
        `payment_date` DATE NOT NULL,
        `amount` DECIMAL(15,2) NOT NULL,
        `payment_method` ENUM('cash','bank','cheque','pdc') DEFAULT 'cash',
        `cheque_no` VARCHAR(100) DEFAULT NULL,
        `cheque_date` DATE DEFAULT NULL,
        `bank` VARCHAR(255) DEFAULT NULL,
        `discount` DECIMAL(15,2) DEFAULT 0.00,
        `notes` TEXT,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`payment_id`),
        KEY `idx_supplier_payment_purchase` (`purchase_id`),
        KEY `idx_supplier_payment_supplier` (`supplier_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `unit` (
        `unit_id` INT(11) NOT NULL AUTO_INCREMENT,
        `unit_name` VARCHAR(100) NOT NULL,
        `unit_short_name` VARCHAR(20) NOT NULL,
        `status` TINYINT(1) DEFAULT 1,
        PRIMARY KEY (`unit_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `purchasem` (
        `slno` INT NOT NULL,
        `docno` VARCHAR(20) DEFAULT NULL,
        `billno` VARCHAR(20) DEFAULT NULL,
        `suppcode` VARCHAR(20) DEFAULT NULL,
        `name` VARCHAR(100) DEFAULT NULL,
        `billamt` DECIMAL(15,2) DEFAULT 0.00,
        `pamt` DECIMAL(15,2) DEFAULT 0.00,
        `addamt` DECIMAL(15,2) DEFAULT 0.00,
        `taxamt` DECIMAL(15,2) DEFAULT 0.00,
        `netamt` DECIMAL(15,2) DEFAULT 0.00,
        `ob` DECIMAL(15,2) DEFAULT 0.00,
        `taxperc` DECIMAL(6,3) DEFAULT 0.000,
        `discperc` DECIMAL(6,3) DEFAULT 0.000,
        `discount` DECIMAL(15,2) DEFAULT 0.00,
        `addr` VARCHAR(200) DEFAULT NULL,
        `note` VARCHAR(200) DEFAULT NULL,
        `tdate` DATE DEFAULT NULL,
        `duedate` DATE DEFAULT NULL,
        `billtype` VARCHAR(20) DEFAULT NULL,
        `statecode` VARCHAR(20) DEFAULT NULL,
        `mobile` VARCHAR(30) DEFAULT NULL,
        `pan` VARCHAR(30) DEFAULT NULL,
        `counter` VARCHAR(20) DEFAULT NULL,
        `tcsperc` DECIMAL(6,3) DEFAULT 0.000,
        `tcsamt` DECIMAL(15,2) DEFAULT 0.00,
        `pr` CHAR(1) DEFAULT 'P',
        `control` TINYINT DEFAULT 1,
        `status` TINYINT DEFAULT 1,
        PRIMARY KEY (`slno`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `purchased` (
        `slno` INT NOT NULL,
        `code` VARCHAR(50) NOT NULL,
        `qty` DECIMAL(18,3) DEFAULT 0,
        `rate` DECIMAL(15,2) DEFAULT 0,
        `amount` DECIMAL(15,2) DEFAULT 0,
        `sno` INT NOT NULL,
        PRIMARY KEY (`slno`, `sno`),
        KEY `idx_purchased_code` (`code`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `purchaserd` (
        `slno` INT NOT NULL,
        `code` VARCHAR(50) NOT NULL,
        `qty` DECIMAL(18,3) DEFAULT 0,
        `rate` DECIMAL(15,2) DEFAULT 0,
        `amount` DECIMAL(15,2) DEFAULT 0,
        `sno` INT NOT NULL,
        PRIMARY KEY (`slno`, `sno`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",

    "CREATE TABLE IF NOT EXISTS `purchaserm` (
        `slno` INT NOT NULL,
        `docno` VARCHAR(20) DEFAULT NULL,
        `billno` VARCHAR(20) DEFAULT NULL,
        `suppcode` VARCHAR(20) DEFAULT NULL,
        `name` VARCHAR(100) DEFAULT NULL,
        `billamt` DECIMAL(15,2) DEFAULT 0.00,
        `ramt` DECIMAL(15,2) DEFAULT 0.00,
        `addamt` DECIMAL(15,2) DEFAULT 0.00,
        `lessamt` DECIMAL(15,2) DEFAULT 0.00,
        `status` TINYINT DEFAULT 1,
        `pr` CHAR(1) DEFAULT 'E',
        `control` TINYINT DEFAULT 1,
        `tdate` DATE DEFAULT NULL,
        `ttime` TIME DEFAULT NULL,
        `rate` DECIMAL(15,2) DEFAULT 0.00,
        `smcode` VARCHAR(20) DEFAULT NULL,
        `round` DECIMAL(15,2) DEFAULT 0.00,
        `netamt` DECIMAL(15,2) DEFAULT 0.00,
        `ic` VARCHAR(20) DEFAULT NULL,
        PRIMARY KEY (`slno`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
];

foreach ($queries as $sql) {
    if ($mysqli->query($sql)) {
        echo "Executed: " . substr($sql, 0, 60) . "...\n";
    } else {
        echo "Error: " . $mysqli->error . "\n";
    }
}

$seedStatements = [
    "INSERT INTO accountgbs (hcode, hname, actype1, pos, reserve, expand, amount)
     SELECT 'SUNDB', 'Sundry Debtors', 'A', 0, 'N', 'N', 0
     WHERE NOT EXISTS (SELECT 1 FROM accountgbs WHERE hcode = 'SUNDB')",
    "INSERT INTO accountgbs (hcode, hname, actype1, pos, reserve, expand, amount)
     SELECT 'SUNCR', 'Sundry Creditors', 'L', 0, 'N', 'N', 0
     WHERE NOT EXISTS (SELECT 1 FROM accountgbs WHERE hcode = 'SUNCR')",
    "INSERT INTO accountg (grcode, name, reserve, actype1, position, pos, grp, mgrp, bscode)
     SELECT 'SUNDB', 'Sundry Debtors', 'N', 'A', 0, 0, 0, NULL, 'SUNDB'
     WHERE NOT EXISTS (SELECT 1 FROM accountg WHERE grcode = 'SUNDB')",
    "INSERT INTO accountg (grcode, name, reserve, actype1, position, pos, grp, mgrp, bscode)
     SELECT 'SUNCR', 'Sundry Creditors', 'N', 'L', 0, 0, 0, NULL, 'SUNCR'
     WHERE NOT EXISTS (SELECT 1 FROM accountg WHERE grcode = 'SUNCR')"
];

foreach ($seedStatements as $sql) {
    if ($mysqli->query($sql)) {
        // optional success message suppressed to avoid noise.
    } else {
        echo "Seed error: {$mysqli->error}\n";
    }
}

/**
 * Ensure a column exists on a table with the provided definition.
 */
function ensure_column(mysqli $mysqli, string $table, string $column, string $definition)
{
    $result = $mysqli->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
    if ($result && $result->num_rows > 0) {
        return;
    }
    $sql = "ALTER TABLE `$table` ADD COLUMN `$column` $definition";
    if ($mysqli->query($sql)) {
        echo "Added column $column to $table.\n";
    } else {
        echo "Failed adding $column to $table: {$mysqli->error}\n";
    }
}

/**
 * Ensure a column uses the requested charset/collation definition.
 */
function ensure_column_definition(mysqli $mysqli, string $table, string $column, string $collation, string $definition): void
{
    $result = $mysqli->query("SHOW FULL COLUMNS FROM `$table` LIKE '$column'");
    if ($result && ($row = $result->fetch_assoc())) {
        if (strcasecmp($row['Collation'] ?? '', $collation) === 0) {
            return;
        }
    }
    $sql = "ALTER TABLE `$table` MODIFY `$column` $definition";
    if ($mysqli->query($sql)) {
        echo "Updated definition for $table.$column.\n";
    } else {
        echo "Failed altering $table.$column: {$mysqli->error}\n";
    }
}

/**
 * Ensure a table uses utf8mb4_unicode_ci collation.
 */
function ensure_table_collation(mysqli $mysqli, string $table, string $collation = 'utf8mb4_unicode_ci'): void
{
    $result = $mysqli->query("SHOW TABLE STATUS LIKE '$table'");
    if ($result && ($row = $result->fetch_assoc())) {
        if (strcasecmp($row['Collation'] ?? '', $collation) === 0) {
            return;
        }
    }
    $sql = "ALTER TABLE `$table` CONVERT TO CHARACTER SET utf8mb4 COLLATE $collation";
    $mysqli->query("SET foreign_key_checks = 0");
    $result = $mysqli->query($sql);
    $mysqli->query("SET foreign_key_checks = 1");
    if ($result) {
        echo "Converted $table to collation $collation.\n";
    } else {
        echo "Failed converting $table: {$mysqli->error}\n";
    }
}

/**
 * Ensure an index exists on a table.
 */
function ensure_index(mysqli $mysqli, string $table, string $index, string $definition)
{
    $result = $mysqli->query("SHOW INDEX FROM `$table` WHERE Key_name = '$index'");
    if ($result && $result->num_rows > 0) {
        return;
    }
    $sql = "ALTER TABLE `$table` ADD $definition";
    if ($mysqli->query($sql)) {
        echo "Added index $index to $table.\n";
    } else {
        echo "Failed adding index $index to $table: {$mysqli->error}\n";
    }
}

ensure_column($mysqli, 'accountm', 'actype2', "CHAR(1) DEFAULT NULL");
ensure_column($mysqli, 'accountm', 'reserve', "ENUM('Y','N') DEFAULT 'N'");
ensure_column($mysqli, 'accountm', 'tplpos', "INT DEFAULT 0");
ensure_column($mysqli, 'accountm', 'shepos', "INT DEFAULT 0");
ensure_column($mysqli, 'accountm', 'shedgrp', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'accountm', 'sp', "TINYINT DEFAULT 0");
ensure_column($mysqli, 'accountm', 'removed', "ENUM('Y','N') DEFAULT 'N'");
ensure_column($mysqli, 'accountm', 'blocked', "ENUM('Y','N') DEFAULT 'N'");
ensure_column($mysqli, 'accountm', 'aclink', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'accountm', 'acperc', "DECIMAL(10,2) DEFAULT 0");

ensure_column($mysqli, 'accountg', 'position', "INT DEFAULT 0");
ensure_column($mysqli, 'accountg', 'pos', "INT DEFAULT 0");
ensure_column($mysqli, 'accountg', 'mgrp', "VARCHAR(50) DEFAULT NULL");

ensure_column($mysqli, 'accountgbs', 'pos', "INT DEFAULT 0");
ensure_column($mysqli, 'accountgbs', 'expand', "ENUM('Y','N') DEFAULT 'N'");

// Customer master compatibility columns
ensure_column($mysqli, 'customer_information', 'customer_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'customer_information', 'phone', "VARCHAR(20) DEFAULT NULL");
ensure_column($mysqli, 'customer_information', 'email', "VARCHAR(100) DEFAULT NULL");
ensure_column($mysqli, 'customer_information', 'salesman_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'customer_information', 'fax', "VARCHAR(50) DEFAULT NULL");

// Supplier master compatibility columns
ensure_column($mysqli, 'supplier_information', 'supplier_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'supplier_information', 'salesman_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'supplier_information', 'fax', "VARCHAR(50) DEFAULT NULL");

// Item master enhancements
ensure_column($mysqli, 'category_list', 'category_code', "VARCHAR(50) DEFAULT NULL");
ensure_index($mysqli, 'category_list', 'uniq_category_code', "UNIQUE KEY `uniq_category_code` (`category_code`)");

ensure_column($mysqli, 'product_information', 'product_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'product_information', 'group_id', "INT UNSIGNED DEFAULT NULL");
ensure_column($mysqli, 'product_information', 'subgroup_id', "INT UNSIGNED DEFAULT NULL");
ensure_column($mysqli, 'product_information', 'default_qty', "DECIMAL(10,2) DEFAULT 1");
ensure_column($mysqli, 'product_information', 'supplier_price', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_information', 'tax_percent', "DECIMAL(5,2) DEFAULT 0");
ensure_column($mysqli, 'product_information', 'taxable', "TINYINT(1) DEFAULT 1");
ensure_column($mysqli, 'product_information', 'no_discount', "TINYINT(1) DEFAULT 0");
ensure_column($mysqli, 'product_information', 'product_details', "TEXT NULL");
ensure_column($mysqli, 'product_information', 'image', "VARCHAR(255) DEFAULT NULL");
ensure_index($mysqli, 'product_information', 'uniq_product_code', "UNIQUE KEY `uniq_product_code` (`product_code`)");

// Purchase header enhancements
ensure_column($mysqli, 'product_purchase', 'line_discount_total', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase', 'purchase_discount', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase', 'total_discount', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase', 'paid_amount', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase', 'due_amount', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase', 'payment_type', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'product_purchase', 'payment_summary', "TEXT NULL");
ensure_column($mysqli, 'product_purchase', 'details', "TEXT NULL");

// Purchase line enhancements
ensure_column($mysqli, 'product_purchase_details', 'discount_pct', "DECIMAL(6,3) DEFAULT 0");
ensure_column($mysqli, 'product_purchase_details', 'discount_value', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase_details', 'vat_pct', "DECIMAL(6,3) DEFAULT 0");
ensure_column($mysqli, 'product_purchase_details', 'vat_value', "DECIMAL(15,2) DEFAULT 0");
ensure_column($mysqli, 'product_purchase_details', 'batch_no', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'product_purchase_details', 'expiry_date', "DATE DEFAULT NULL");
ensure_column($mysqli, 'product_purchase_details', 'line_total', "DECIMAL(15,2) DEFAULT 0");

// Staff enhancements
ensure_column($mysqli, 'hr_employees', 'mobile', "VARCHAR(20) DEFAULT NULL");
ensure_column($mysqli, 'hr_employees', 'phone', "VARCHAR(20) DEFAULT NULL");

// Agent/Broker salesman mapping
ensure_column($mysqli, 'agent', 'salesman_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'broker', 'salesman_code', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'agent', 'fax', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'broker', 'fax', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'clients', 'fax', "VARCHAR(50) DEFAULT NULL");
ensure_column($mysqli, 'clients', 'contact_person', "VARCHAR(255) DEFAULT NULL");

ensure_column_definition(
    $mysqli,
    'accountm',
    'accode',
    'utf8mb4_unicode_ci',
    "VARCHAR(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL"
);

$collationTables = [
    'customer_information',
    'supplier_information',
    'agent',
    'broker',
    'clients',
    'clientspict',
    'clients_advanced',
    'phonebook',
    'hr_employees',
    'product_groups',
    'product_subgroups'
];
foreach ($collationTables as $tableName) {
    ensure_table_collation($mysqli, $tableName);
}

$clientColumns = [
    'grp' => "VARCHAR(50) DEFAULT NULL",
    'account_group' => "VARCHAR(50) DEFAULT NULL",
    'bshead' => "VARCHAR(50) DEFAULT NULL",
    'addr1' => "VARCHAR(255) DEFAULT NULL",
    'addr2' => "VARCHAR(255) DEFAULT NULL",
    'addr3' => "VARCHAR(255) DEFAULT NULL",
    'city' => "VARCHAR(100) DEFAULT NULL",
    'state' => "VARCHAR(100) DEFAULT NULL",
    'pin' => "VARCHAR(20) DEFAULT NULL",
    'country' => "VARCHAR(100) DEFAULT NULL",
    'route' => "VARCHAR(50) DEFAULT NULL",
    'carea' => "VARCHAR(50) DEFAULT NULL",
    'distance' => "DECIMAL(10,2) DEFAULT NULL",
    'telephone' => "VARCHAR(50) DEFAULT NULL",
    'mobile' => "VARCHAR(50) DEFAULT NULL",
    'homemobile' => "VARCHAR(50) DEFAULT NULL",
    'email' => "VARCHAR(150) DEFAULT NULL",
    'tin' => "VARCHAR(30) DEFAULT NULL",
    'cst' => "VARCHAR(30) DEFAULT NULL",
    'panadhar' => "VARCHAR(50) DEFAULT NULL",
    'religion' => "VARCHAR(50) DEFAULT NULL",
    'notes' => "TEXT NULL",
    'smcode' => "VARCHAR(50) DEFAULT NULL",
    'cocode' => "VARCHAR(50) DEFAULT NULL",
    'care_of_name' => "VARCHAR(255) DEFAULT NULL",
    'care_of_party' => "ENUM('Y','N') DEFAULT 'N'",
    'pcard' => "VARCHAR(50) DEFAULT NULL",
    'pcardno' => "VARCHAR(50) DEFAULT NULL",
    'oppcardpoints' => "DECIMAL(10,2) DEFAULT NULL",
    'salary' => "DECIMAL(18,2) DEFAULT NULL",
    'cutrate' => "DECIMAL(10,2) DEFAULT NULL",
    'commission_pct' => "DECIMAL(10,2) DEFAULT NULL",
    'colncomn' => "DECIMAL(10,2) DEFAULT NULL",
    'staff_commission' => "DECIMAL(10,2) DEFAULT NULL",
    'id_number' => "VARCHAR(100) DEFAULT NULL",
    'pospwd' => "VARCHAR(100) DEFAULT NULL",
    'approval' => "VARCHAR(100) DEFAULT NULL",
    'agent' => "ENUM('Y','N') DEFAULT 'N'",
    'agentcode' => "VARCHAR(50) DEFAULT NULL",
    'contract_date' => "DATE DEFAULT NULL",
    'adate' => "DATE DEFAULT NULL",
    'duedate' => "DATE DEFAULT NULL",
    'opbalance' => "DECIMAL(18,2) DEFAULT 0",
    'opbalanceb' => "DECIMAL(18,2) DEFAULT 0",
    'balance_type' => "ENUM('dr','cr') DEFAULT 'cr'",
    'secondary_balance_type' => "ENUM('dr','cr') DEFAULT 'cr'",
    'control' => "TINYINT DEFAULT 1",
    'removed' => "ENUM('Y','N') DEFAULT 'N'",
    'blocked' => "ENUM('Y','N') DEFAULT 'N'",
    'display' => "ENUM('Y','N') DEFAULT 'Y'",
    'link_phonebook' => "ENUM('Y','N') DEFAULT 'N'",
    'print_card' => "ENUM('Y','N') DEFAULT 'N'",
    'show_camera' => "ENUM('Y','N') DEFAULT 'N'",
    'update_foreign' => "ENUM('Y','N') DEFAULT 'N'",
    'agent_staff' => "ENUM('Y','N') DEFAULT 'N'",
    'created_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP",
    'updated_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
];

foreach ($clientColumns as $column => $definition) {
    ensure_column($mysqli, 'clients', $column, $definition);
}

ensure_index($mysqli, 'clients', 'uniq_clients_agentcode', "UNIQUE KEY `uniq_clients_agentcode` (`agentcode`)");
ensure_index($mysqli, 'clients', 'idx_clients_mobile', "INDEX `idx_clients_mobile` (`mobile`)");
ensure_index($mysqli, 'clients', 'idx_clients_id_number', "INDEX `idx_clients_id_number` (`id_number`)");

// Backfill newly added customer columns
if ($mysqli->query("UPDATE customer_information SET customer_code = CONCAT('CUST-', LPAD(customer_id, 4, '0')) WHERE customer_code IS NULL OR customer_code = ''")) {
    echo "Backfilled customer_code for customer_information.\n";
} else {
    echo "Failed to backfill customer_code: {$mysqli->error}\n";
}
if ($mysqli->query("UPDATE customer_information SET phone = customer_mobile WHERE (phone IS NULL OR phone = '') AND customer_mobile IS NOT NULL")) {
    echo "Synced phone column with customer_mobile values.\n";
} else {
    echo "Failed syncing phone column: {$mysqli->error}\n";
}
if ($mysqli->query("UPDATE customer_information SET email = customer_email WHERE (email IS NULL OR email = '') AND customer_email IS NOT NULL")) {
    echo "Synced email column with customer_email values.\n";
} else {
    echo "Failed syncing email column: {$mysqli->error}\n";
}

if ($mysqli->query("UPDATE supplier_information SET supplier_code = CONCAT('SUP-', LPAD(supplier_id, 4, '0')) WHERE supplier_code IS NULL OR supplier_code = ''")) {
    echo "Backfilled supplier_code for supplier_information.\n";
} else {
    echo "Failed to backfill supplier_code: {$mysqli->error}\n";
}

$result = $mysqli->query("SELECT cvalue FROM generali WHERE code = 'PURCHASEB'");
if ($result && $result->num_rows === 0) {
    if ($mysqli->query("INSERT INTO generali (code, cvalue, description) VALUES ('PURCHASEB', 0, 'Legacy purchase bill counter')")) {
        echo "Seeded PURCHASEB counter in generali.\n";
    } else {
        echo "Failed seeding PURCHASEB counter: {$mysqli->error}\n";
    }
}

$generalsDefaults = [
    ['PBPREF', 'PUR-'],
    ['PBLEN', '5']
];
foreach ($generalsDefaults as $row) {
    [$code, $value] = $row;
    $stmt = $mysqli->prepare("INSERT INTO generals (`code`, `cvalue`) VALUES (?, ?) ON DUPLICATE KEY UPDATE cvalue = cvalue");
    if ($stmt) {
        $stmt->bind_param('ss', $code, $value);
        if ($stmt->execute()) {
            echo "Ensured generals key {$code}.\n";
        } else {
            echo "Failed seeding {$code} in generals: {$stmt->error}\n";
        }
        $stmt->close();
    }
}

// Seed generali defaults for auto-coding
$defaultConfigs = [
    ['CLIENT_AUTOCODE_CUSTOMER', json_encode(['enabled' => true, 'prefix' => 'C', 'next' => 1, 'padding' => 4]), 'Auto-code settings for customers'],
    ['CLIENT_AUTOCODE_SUPPLIER', json_encode(['enabled' => true, 'prefix' => 'S', 'next' => 1, 'padding' => 4]), 'Auto-code settings for suppliers']
];

foreach ($defaultConfigs as $configRow) {
    [$code, $value, $description] = $configRow;
    $stmt = $mysqli->prepare("INSERT INTO generali (`code`, `cvalue`, `description`) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE description = VALUES(description)");
    if ($stmt) {
        $stmt->bind_param('sss', $code, $value, $description);
        if ($stmt->execute()) {
            echo "Ensured generali key {$code}.\n";
        } else {
            echo "Failed seeding {$code}: {$stmt->error}\n";
        }
        $stmt->close();
    } else {
        echo "Failed preparing statement for {$code}: {$mysqli->error}\n";
    }
}

$legacyTableCheck = $mysqli->query("SHOW TABLES LIKE 'accounts'");
if ($legacyTableCheck && $legacyTableCheck->num_rows > 0) {
    echo "Migrating legacy accounts table into accountm...\n";
    $migrateSql = "
        INSERT INTO accountm (accode, name, actype1, reserve, note)
        SELECT a.account_code, a.account_name,
            CASE a.account_type
                WHEN 'asset' THEN 'A'
                WHEN 'liability' THEN 'L'
                WHEN 'income' THEN 'R'
                WHEN 'expense' THEN 'E'
                ELSE 'A'
            END as actype1,
            CASE WHEN a.is_system = 1 THEN 'Y' ELSE 'N' END as reserve,
            a.description
        FROM accounts a
        WHERE NOT EXISTS (
            SELECT 1 FROM accountm m
            WHERE m.accode COLLATE utf8mb4_unicode_ci = a.account_code COLLATE utf8mb4_unicode_ci
        )
    ";
    if ($mysqli->query($migrateSql)) {
        echo "Legacy accounts migrated.\n";
        if ($mysqli->query("DROP TABLE `accounts`")) {
            echo "Dropped legacy accounts table.\n";
        }
    } else {
        echo "Migration failed: " . $mysqli->error . "\n";
    }
}

echo "Schema alterations complete.\n";
$mysqli->close();
