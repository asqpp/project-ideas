<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_subgroups extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('ProductSubgroup_model');
        $this->load->model('ProductGroup_model');
    }

    public function index()
    {
        $page = (int) ($this->input->get('page') ?? 1);
        $search = $this->input->get('search') ?? '';

        $result = $this->ProductSubgroup_model->get_paginated(25, $page, $search);

        $data = [
            'page_title' => 'Product Subgroups',
            'subgroups' => $result->data,
            'pagination' => $result,
            'search' => $search,
            'main_content' => 'product_subgroups/index'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function add()
    {
        $this->handle_form();
    }

    public function edit($id)
    {
        $subgroup = $this->ProductSubgroup_model->get_by_id($id);
        if (!$subgroup) {
            show_404();
        }
        $this->handle_form($subgroup);
    }

    private function handle_form($subgroup = null): void
    {
        if ($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('subgroup_name', 'Subgroup Name', 'required|trim');
            $this->form_validation->set_rules('subgroup_code', 'Subgroup Code', 'required|trim|callback_validate_subgroup_code[' . ($subgroup->id ?? '') . ']');
            $this->form_validation->set_rules('group_id', 'Parent Group', 'required');

            if ($this->form_validation->run() === true) {
                $payload = [
                    'subgroup_name' => $this->input->post('subgroup_name'),
                    'subgroup_code' => strtoupper($this->input->post('subgroup_code')),
                    'group_id' => $this->input->post('group_id'),
                    'description' => $this->input->post('description'),
                    'status' => $this->input->post('status') ? 1 : 0
                ];

                if ($subgroup) {
                    $this->ProductSubgroup_model->update($subgroup->id, $payload);
                    $this->session->set_flashdata('success', 'Subgroup updated successfully.');
                } else {
                    $this->ProductSubgroup_model->insert($payload);
                    $this->session->set_flashdata('success', 'Subgroup created successfully.');
                }

                redirect('product_subgroups');
            }
        }

        $data = [
            'page_title' => $subgroup ? 'Edit Subgroup' : 'Add Subgroup',
            'subgroup' => $subgroup,
            'groups' => $this->ProductGroup_model->get_all(),
            'main_content' => 'product_subgroups/form'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function delete($id)
    {
        $subgroup = $this->ProductSubgroup_model->get_by_id($id);
        if (!$subgroup) {
            show_404();
        }

        $this->db->where('subgroup_id', $id);
        $product_count = $this->db->count_all_results('product_information');
        if ($product_count > 0) {
            $this->session->set_flashdata('error', 'Cannot delete subgroup. Products are linked to it.');
            redirect('product_subgroups');
        }

        $this->ProductSubgroup_model->delete($id);
        $this->session->set_flashdata('success', 'Subgroup deleted successfully.');
        redirect('product_subgroups');
    }

    public function validate_subgroup_code($code, $id = null)
    {
        $code = strtoupper($code);
        if ($this->ProductSubgroup_model->code_exists($code, $id ? (int) $id : null)) {
            $this->form_validation->set_message('validate_subgroup_code', 'The {field} must be unique.');
            return false;
        }
        return true;
    }
}
