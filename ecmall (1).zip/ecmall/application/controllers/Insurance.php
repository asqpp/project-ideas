<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Insurance extends CI_Controller
{
    private $pages = [];

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->load->model('Insurance_model');
        $this->load->model('Customer_model');
        $this->load->model('Product_model');
        $this->load->model('Agent_model');
        $this->load->model('Broker_model');
        $this->load->model('Invoice_model');
        $this->load->library('form_validation');

        $this->pages = $this->buildPages();
    }

    private function buildPages(): array
    {
        $defaultActions = [
            ['label' => 'Save Draft', 'variant' => 'outline', 'icon' => 'fas fa-save'],
            ['label' => 'Submit Workflow', 'variant' => 'primary', 'icon' => 'fas fa-paper-plane']
        ];

        return [
            'policy_management' => [
                'title' => 'Policy Management',
                'description' => 'Create, endorse and track policies with instant validation and renewal alerts across company and branch hierarchies.',
                'form' => [
                    'title' => 'Policy Workspace',
                    'subtitle' => 'Capture customer, coverage and premium details in one place.',
                    'fields' => [
                        ['label' => 'Policy Number', 'name' => 'policy_number', 'placeholder' => 'e.g. POL-2025-00045'],
                        ['label' => 'Customer', 'name' => 'customer_id', 'type' => 'select', 'options' => ['Choose Customer', 'Corporate', 'Individual']],
                        ['label' => 'Product / Plan', 'name' => 'product_id', 'type' => 'select', 'options' => ['Motor Comprehensive', 'Medical Gold', 'Property TSI']],
                        ['label' => 'Effective Date', 'name' => 'effective_date', 'type' => 'date'],
                        ['label' => 'Expiry Date', 'name' => 'expiry_date', 'type' => 'date'],
                        ['label' => 'Premium Amount', 'name' => 'premium_amount', 'type' => 'currency'],
                        ['label' => 'Payment Mode', 'name' => 'payment_mode', 'type' => 'select', 'options' => ['Cash', 'Bank Transfer', 'Cheque'], 'placeholder' => 'Select mode'],
                        ['label' => 'Policy Status', 'name' => 'status', 'type' => 'select', 'options' => ['Draft', 'Active', 'Lapsed', 'Cancelled']]
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Active Policies', 'value' => '1,248', 'trend' => '+5.6% vs LY', 'trend_positive' => true, 'icon' => 'fas fa-shield'],
                    ['label' => 'Renewals Due (30d)', 'value' => '74', 'trend' => '31 high priority', 'icon' => 'fas fa-rotate'],
                    ['label' => 'Pending Endorsements', 'value' => '42', 'icon' => 'fas fa-edit'],
                    ['label' => 'Outstanding Premium', 'value' => 'AED 182K', 'icon' => 'fas fa-money-bill-wave']
                ],
                'checklist' => [
                    ['label' => 'Customer KYC Complete', 'description' => 'Trade license, IDs & VAT verified'],
                    ['label' => 'Cover Note Issued', 'description' => 'Auto-generated and emailed to client'],
                    ['label' => 'Premium Allocation Posted', 'description' => 'Double-entry synced with accounting module']
                ],
                'activity' => [
                    ['timestamp' => '09:42 AM', 'title' => 'Renewal reminder sent', 'description' => 'Email + in-app notification delivered'],
                    ['timestamp' => 'Yesterday', 'title' => 'Endorsement approved', 'description' => 'Sum assured revised by NA-FIX Admin']
                ],
                'supporting' => [
                    [
                        'title' => 'Account Structure',
                        'icon' => 'fas fa-sitemap',
                        'description' => 'Welcome to Insurance ERP – modern navigation system with organized reports and account structure.',
                        'items' => [
                            ['label' => 'Dashboard', 'description' => 'Overview, company & branch insights with real-time notifications.'],
                            ['label' => 'Masters', 'description' => 'Manage customers, agents, brokers, suppliers & products.']
                        ]
                    ],
                    [
                        'title' => 'Workflow Stages',
                        'icon' => 'fas fa-stream',
                        'items' => [
                            ['label' => 'Create & Validate', 'description' => 'Capture policy header and verify underwriting rules.'],
                            ['label' => 'Quote & Bind', 'description' => 'Issue quotation, confirm acceptance and bind policy.'],
                            ['label' => 'Issue & Notify', 'description' => 'Generate policy schedule, notify customer and accounts.']
                        ]
                    ]
                ]
            ],
            'claims_management' => [
                'title' => 'Claims Management',
                'description' => 'Track FNOL through settlement with status driven workflows, SLA alerts and reserve monitoring.',
                'form' => [
                    'title' => 'Claim Registration',
                    'subtitle' => 'Capture incident, coverage and reserve details.',
                    'fields' => [
                        ['label' => 'Claim Number', 'name' => 'claim_number', 'placeholder' => 'e.g. CLM-2025-0031'],
                        ['label' => 'Policy Reference', 'name' => 'policy_reference', 'type' => 'select', 'options' => []],
                        ['label' => 'Date of Loss', 'name' => 'loss_date', 'type' => 'date'],
                        ['label' => 'Loss Type', 'name' => 'loss_type', 'type' => 'select', 'options' => ['Motor', 'Medical', 'Property', 'Life']],
                        ['label' => 'Reserve Amount', 'name' => 'reserve_amount', 'type' => 'currency'],
                        ['label' => 'Adjuster', 'name' => 'adjuster', 'type' => 'select', 'options' => ['In-house', 'Third Party']],
                        ['label' => 'Claim Status', 'name' => 'claim_status', 'type' => 'select', 'options' => ['Registered', 'Assessment', 'Approved', 'Rejected']],
                        ['label' => 'Narration', 'name' => 'narration', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Open Claims', 'value' => '219', 'trend' => '-3.1% month', 'trend_positive' => true, 'icon' => 'fas fa-briefcase-medical'],
                    ['label' => 'Average SLA', 'value' => '6.4 days', 'icon' => 'fas fa-stopwatch'],
                    ['label' => 'Reserve vs Paid', 'value' => '71%', 'icon' => 'fas fa-scale-unbalanced'],
                    ['label' => 'Alerts', 'value' => '9 escalations', 'icon' => 'fas fa-bell']
                ],
                'checklist' => [
                    ['label' => 'FNOL Logged', 'description' => 'First notification captured with timestamp'],
                    ['label' => 'Documents Received', 'description' => 'Photos, claim form & police report'],
                    ['label' => 'Reserve Approved', 'description' => 'Finance notified with entry reference']
                ],
                'activity' => [
                    ['timestamp' => 'Today 11:05 AM', 'title' => 'Assessment completed', 'description' => 'Workshop uploaded estimate'],
                    ['timestamp' => 'Yesterday 04:17 PM', 'title' => 'Reserve adjustment', 'description' => 'AED 4,500 additional reserve approved']
                ]
            ],
            'underwriting' => [
                'title' => 'Underwriting',
                'description' => 'Centralize risk evaluation, rating factors and approval notes with structured templates.',
                'form' => [
                    'title' => 'Risk Evaluation Sheet',
                    'fields' => [
                        ['label' => 'Submission Reference', 'name' => 'submission_ref', 'placeholder' => 'e.g. SUB-2025-012'],
                        ['label' => 'Broker / Agent', 'name' => 'channel_type', 'type' => 'select', 'options' => ['Direct', 'Broker', 'Agent']],
                        ['label' => 'Risk Category', 'name' => 'risk_category', 'type' => 'select', 'options' => ['Low', 'Medium', 'High', 'Critical']],
                        ['label' => 'Sum Assured', 'name' => 'sum_assured', 'type' => 'currency'],
                        ['label' => 'Base Rate %', 'name' => 'base_rate', 'type' => 'number', 'placeholder' => 'e.g. 1.25'],
                        ['label' => 'Loading / Discount %', 'name' => 'loading', 'type' => 'number'],
                        ['label' => 'UW Decision', 'name' => 'decision', 'type' => 'select', 'options' => ['Pending', 'Approved', 'Referral', 'Declined']],
                        ['label' => 'Remarks', 'name' => 'remarks', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Submissions Today', 'value' => '36', 'icon' => 'fas fa-inbox'],
                    ['label' => 'Referral Queue', 'value' => '12', 'icon' => 'fas fa-random'],
                    ['label' => 'Average Rate', 'value' => '1.82%', 'icon' => 'fas fa-percent'],
                    ['label' => 'Cases Pending >24h', 'value' => '4', 'icon' => 'fas fa-hourglass-half']
                ],
                'checklist' => [
                    ['label' => 'Proposal Signed', 'description' => 'Digital signature captured'],
                    ['label' => 'Medical Reports', 'description' => 'Uploaded to document vault'],
                    ['label' => 'Peer Review', 'description' => 'Second level approval recorded']
                ]
            ],
            'premium_collection' => [
                'title' => 'Premium Collection',
                'description' => 'Automate premium schedules, receipts and outstanding follow-ups with direct link to accounting.',
                'form' => [
                    'title' => 'Premium Allocation',
                    'fields' => [
                        ['label' => 'Reference Type', 'name' => 'reference_type', 'type' => 'select', 'options' => ['Policy', 'Invoice']],
                        ['label' => 'Policy / Invoice', 'name' => 'reference', 'type' => 'select', 'options' => []],
                        ['label' => 'Due Date', 'name' => 'due_date', 'type' => 'date'],
                        ['label' => 'Installment #', 'name' => 'installment_no', 'type' => 'number'],
                        ['label' => 'Due Amount', 'name' => 'due_amount', 'type' => 'currency'],
                        ['label' => 'Receipt Type', 'name' => 'receipt_type', 'type' => 'select', 'options' => ['Cash', 'Transfer', 'Cheque']],
                        ['label' => 'Collection Owner', 'name' => 'collection_owner', 'type' => 'select', 'options' => ['Collections', 'Finance', 'Agent']],
                        ['label' => 'Remarks', 'name' => 'remarks', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Allocate Receipt', 'variant' => 'primary', 'icon' => 'fas fa-link'],
                        ['label' => 'Send Reminder', 'variant' => 'outline', 'icon' => 'fas fa-envelope']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Collected MTD', 'value' => 'AED 1.38M', 'trend' => '+12% vs target', 'trend_positive' => true, 'icon' => 'fas fa-sack-dollar'],
                    ['label' => 'Overdue Installments', 'value' => '18', 'icon' => 'fas fa-exclamation-circle'],
                    ['label' => 'Auto Reminders', 'value' => '53 scheduled', 'icon' => 'fas fa-clock']
                ],
                'checklist' => [
                    ['label' => 'Receipt Posted', 'description' => 'Journal voucher created with reference'],
                    ['label' => 'Allocation Verified', 'description' => 'Reconciled against invoice balance'],
                    ['label' => 'Notification Sent', 'description' => 'Email/SMS confirmation delivered']
                ]
            ],
            'commission_processing' => [
                'title' => 'Commission Processing',
                'description' => 'Calculate and release commissions for brokers and agents with multi-tier slabs.',
                'form' => [
                    'title' => 'Commission Worksheet',
                    'fields' => [
                        ['label' => 'Partner Type', 'name' => 'partner_type', 'type' => 'select', 'options' => ['Broker', 'Agent', 'Aggregator']],
                        ['label' => 'Partner Name', 'name' => 'partner_name', 'type' => 'select', 'options' => []],
                        ['label' => 'Policy Reference', 'name' => 'policy_number', 'placeholder' => 'Linked policy'],
                        ['label' => 'Commission %', 'name' => 'commission_pct', 'type' => 'number'],
                        ['label' => 'Commission Amount', 'name' => 'commission_amount', 'type' => 'currency'],
                        ['label' => 'Payable On', 'name' => 'payable_on', 'type' => 'date'],
                        ['label' => 'Approval Status', 'name' => 'approval_status', 'type' => 'select', 'options' => ['Pending', 'Approved', 'On Hold']],
                        ['label' => 'Notes', 'name' => 'notes', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Payable this week', 'value' => 'AED 214K', 'icon' => 'fas fa-money-check-alt'],
                    ['label' => 'Pending Approvals', 'value' => '7', 'icon' => 'fas fa-user-check'],
                    ['label' => 'Discrepancies', 'value' => '2 flagged', 'icon' => 'fas fa-flag']
                ],
                'checklist' => [
                    ['label' => 'Policy Paid', 'description' => 'Premium receipt confirmed'],
                    ['label' => 'Split Verified', 'description' => 'Tier + Override validated'],
                    ['label' => 'Accounts Posted', 'description' => 'Journal entry ready for release']
                ]
            ],
            'renewals' => [
                'title' => 'Renewals',
                'description' => 'Automated renewal board with ageing, task owners and cross-sell recommendations.',
                'form' => [
                    'title' => 'Renewal Planner',
                    'fields' => [
                        ['label' => 'Policy Number', 'name' => 'policy_number', 'type' => 'select', 'options' => []],
                        ['label' => 'Current Expiry', 'name' => 'current_expiry', 'type' => 'date'],
                        ['label' => 'Renewal Category', 'name' => 'category', 'type' => 'select', 'options' => ['Auto', 'Medical', 'Property']],
                        ['label' => 'Assigned To', 'name' => 'assigned_to', 'type' => 'select', 'options' => ['Renewal Desk', 'Agent', 'Broker']],
                        ['label' => 'Proposed Premium', 'name' => 'proposed_premium', 'type' => 'currency'],
                        ['label' => 'Follow-up Date', 'name' => 'follow_up_date', 'type' => 'date'],
                        ['label' => 'Customer Feedback', 'name' => 'feedback', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Send Proposal', 'variant' => 'primary', 'icon' => 'fas fa-file-signature'],
                        ['label' => 'Log Activity', 'variant' => 'outline', 'icon' => 'fas fa-clipboard-list']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Renewals due (60d)', 'value' => '138', 'icon' => 'fas fa-calendar-alt'],
                    ['label' => 'Converted', 'value' => '64%', 'trend' => '+8% YoY', 'trend_positive' => true, 'icon' => 'fas fa-chart-line'],
                    ['label' => 'At Risk', 'value' => '19', 'icon' => 'fas fa-exclamation-triangle']
                ]
            ],
            'endorsements' => [
                'title' => 'Endorsements',
                'description' => 'Issue mid-term policy changes with tracked approvals, versioning and notifications.',
                'form' => [
                    'title' => 'Endorsement Request',
                    'fields' => [
                        ['label' => 'Policy Number', 'name' => 'policy_number', 'type' => 'select', 'options' => []],
                        ['label' => 'Endorsement Type', 'name' => 'endorsement_type', 'type' => 'select', 'options' => ['Addition', 'Cancellation', 'Correction', 'Benefit Change']],
                        ['label' => 'Effective Date', 'name' => 'effective_date', 'type' => 'date'],
                        ['label' => 'Premium Impact', 'name' => 'premium_impact', 'type' => 'currency', 'helper' => 'Use negative values for refunds'],
                        ['label' => 'Approval Route', 'name' => 'approval_route', 'type' => 'select', 'options' => ['Operations', 'Underwriting', 'Finance']],
                        ['label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Endorsements this month', 'value' => '58', 'icon' => 'fas fa-pencil-alt'],
                    ['label' => 'Average turnaround', 'value' => '4.3 hrs', 'icon' => 'fas fa-hourglass'],
                    ['label' => 'Pending approvals', 'value' => '6', 'icon' => 'fas fa-user-lock']
                ],
                'checklist' => [
                    ['label' => 'Supporting Docs', 'description' => 'Attachments uploaded to record'],
                    ['label' => 'Premium Posted', 'description' => 'Adjusting entry generated'],
                    ['label' => 'Customer Notified', 'description' => 'Notification + PDF sent']
                ]
            ]
        ];
    }

    private function default_form_actions(): array
    {
        return [
            ['label' => 'Save', 'variant' => 'primary', 'icon' => 'fas fa-save'],
            ['label' => 'Reset', 'variant' => 'outline', 'icon' => 'fas fa-undo']
        ];
    }

    private function hydrate_form_config(string $slug, array $form): array
    {
        $fields = $form['fields'] ?? [];

        switch ($slug) {
            case 'policy_management':
                $fields = $this->inject_select_options($fields, 'customer_id', $this->customer_options(), 'Select customer');
                $fields = $this->inject_select_options($fields, 'product_id', $this->product_options(), 'Select product');
                $fields = $this->inject_select_options($fields, 'status', $this->enum_options(['Draft', 'Active', 'Lapsed', 'Cancelled']));
                break;
            case 'claims_management':
                $fields = $this->inject_select_options($fields, 'policy_reference', $this->policy_dropdown(), 'Select policy');
                $fields = $this->inject_select_options($fields, 'claim_status', $this->enum_options(['Registered', 'Assessment', 'Approved', 'Rejected']));
                break;
            case 'underwriting':
                $fields = $this->inject_select_options($fields, 'channel_type', $this->enum_options(['Direct', 'Broker', 'Agent']));
                $fields = $this->inject_select_options($fields, 'risk_category', $this->enum_options(['Low', 'Medium', 'High', 'Critical']));
                $fields = $this->inject_select_options($fields, 'decision', $this->enum_options(['Pending', 'Approved', 'Referral', 'Declined']));
                break;
            case 'premium_collection':
                $fields = $this->inject_select_options($fields, 'reference_type', $this->enum_options(['Policy', 'Invoice']));
                $fields = $this->inject_select_options($fields, 'reference', $this->policy_invoice_dropdown(), 'Select reference');
                $fields = $this->inject_select_options($fields, 'receipt_type', $this->enum_options(['Cash', 'Transfer', 'Cheque']));
                $fields = $this->inject_select_options($fields, 'collection_owner', $this->enum_options(['Collections', 'Finance', 'Agent']));
                break;
            case 'commission_processing':
                $fields = $this->inject_select_options($fields, 'partner_name', $this->partner_dropdown(), 'Select partner');
                $fields = $this->inject_select_options($fields, 'approval_status', $this->enum_options(['Pending', 'Approved', 'On Hold']));
                break;
            case 'renewals':
                $fields = $this->inject_select_options($fields, 'policy_number', $this->policy_dropdown(), 'Select policy');
                $fields = $this->inject_select_options($fields, 'category', $this->enum_options(['Auto', 'Medical', 'Property']));
                break;
            case 'endorsements':
                $fields = $this->inject_select_options($fields, 'policy_number', $this->policy_dropdown(), 'Select policy');
                $fields = $this->inject_select_options($fields, 'endorsement_type', $this->enum_options(['Addition', 'Cancellation', 'Correction', 'Benefit Change']));
                $fields = $this->inject_select_options($fields, 'approval_route', $this->enum_options(['Operations', 'Underwriting', 'Finance']));
                break;
        }

        $form['fields'] = $fields;
        $form['action'] = current_url();
        $form['method'] = 'post';

        return $form;
    }

    private function process_form_submission(string $slug): void
    {
        if ($this->input->method() !== 'post') {
            return;
        }

        switch ($slug) {
            case 'policy_management':
                $this->form_validation->set_rules('policy_number', 'Policy Number', 'required|trim');
                $this->form_validation->set_rules('customer_id', 'Customer', 'required|integer');
                $this->form_validation->set_rules('product_id', 'Product', 'required|integer');
                $this->form_validation->set_rules('effective_date', 'Effective Date', 'required');
                $this->form_validation->set_rules('expiry_date', 'Expiry Date', 'required');
                $this->form_validation->set_rules('premium_amount', 'Premium Amount', 'required|numeric');
                $this->form_validation->set_rules('payment_mode', 'Payment Mode', 'required');
                $this->form_validation->set_rules('status', 'Status', 'required');

                if ($this->form_validation->run()) {
                    $this->Insurance_model->create_policy([
                        'policy_number' => $this->input->post('policy_number', TRUE),
                        'customer_id' => (int) $this->input->post('customer_id'),
                        'product_id' => (int) $this->input->post('product_id'),
                        'effective_date' => $this->input->post('effective_date'),
                        'expiry_date' => $this->input->post('expiry_date'),
                        'premium_amount' => $this->decimal_input('premium_amount'),
                        'payment_mode' => $this->input->post('payment_mode', TRUE),
                        'status' => $this->input->post('status', TRUE)
                    ]);
                    $this->session->set_flashdata('success', 'Policy saved successfully.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;

            case 'claims_management':
                $this->form_validation->set_rules('claim_number', 'Claim Number', 'required|trim');
                $this->form_validation->set_rules('policy_reference', 'Policy Reference', 'required');
                $this->form_validation->set_rules('loss_date', 'Date of Loss', 'required');
                $this->form_validation->set_rules('loss_type', 'Loss Type', 'required');
                $this->form_validation->set_rules('reserve_amount', 'Reserve Amount', 'numeric');
                $this->form_validation->set_rules('claim_status', 'Claim Status', 'required');

                if ($this->form_validation->run()) {
                    $policy_number = $this->input->post('policy_reference', TRUE);
                    $policy = $this->Insurance_model->get_policy_by_number($policy_number);

                    $this->Insurance_model->create_claim([
                        'claim_number' => $this->input->post('claim_number', TRUE),
                        'policy_id' => $policy->id ?? null,
                        'policy_number' => $policy_number,
                        'customer_id' => $policy->customer_id ?? null,
                        'loss_date' => $this->input->post('loss_date'),
                        'loss_type' => $this->input->post('loss_type', TRUE),
                        'reserve_amount' => $this->decimal_input('reserve_amount'),
                        'adjuster' => $this->input->post('adjuster', TRUE),
                        'status' => $this->input->post('claim_status', TRUE),
                        'narration' => $this->input->post('narration', TRUE)
                    ]);

                    $this->session->set_flashdata('success', 'Claim registered successfully.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;

            case 'underwriting':
                $this->form_validation->set_rules('submission_ref', 'Submission Reference', 'required|trim');
                $this->form_validation->set_rules('channel_type', 'Broker / Agent', 'required');
                $this->form_validation->set_rules('risk_category', 'Risk Category', 'required');
                $this->form_validation->set_rules('sum_assured', 'Sum Assured', 'required|numeric');
                $this->form_validation->set_rules('base_rate', 'Base Rate %', 'numeric');
                $this->form_validation->set_rules('loading', 'Loading / Discount %', 'numeric');
                $this->form_validation->set_rules('decision', 'Decision', 'required');

                if ($this->form_validation->run()) {
                    $this->Insurance_model->create_underwriting([
                        'submission_ref' => $this->input->post('submission_ref', TRUE),
                        'channel_type' => $this->input->post('channel_type', TRUE),
                        'risk_category' => $this->input->post('risk_category', TRUE),
                        'sum_assured' => $this->decimal_input('sum_assured'),
                        'base_rate' => $this->decimal_input('base_rate'),
                        'loading' => $this->decimal_input('loading'),
                        'decision' => $this->input->post('decision', TRUE),
                        'remarks' => $this->input->post('remarks', TRUE)
                    ]);
                    $this->session->set_flashdata('success', 'Underwriting record captured.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;

            case 'premium_collection':
                $this->form_validation->set_rules('reference_type', 'Reference Type', 'required');
                $this->form_validation->set_rules('reference', 'Reference', 'required');
                $this->form_validation->set_rules('due_date', 'Due Date', 'required');
                $this->form_validation->set_rules('installment_no', 'Installment #', 'integer');
                $this->form_validation->set_rules('due_amount', 'Due Amount', 'required|numeric');
                $this->form_validation->set_rules('receipt_type', 'Receipt Type', 'required');
                $this->form_validation->set_rules('collection_owner', 'Collection Owner', 'required');

                if ($this->form_validation->run()) {
                    $this->Insurance_model->create_premium_collection([
                        'reference_type' => strtolower($this->input->post('reference_type', TRUE)),
                        'reference_id' => $this->input->post('reference', TRUE),
                        'due_date' => $this->input->post('due_date'),
                        'installment_no' => (int) $this->input->post('installment_no'),
                        'due_amount' => $this->decimal_input('due_amount'),
                        'receipt_type' => $this->input->post('receipt_type', TRUE),
                        'collection_owner' => $this->input->post('collection_owner', TRUE),
                        'remarks' => $this->input->post('remarks', TRUE),
                        'status' => 'Pending'
                    ]);
                    $this->session->set_flashdata('success', 'Premium schedule saved.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;

            case 'commission_processing':
                $this->form_validation->set_rules('partner_type', 'Partner Type', 'required');
                $this->form_validation->set_rules('partner_name', 'Partner Name', 'required');
                $this->form_validation->set_rules('policy_number', 'Policy Reference', 'required');
                $this->form_validation->set_rules('commission_pct', 'Commission %', 'numeric');
                $this->form_validation->set_rules('commission_amount', 'Commission Amount', 'required|numeric');
                $this->form_validation->set_rules('payable_on', 'Payable On', 'required');
                $this->form_validation->set_rules('approval_status', 'Approval Status', 'required');

                if ($this->form_validation->run()) {
                    $this->Insurance_model->create_commission([
                        'partner_type' => strtolower($this->input->post('partner_type', TRUE)),
                        'partner_name' => $this->input->post('partner_name', TRUE),
                        'policy_number' => $this->input->post('policy_number', TRUE),
                        'commission_pct' => $this->decimal_input('commission_pct'),
                        'commission_amount' => $this->decimal_input('commission_amount'),
                        'payable_on' => $this->input->post('payable_on'),
                        'approval_status' => $this->input->post('approval_status', TRUE),
                        'notes' => $this->input->post('notes', TRUE)
                    ]);
                    $this->session->set_flashdata('success', 'Commission calculated.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;

            case 'renewals':
                $this->form_validation->set_rules('policy_number', 'Policy Number', 'required');
                $this->form_validation->set_rules('current_expiry', 'Current Expiry', 'required');
                $this->form_validation->set_rules('category', 'Category', 'required');
                $this->form_validation->set_rules('assigned_to', 'Assigned To', 'required');
                $this->form_validation->set_rules('proposed_premium', 'Proposed Premium', 'numeric');
                $this->form_validation->set_rules('follow_up_date', 'Follow-up Date', 'required');

                if ($this->form_validation->run()) {
                    $this->Insurance_model->create_renewal([
                        'policy_number' => $this->input->post('policy_number', TRUE),
                        'current_expiry' => $this->input->post('current_expiry'),
                        'category' => $this->input->post('category', TRUE),
                        'assigned_to' => $this->input->post('assigned_to', TRUE),
                        'proposed_premium' => $this->decimal_input('proposed_premium'),
                        'follow_up_date' => $this->input->post('follow_up_date'),
                        'feedback' => $this->input->post('feedback', TRUE),
                        'status' => 'Planned'
                    ]);
                    $this->session->set_flashdata('success', 'Renewal planner updated.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;

            case 'endorsements':
                $this->form_validation->set_rules('policy_number', 'Policy Number', 'required');
                $this->form_validation->set_rules('endorsement_type', 'Endorsement Type', 'required');
                $this->form_validation->set_rules('effective_date', 'Effective Date', 'required');
                $this->form_validation->set_rules('premium_impact', 'Premium Impact', 'numeric');
                $this->form_validation->set_rules('approval_route', 'Approval Route', 'required');
                $this->form_validation->set_rules('description', 'Description', 'required');

                if ($this->form_validation->run()) {
                    $this->Insurance_model->create_endorsement([
                        'policy_number' => $this->input->post('policy_number', TRUE),
                        'endorsement_type' => $this->input->post('endorsement_type', TRUE),
                        'effective_date' => $this->input->post('effective_date'),
                        'premium_impact' => $this->decimal_input('premium_impact'),
                        'approval_route' => $this->input->post('approval_route', TRUE),
                        'description' => $this->input->post('description', TRUE),
                        'status' => 'Pending'
                    ]);
                    $this->session->set_flashdata('success', 'Endorsement request logged.');
                    redirect(current_url());
                }
                $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
                break;
        }
    }

    private function resolve_meta_cards(string $slug, array $defaults): array
    {
        switch ($slug) {
            case 'policy_management':
                $metrics = $this->Insurance_model->get_policy_metrics();
                return [
                    ['label' => 'Active Policies', 'value' => number_format($metrics['active'] ?? 0), 'icon' => 'fas fa-shield'],
                    ['label' => 'Renewals Due (30d)', 'value' => number_format($metrics['renewal_due'] ?? 0), 'icon' => 'fas fa-rotate'],
                    ['label' => 'Pending Endorsements', 'value' => number_format($metrics['pending_endorsements'] ?? 0), 'icon' => 'fas fa-edit'],
                    ['label' => 'Outstanding Premium', 'value' => 'AED ' . number_format($metrics['outstanding_premium'] ?? 0, 2), 'icon' => 'fas fa-money-bill-wave']
                ];
            case 'claims_management':
                $open_claims = $this->Insurance_model->count_where(Insurance_model::TABLE_CLAIMS, ['status' => 'Assessment']);
                return [
                    ['label' => 'Total Claims', 'value' => number_format($this->Insurance_model->count_where(Insurance_model::TABLE_CLAIMS)), 'icon' => 'fas fa-briefcase-medical'],
                    ['label' => 'In Assessment', 'value' => number_format($open_claims), 'icon' => 'fas fa-search'],
                    ['label' => 'Average Reserve', 'value' => 'AED ' . number_format($this->Insurance_model->sum_column(Insurance_model::TABLE_CLAIMS, 'reserve_amount') ?? 0, 2), 'icon' => 'fas fa-scale-balanced'],
                ];
            case 'premium_collection':
                return [
                    ['label' => 'Pending Installments', 'value' => number_format($this->Insurance_model->count_where(Insurance_model::TABLE_PREMIUM_COLLECTIONS, ['status' => 'Pending'])), 'icon' => 'fas fa-clock'],
                    ['label' => 'Collected', 'value' => 'AED ' . number_format($this->Insurance_model->sum_column(Insurance_model::TABLE_PREMIUM_COLLECTIONS, 'due_amount', ['status' => 'Collected']) ?? 0, 2), 'icon' => 'fas fa-circle-check'],
                    ['label' => 'Outstanding', 'value' => 'AED ' . number_format($this->Insurance_model->sum_column(Insurance_model::TABLE_PREMIUM_COLLECTIONS, 'due_amount', ['status' => 'Pending']) ?? 0, 2), 'icon' => 'fas fa-triangle-exclamation']
                ];
            default:
                return $defaults;
        }
    }

    private function inject_select_options(array $fields, string $name, array $options, string $placeholder = '')
    {
        foreach ($fields as &$field) {
            if (($field['name'] ?? '') === $name) {
                $field['type'] = 'select';
                $field['options'] = $options;
                if (!empty($placeholder)) {
                    $field['placeholder'] = $placeholder;
                }
                break;
            }
        }
        return $fields;
    }

    private function customer_options(): array
    {
        $this->db->select('customer_id, customer_name, customer_mobile');
        $this->db->from('customer_information');
        $this->db->order_by('customer_name', 'ASC');

        return array_map(function ($row) {
            $suffix = $row->customer_mobile ? ' - ' . $row->customer_mobile : '';
            return [
                'value' => $row->customer_id,
                'label' => trim($row->customer_name . $suffix)
            ];
        }, $this->db->get()->result());
    }

    private function product_options(): array
    {
        $this->db->select('product_id, product_name, product_model');
        $this->db->from('product_information');
        $this->db->order_by('product_name', 'ASC');

        return array_map(function ($row) {
            return [
                'value' => $row->product_id,
                'label' => trim($row->product_name . ' ' . ($row->product_model ?? ''))
            ];
        }, $this->db->get()->result());
    }

    private function policy_dropdown(): array
    {
        $policies = $this->Insurance_model->get_policy_dropdown();
        return array_map(function ($row) {
            return ['value' => $row->policy_number, 'label' => 'Policy - ' . $row->policy_number];
        }, $policies);
    }

    private function policy_invoice_dropdown(): array
    {
        $options = $this->policy_dropdown();

        $this->db->select('invoice_id, invoice as reference');
        $this->db->from('invoice');
        $this->db->order_by('invoice_id', 'DESC');
        foreach ($this->db->get()->result() as $invoice) {
            $options[] = [
                'value' => 'INV:' . $invoice->invoice,
                'label' => 'Invoice ' . $invoice->invoice
            ];
        }

        return $options;
    }

    private function partner_dropdown(): array
    {
        $options = [];

        $this->db->select('agent_id, agent_name');
        $this->db->from('agent');
        $this->db->order_by('agent_name', 'ASC');
        foreach ($this->db->get()->result() as $agent) {
            $options[] = [
                'value' => $agent->agent_name,
                'label' => 'Agent - ' . $agent->agent_name
            ];
        }

        $this->db->select('broker_id, broker_name');
        $this->db->from('broker');
        $this->db->order_by('broker_name', 'ASC');
        foreach ($this->db->get()->result() as $broker) {
            $options[] = [
                'value' => $broker->broker_name,
                'label' => 'Broker - ' . $broker->broker_name
            ];
        }

        return $options;
    }

    private function enum_options(array $values): array
    {
        return array_map(function ($value) {
            return ['value' => $value, 'label' => $value];
        }, $values);
    }

    private function decimal_input(string $key): float
    {
        $raw = (string) $this->input->post($key);
        $value = str_replace(',', '', $raw);
        return (float) ($value !== '' ? $value : 0);
    }

    private function render(string $slug): void
    {
        if (!isset($this->pages[$slug])) {
            show_404();
        }

        $this->process_form_submission($slug);

        $config = $this->pages[$slug];
        $form_config = $this->hydrate_form_config($slug, $config['form'] ?? []);

        $data = [
            'page_title' => $config['title'],
            'page_description' => $config['description'],
            'form_title' => $form_config['title'] ?? $config['title'],
            'form_subtitle' => $form_config['subtitle'] ?? '',
            'form_badge' => $form_config['badge'] ?? '',
            'form_layout' => $form_config['layout'] ?? 'grid-cols-1 md:grid-cols-2',
            'form_fields' => $form_config['fields'] ?? [],
            'form_actions' => $form_config['actions'] ?? $this->default_form_actions(),
            'form_action' => $form_config['action'] ?? current_url(),
            'form_method' => $form_config['method'] ?? 'post',
            'meta_cards' => $this->resolve_meta_cards($slug, $config['meta_cards'] ?? []),
            'checklist' => $config['checklist'] ?? [],
            'activity_timeline' => $config['activity'] ?? [],
            'supporting_sections' => $config['supporting'] ?? [],
            'main_content' => 'shared/dynamic_form',
            'active_menu' => 'insurance'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function policy_management()
    {
        $this->render('policy_management');
    }

    public function claims_management()
    {
        $this->render('claims_management');
    }

    public function underwriting()
    {
        $this->render('underwriting');
    }

    public function premium_collection()
    {
        $this->render('premium_collection');
    }

    public function commission_processing()
    {
        $this->render('commission_processing');
    }

    public function renewals()
    {
        $this->render('renewals');
    }

    public function endorsements()
    {
        $this->render('endorsements');
    }
}
