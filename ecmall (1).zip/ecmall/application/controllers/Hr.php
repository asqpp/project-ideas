<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hr extends CI_Controller
{
    private $pages = [];

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->load->model('Hr_model');
        $this->load->library('form_validation');

        $this->pages = $this->buildPages();
    }

    private function buildPages(): array
    {
        $defaultActions = [
            ['label' => 'Save Changes', 'variant' => 'primary', 'icon' => 'fas fa-save'],
            ['label' => 'Schedule Workflow', 'variant' => 'outline', 'icon' => 'fas fa-calendar-check']
        ];

        return [
            'employee_management' => [
                'title' => 'Employee Management',
                'description' => 'Maintain complete employee master data with document, designation and payroll linkage.',
                'form' => [
                    'title' => 'Employee Master Form',
                    'fields' => [
                        ['label' => 'Employee Code', 'name' => 'employee_code', 'placeholder' => 'e.g. EMP-057'],
                        ['label' => 'Full Name', 'name' => 'full_name', 'placeholder' => 'Enter legal name'],
                        ['label' => 'Department', 'name' => 'department', 'type' => 'select', 'options' => ['Operations', 'Finance', 'HR', 'Sales']],
                        ['label' => 'Designation', 'name' => 'designation', 'placeholder' => 'e.g. Sr. Underwriter'],
                        ['label' => 'Joining Date', 'name' => 'joining_date', 'type' => 'date'],
                        ['label' => 'Work Email', 'name' => 'work_email', 'type' => 'email'],
                        ['label' => 'Status', 'name' => 'status', 'type' => 'select', 'options' => ['Active', 'Probation', 'Inactive']],
                        ['label' => 'Notes', 'name' => 'notes', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Headcount', 'value' => '86', 'trend' => '+3 hires', 'trend_positive' => true, 'icon' => 'fas fa-users'],
                    ['label' => 'Onboarding Tasks', 'value' => '12 open', 'icon' => 'fas fa-clipboard-check']
                ],
                'checklist' => [
                    ['label' => 'Documents Verified', 'description' => 'Passport, visa & degree uploaded'],
                    ['label' => 'Payroll Linked', 'description' => 'Salary structure assigned']
                ]
            ],
            'attendance' => [
                'title' => 'Attendance',
                'description' => 'Daily attendance capture with biometrics sync and exception approval tracking.',
                'form' => [
                    'title' => 'Attendance Adjustment',
                    'fields' => [
                        ['label' => 'Employee', 'name' => 'employee_id', 'type' => 'select', 'options' => ['Select Employee']],
                        ['label' => 'Date', 'name' => 'attendance_date', 'type' => 'date'],
                        ['label' => 'Check-in Time', 'name' => 'check_in', 'type' => 'text', 'placeholder' => '08:30'],
                        ['label' => 'Check-out Time', 'name' => 'check_out', 'type' => 'text', 'placeholder' => '17:30'],
                        ['label' => 'Work Location', 'name' => 'work_location', 'type' => 'select', 'options' => ['Head Office', 'Remote', 'Client Site']],
                        ['label' => 'Remarks', 'name' => 'remarks', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Apply Adjustment', 'variant' => 'primary', 'icon' => 'fas fa-user-clock'],
                        ['label' => 'Notify Employee', 'variant' => 'outline', 'icon' => 'fas fa-paper-plane']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Present Today', 'value' => '78', 'icon' => 'fas fa-user-check'],
                    ['label' => 'Late Arrivals', 'value' => '5', 'icon' => 'fas fa-clock']
                ]
            ],
            'leave_management' => [
                'title' => 'Leave Management',
                'description' => 'Configure leave types, approvals and encashment with live balances.',
                'form' => [
                    'title' => 'Leave Request',
                    'fields' => [
                        ['label' => 'Employee', 'name' => 'employee_id', 'type' => 'select', 'options' => ['Select Employee']],
                        ['label' => 'Leave Type', 'name' => 'leave_type', 'type' => 'select', 'options' => ['Annual', 'Sick', 'Emergency', 'Unpaid']],
                        ['label' => 'From Date', 'name' => 'from_date', 'type' => 'date'],
                        ['label' => 'To Date', 'name' => 'to_date', 'type' => 'date'],
                        ['label' => 'Total Days', 'name' => 'total_days', 'type' => 'number'],
                        ['label' => 'Approver', 'name' => 'approver', 'type' => 'select', 'options' => ['Line Manager', 'HR']],
                        ['label' => 'Reason', 'name' => 'reason', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Pending Approvals', 'value' => '8', 'icon' => 'fas fa-mail-bulk'],
                    ['label' => 'Encashment Requests', 'value' => '3', 'icon' => 'fas fa-coins']
                ]
            ],
            'payroll_processing' => [
                'title' => 'Payroll Processing',
                'description' => 'End-to-end payroll run with compliance validations and bank file exports.',
                'form' => [
                    'title' => 'Payroll Cycle',
                    'fields' => [
                        ['label' => 'Payroll Month', 'name' => 'payroll_month', 'type' => 'select', 'options' => ['January', 'February', 'March']],
                        ['label' => 'Pay Group', 'name' => 'pay_group', 'type' => 'select', 'options' => ['HO Salaried', 'Sales Incentive']],
                        ['label' => 'Payment Date', 'name' => 'payment_date', 'type' => 'date'],
                        ['label' => 'Basic Salary', 'name' => 'basic_salary', 'type' => 'currency'],
                        ['label' => 'Allowances', 'name' => 'allowances', 'type' => 'currency'],
                        ['label' => 'Deductions', 'name' => 'deductions', 'type' => 'currency'],
                        ['label' => 'Net Pay', 'name' => 'net_pay', 'type' => 'currency'],
                        ['label' => 'Remarks', 'name' => 'remarks', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Validate', 'variant' => 'outline', 'icon' => 'fas fa-check-double'],
                        ['label' => 'Generate WPS', 'variant' => 'primary', 'icon' => 'fas fa-file-export']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Total Payroll', 'value' => 'AED 612K', 'icon' => 'fas fa-wallet'],
                    ['label' => 'Pending Bank File', 'value' => '1', 'icon' => 'fas fa-file-import']
                ]
            ],
            'salary_structures' => [
                'title' => 'Salary Structures',
                'description' => 'Design grade wise salary templates with automatic benefits and statutory components.',
                'form' => [
                    'title' => 'Structure Builder',
                    'fields' => [
                        ['label' => 'Grade / Band', 'name' => 'grade', 'type' => 'select', 'options' => ['A1', 'B1', 'C1']],
                        ['label' => 'Basic %', 'name' => 'basic_pct', 'type' => 'number'],
                        ['label' => 'Housing Allowance', 'name' => 'housing_allowance', 'type' => 'currency'],
                        ['label' => 'Transport Allowance', 'name' => 'transport_allowance', 'type' => 'currency'],
                        ['label' => 'Other Benefits', 'name' => 'other_benefits', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => $defaultActions
                ],
                'meta_cards' => [
                    ['label' => 'Structures Active', 'value' => '12', 'icon' => 'fas fa-layer-group'],
                    ['label' => 'Pending Review', 'value' => '2', 'icon' => 'fas fa-exclamation-circle']
                ]
            ],
            'performance' => [
                'title' => 'Performance',
                'description' => 'Track KPIs, reviews and goals with workflow reminders and calibration comments.',
                'form' => [
                    'title' => 'Performance Review',
                    'fields' => [
                        ['label' => 'Employee', 'name' => 'employee_id', 'type' => 'select', 'options' => ['Select Employee']],
                        ['label' => 'Review Period', 'name' => 'review_period', 'type' => 'select', 'options' => ['Q1', 'Q2', 'Q3', 'Q4']],
                        ['label' => 'Overall Rating', 'name' => 'rating', 'type' => 'select', 'options' => ['Outstanding', 'Exceeds', 'Meets', 'Needs Improvement']],
                        ['label' => 'Primary KPI Score', 'name' => 'kpi_score', 'type' => 'number'],
                        ['label' => 'Development Plan', 'name' => 'development_plan', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Publish Review', 'variant' => 'primary', 'icon' => 'fas fa-share'],
                        ['label' => 'Request Calibration', 'variant' => 'outline', 'icon' => 'fas fa-balance-scale']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Reviews Due', 'value' => '14', 'icon' => 'fas fa-calendar-check'],
                    ['label' => 'Pending Feedback', 'value' => '5', 'icon' => 'fas fa-comments']
                ]
            ]
        ];
    }

    private function render(string $slug): void
    {
        if (!isset($this->pages[$slug])) {
            show_404();
        }

        $this->process_form_submission($slug);

        $config = $this->pages[$slug];
        $form_config = $this->hydrate_form_config($slug, $config['form'] ?? []);

        $data = [
            'page_title' => $config['title'],
            'page_description' => $config['description'],
            'form_title' => $form_config['title'] ?? $config['title'],
            'form_fields' => $form_config['fields'] ?? [],
            'form_actions' => $form_config['actions'] ?? $this->default_form_actions(),
            'form_action' => $form_config['action'] ?? current_url(),
            'form_method' => $form_config['method'] ?? 'post',
            'meta_cards' => $this->resolve_meta_cards($slug, $config['meta_cards'] ?? []),
            'checklist' => $config['checklist'] ?? [],
            'activity_timeline' => $config['activity'] ?? [],
            'main_content' => 'shared/dynamic_form',
            'active_menu' => 'hr'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function employee_management()
    {
        $this->render('employee_management');
    }

    public function attendance()
    {
        $this->render('attendance');
    }

    public function leave_management()
    {
        $this->render('leave_management');
    }

    public function payroll_processing()
    {
        $this->render('payroll_processing');
    }

    public function salary_structures()
    {
        $this->render('salary_structures');
    }

    public function performance()
    {
        $this->render('performance');
    }

    private function default_form_actions(): array
    {
        return [
            ['label' => 'Save', 'variant' => 'primary', 'icon' => 'fas fa-save'],
            ['label' => 'Reset', 'variant' => 'outline', 'icon' => 'fas fa-rotate-left']
        ];
    }

    private function hydrate_form_config(string $slug, array $form): array
    {
        $fields = $form['fields'] ?? [];

        switch ($slug) {
            case 'employee_management':
                $fields = $this->inject_select_options($fields, 'department', $this->enum_options(['Operations', 'Finance', 'HR', 'Sales']));
                $fields = $this->inject_select_options($fields, 'status', $this->enum_options(['Active', 'Probation', 'Inactive']));
                break;

            case 'attendance':
                $fields = $this->inject_select_options($fields, 'employee_id', $this->employee_options(), 'Select Employee');
                $fields = $this->inject_select_options($fields, 'work_location', $this->enum_options(['Head Office', 'Remote', 'Client Site']));
                break;

            case 'leave_management':
                $fields = $this->inject_select_options($fields, 'employee_id', $this->employee_options(), 'Select Employee');
                $fields = $this->inject_select_options($fields, 'leave_type', $this->enum_options(['Annual', 'Sick', 'Emergency', 'Unpaid']));
                $fields = $this->inject_select_options($fields, 'approver', $this->enum_options(['Line Manager', 'HR']));
                break;

            case 'payroll_processing':
                $fields = $this->inject_select_options($fields, 'payroll_month', $this->enum_options(['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December']));
                break;

            case 'salary_structures':
                $fields = $this->inject_select_options($fields, 'grade', $this->enum_options(['A1', 'B1', 'C1']));
                break;

            case 'performance':
                $fields = $this->inject_select_options($fields, 'employee_id', $this->employee_options(), 'Select Employee');
                $fields = $this->inject_select_options($fields, 'review_period', $this->enum_options(['Q1', 'Q2', 'Q3', 'Q4']));
                $fields = $this->inject_select_options($fields, 'rating', $this->enum_options(['Outstanding', 'Exceeds', 'Meets', 'Needs Improvement']));
                break;
        }

        $form['fields'] = $fields;
        $form['action'] = current_url();
        $form['method'] = 'post';

        return $form;
    }

    private function process_form_submission(string $slug): void
    {
        if ($this->input->method() !== 'post') {
            return;
        }

        switch ($slug) {
            case 'employee_management':
                $this->form_validation->set_rules('employee_code', 'Employee Code', 'required|trim');
                $this->form_validation->set_rules('full_name', 'Full Name', 'required|trim');
                $this->form_validation->set_rules('department', 'Department', 'required');
                $this->form_validation->set_rules('designation', 'Designation', 'required|trim');
                $this->form_validation->set_rules('joining_date', 'Joining Date', 'required');
                $this->form_validation->set_rules('work_email', 'Work Email', 'required|valid_email');
                $this->form_validation->set_rules('status', 'Status', 'required');

                if ($this->form_validation->run()) {
                    $this->Hr_model->save_employee([
                        'employee_code' => $this->input->post('employee_code', TRUE),
                        'full_name' => $this->input->post('full_name', TRUE),
                        'department' => $this->input->post('department', TRUE),
                        'designation' => $this->input->post('designation', TRUE),
                        'joining_date' => $this->input->post('joining_date', TRUE),
                        'work_email' => $this->input->post('work_email', TRUE),
                        'status' => $this->input->post('status', TRUE),
                        'notes' => $this->input->post('notes', TRUE),
                    ]);

                    $this->session->set_flashdata('success', 'Employee saved successfully.');
                    redirect(current_url());
                }
                break;

            case 'attendance':
                $this->form_validation->set_rules('employee_id', 'Employee', 'required|integer');
                $this->form_validation->set_rules('attendance_date', 'Date', 'required');
                $this->form_validation->set_rules('check_in', 'Check-in', 'required');
                $this->form_validation->set_rules('check_out', 'Check-out', 'required');
                $this->form_validation->set_rules('work_location', 'Location', 'required');

                if ($this->form_validation->run()) {
                    $this->Hr_model->save_attendance([
                        'employee_id' => (int) $this->input->post('employee_id'),
                        'attendance_date' => $this->input->post('attendance_date', TRUE),
                        'check_in' => $this->input->post('check_in', TRUE),
                        'check_out' => $this->input->post('check_out', TRUE),
                        'work_location' => $this->input->post('work_location', TRUE),
                        'remarks' => $this->input->post('remarks', TRUE),
                    ]);
                    $this->session->set_flashdata('success', 'Attendance updated.');
                    redirect(current_url());
                }
                break;

            case 'leave_management':
                $this->form_validation->set_rules('employee_id', 'Employee', 'required|integer');
                $this->form_validation->set_rules('leave_type', 'Leave Type', 'required');
                $this->form_validation->set_rules('from_date', 'From Date', 'required');
                $this->form_validation->set_rules('to_date', 'To Date', 'required');
                $this->form_validation->set_rules('total_days', 'Total Days', 'required|numeric');
                $this->form_validation->set_rules('approver', 'Approver', 'required');

                if ($this->form_validation->run()) {
                    $this->Hr_model->save_leave([
                        'employee_id' => (int) $this->input->post('employee_id'),
                        'leave_type' => $this->input->post('leave_type', TRUE),
                        'from_date' => $this->input->post('from_date', TRUE),
                        'to_date' => $this->input->post('to_date', TRUE),
                        'total_days' => $this->decimal_input('total_days'),
                        'approver' => $this->input->post('approver', TRUE),
                        'reason' => $this->input->post('reason', TRUE),
                        'status' => 'Pending'
                    ]);
                    $this->session->set_flashdata('success', 'Leave request captured.');
                    redirect(current_url());
                }
                break;

            case 'payroll_processing':
                $this->form_validation->set_rules('payroll_month', 'Payroll Month', 'required');
                $this->form_validation->set_rules('pay_group', 'Pay Group', 'required');
                $this->form_validation->set_rules('payment_date', 'Payment Date', 'required');
                $this->form_validation->set_rules('basic_salary', 'Basic Salary', 'required|numeric');
                $this->form_validation->set_rules('allowances', 'Allowances', 'numeric');
                $this->form_validation->set_rules('deductions', 'Deductions', 'numeric');
                $this->form_validation->set_rules('net_pay', 'Net Pay', 'required|numeric');

                if ($this->form_validation->run()) {
                    $this->Hr_model->save_payroll([
                        'payroll_month' => $this->input->post('payroll_month', TRUE),
                        'pay_group' => $this->input->post('pay_group', TRUE),
                        'payment_date' => $this->input->post('payment_date', TRUE),
                        'basic_salary' => $this->decimal_input('basic_salary'),
                        'allowances' => $this->decimal_input('allowances'),
                        'deductions' => $this->decimal_input('deductions'),
                        'net_pay' => $this->decimal_input('net_pay'),
                        'remarks' => $this->input->post('remarks', TRUE),
                        'status' => 'Validated'
                    ]);
                    $this->session->set_flashdata('success', 'Payroll cycle stored.');
                    redirect(current_url());
                }
                break;

            case 'salary_structures':
                $this->form_validation->set_rules('grade', 'Grade', 'required');
                $this->form_validation->set_rules('basic_pct', 'Basic %', 'required|numeric');
                $this->form_validation->set_rules('housing_allowance', 'Housing Allowance', 'numeric');
                $this->form_validation->set_rules('transport_allowance', 'Transport Allowance', 'numeric');

                if ($this->form_validation->run()) {
                    $this->Hr_model->save_salary_structure([
                        'grade' => $this->input->post('grade', TRUE),
                        'basic_pct' => $this->decimal_input('basic_pct'),
                        'housing_allowance' => $this->decimal_input('housing_allowance'),
                        'transport_allowance' => $this->decimal_input('transport_allowance'),
                        'other_benefits' => $this->input->post('other_benefits', TRUE),
                    ]);
                    $this->session->set_flashdata('success', 'Salary structure saved.');
                    redirect(current_url());
                }
                break;

            case 'performance':
                $this->form_validation->set_rules('employee_id', 'Employee', 'required|integer');
                $this->form_validation->set_rules('review_period', 'Review Period', 'required');
                $this->form_validation->set_rules('rating', 'Rating', 'required');
                $this->form_validation->set_rules('kpi_score', 'KPI Score', 'numeric');

                if ($this->form_validation->run()) {
                    $this->Hr_model->save_performance([
                        'employee_id' => (int) $this->input->post('employee_id'),
                        'review_period' => $this->input->post('review_period', TRUE),
                        'rating' => $this->input->post('rating', TRUE),
                        'kpi_score' => $this->decimal_input('kpi_score'),
                        'development_plan' => $this->input->post('development_plan', TRUE),
                        'status' => 'Draft'
                    ]);
                    $this->session->set_flashdata('success', 'Performance review recorded.');
                    redirect(current_url());
                }
                break;
        }

        if (!empty($_POST)) {
            $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
        }
    }

    private function inject_select_options(array $fields, string $name, array $options, string $placeholder = '')
    {
        foreach ($fields as &$field) {
            if (($field['name'] ?? '') === $name) {
                $field['type'] = 'select';
                $field['options'] = $options;
                if ($placeholder) {
                    $field['placeholder'] = $placeholder;
                }
                break;
            }
        }
        return $fields;
    }

    private function employee_options(): array
    {
        return array_map(function ($row) {
            return [
                'value' => $row->id,
                'label' => $row->full_name . ' (' . $row->employee_code . ')'
            ];
        }, $this->Hr_model->get_employee_dropdown());
    }

    private function enum_options(array $values): array
    {
        return array_map(function ($value) {
            return ['value' => $value, 'label' => $value];
        }, $values);
    }

    private function resolve_meta_cards(string $slug, array $defaults): array
    {
        switch ($slug) {
            case 'employee_management':
                return [
                    ['label' => 'Headcount', 'value' => number_format($this->Hr_model->count_employees()), 'icon' => 'fas fa-users'],
                    ['label' => 'Onboarding', 'value' => number_format($this->Hr_model->count_employees('Probation')), 'icon' => 'fas fa-clipboard-check']
                ];
            case 'attendance':
                return [
                    ['label' => 'Present Today', 'value' => number_format($this->Hr_model->attendance_today(date('Y-m-d'))), 'icon' => 'fas fa-user-check'],
                    ['label' => 'Pending Leaves', 'value' => number_format($this->Hr_model->count_pending_leaves()), 'icon' => 'fas fa-envelope-open-text']
                ];
            case 'payroll_processing':
                return [
                    ['label' => 'Current Payroll', 'value' => 'AED ' . number_format($this->Hr_model->total_payroll_amount(date('F')) ?? 0, 2), 'icon' => 'fas fa-wallet'],
                    ['label' => 'Employees Paid', 'value' => number_format($this->Hr_model->count_employees('Active')), 'icon' => 'fas fa-file-invoice-dollar']
                ];
            default:
                return $defaults;
        }
    }

    private function decimal_input(string $key): float
    {
        $value = str_replace(',', '', (string) $this->input->post($key));
        return (float) ($value !== '' ? $value : 0);
    }
}
