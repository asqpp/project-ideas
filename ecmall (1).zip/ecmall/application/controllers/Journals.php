<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Journals extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->load->model('Journal_model');
        $this->load->model('Account_model');
    }

    public function index()
    {
        $page = max(1, (int) ($this->input->get('page') ?? 1));
        $filters = [
            'from_date' => $this->input->get('from_date'),
            'to_date' => $this->input->get('to_date')
        ];

        $result = $this->Journal_model->get_paginated(25, $page, $filters);

        $data = [
            'page_title' => 'Journal Entries',
            'journals' => $result->data,
            'pagination' => $result,
            'filters' => $filters,
            'accounts' => $this->Account_model->get_for_dropdown(),
            'main_content' => 'journals/index',
            'active_menu' => 'journals'
        ];

        $this->load->view('templates/modern_layout', $data);
    }
}
