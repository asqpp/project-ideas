<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Settings extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }
    }

    private function renderForm(array $config): void
    {
        $data = [
            'page_title' => $config['title'],
            'page_description' => $config['description'] ?? '',
            'form_title' => $config['form_title'] ?? $config['title'],
            'form_fields' => $config['fields'] ?? [],
            'form_actions' => $config['actions'] ?? [],
            'meta_cards' => $config['meta_cards'] ?? [],
            'checklist' => $config['checklist'] ?? [],
            'supporting_sections' => $config['sections'] ?? [],
            'main_content' => 'shared/dynamic_form',
            'active_menu' => 'settings'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function index()
    {
        $this->renderForm([
            'title' => 'General Settings',
            'description' => 'Control company profile, branding, notification preferences and timezone across the Insurance ERP.',
            'fields' => [
                ['label' => 'Company Name', 'name' => 'company_name', 'placeholder' => 'NA-FIX Solutions'],
                ['label' => 'Default Branch', 'name' => 'default_branch', 'type' => 'select', 'options' => ['Head Office', 'Abu Dhabi', 'Sharjah']],
                ['label' => 'Timezone', 'name' => 'timezone', 'type' => 'select', 'options' => ['Asia/Dubai', 'Asia/Kolkata', 'Asia/Bahrain']],
                ['label' => 'Currency', 'name' => 'currency', 'type' => 'select', 'options' => ['AED', 'USD', 'SAR']],
                ['label' => 'Financial Year Start', 'name' => 'fy_start', 'type' => 'date'],
                ['label' => 'Notification Email', 'name' => 'notification_email', 'type' => 'email'],
                ['label' => 'Brand Color', 'name' => 'brand_color', 'type' => 'text', 'placeholder' => '#0F172A']
            ],
            'actions' => [
                ['label' => 'Save Settings', 'variant' => 'primary', 'icon' => 'fas fa-save'],
                ['label' => 'Preview Portal', 'variant' => 'outline', 'icon' => 'fas fa-eye']
            ],
            'meta_cards' => [
                ['label' => 'Version', 'value' => 'Insurance ERP 5', 'icon' => 'fas fa-code-branch'],
                ['label' => 'Environment', 'value' => 'Production', 'icon' => 'fas fa-server']
            ],
            'checklist' => [
                ['label' => 'Brand assets uploaded'],
                ['label' => 'Default sequences configured'],
                ['label' => 'Notification templates enabled']
            ]
        ]);
    }

    public function account_structure()
    {
        $this->renderForm([
            'title' => 'Account Structure',
            'description' => 'Modern navigation system with organized reports and account structure for Insurance ERP.',
            'fields' => [
                ['label' => 'Hierarchy Name', 'name' => 'hierarchy_name', 'placeholder' => 'Account Structure'],
                ['label' => 'Primary Module', 'name' => 'primary_module', 'type' => 'select', 'options' => ['Dashboard', 'Masters', 'Insurance', 'Accounting', 'Transactions', 'HR & Payroll', 'Reports', 'Settings']],
                ['label' => 'Description', 'name' => 'description', 'type' => 'textarea', 'col_span' => 'md:col-span-2', 'placeholder' => 'Welcome to Insurance ERP...']
            ],
            'sections' => [
                [
                    'title' => 'Navigation Map',
                    'icon' => 'fas fa-compass',
                    'items' => [
                        ['label' => 'Dashboard', 'description' => 'Overview, company & branch insights with real-time notifications.'],
                        ['label' => 'Masters', 'description' => 'Manage customers, agents, brokers, suppliers & products.'],
                        ['label' => 'Insurance', 'description' => 'Policy, claims, underwriting and commission processing.'],
                        ['label' => 'Accounting', 'description' => 'General ledger, journals, bank reconciliation and balance sheet.'],
                        ['label' => 'Transactions', 'description' => 'Sales invoices, purchase bills, receipts, payments and journal entries.'],
                        ['label' => 'HR & Payroll', 'description' => 'Employee management, attendance, leave and payroll processing.'],
                        ['label' => 'Reports', 'description' => 'Financial, sales, purchase, insurance and HR reports with drill-downs.'],
                        ['label' => 'Settings', 'description' => 'Configuration, account structure and notifications.']
                    ]
                ]
            ]
        ]);
    }

    public function notifications()
    {
        $this->renderForm([
            'title' => 'Notification Center',
            'description' => 'Enable alerts for CRUD operations, critical approvals and expiring policies.',
            'fields' => [
                ['label' => 'Email Alerts', 'name' => 'email_alerts', 'type' => 'select', 'options' => ['Enabled', 'Disabled']],
                ['label' => 'SMS Alerts', 'name' => 'sms_alerts', 'type' => 'select', 'options' => ['Enabled', 'Disabled']],
                ['label' => 'In-app Notifications', 'name' => 'inapp', 'type' => 'select', 'options' => ['Enabled', 'Disabled']],
                ['label' => 'Critical Modules', 'name' => 'modules', 'type' => 'chips', 'options' => ['Policies', 'Claims', 'Accounts', 'HR']]
            ],
            'actions' => [
                ['label' => 'Update Channels', 'variant' => 'primary', 'icon' => 'fas fa-bell'],
                ['label' => 'Test Notification', 'variant' => 'outline', 'icon' => 'fas fa-paper-plane']
            ],
            'meta_cards' => [
                ['label' => 'Active Webhooks', 'value' => '3', 'icon' => 'fas fa-link'],
                ['label' => 'Last Test', 'value' => '2 mins ago', 'icon' => 'fas fa-history']
            ]
        ]);
    }

    public function client_codes()
    {
        $this->load->model('ClientSettings_model');

        if ($this->input->method() === 'post') {
            $customerConfig = [
                'enabled' => $this->input->post('customer_enabled'),
                'prefix' => $this->input->post('customer_prefix'),
                'next' => $this->input->post('customer_next'),
                'padding' => $this->input->post('customer_padding')
            ];
            $supplierConfig = [
                'enabled' => $this->input->post('supplier_enabled'),
                'prefix' => $this->input->post('supplier_prefix'),
                'next' => $this->input->post('supplier_next'),
                'padding' => $this->input->post('supplier_padding')
            ];

            $this->ClientSettings_model->save_autocode('customer', $customerConfig);
            $this->ClientSettings_model->save_autocode('supplier', $supplierConfig);

            $this->session->set_flashdata('success', 'Client code settings updated.');
            redirect('settings/client_codes');
        }

        $data = [
            'page_title' => 'Client Code Settings',
            'active_menu' => 'settings',
            'main_content' => 'settings/client_codes',
            'customer_config' => $this->ClientSettings_model->get_autocode('customer'),
            'supplier_config' => $this->ClientSettings_model->get_autocode('supplier')
        ];

        $this->load->view('templates/modern_layout', $data);
    }
}
