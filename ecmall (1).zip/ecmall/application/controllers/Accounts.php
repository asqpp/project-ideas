<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Account_model');
        $this->load->model('AccountStructure_model');
    }

    /**
     * Chart of Accounts - List all accounts
     */
    public function index() {
        $page = $this->input->get('page') ?? 1;
        $search = $this->input->get('search') ?? '';
        $account_type = $this->input->get('account_type') ?? '';

        $result = $this->Account_model->get_paginated(50, $page, $search, $account_type);

        // Calculate balances for each account
        foreach ($result->data as $account) {
            $account->balance = $this->Account_model->get_balance($account->account_code);
        }

        $data = [
            'page_title' => 'Chart of Accounts',
            'accounts' => $result->data,
            'pagination' => $result,
            'search' => $search,
            'account_type' => $account_type,
            'account_types' => $this->Account_model->get_account_types(),
            'main_content' => 'accounts/index'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Add new account
     */
    public function add() {
        return $this->legacy_account();
    }

    /**
     * Edit account
     */
    public function edit($account_id) {
        if (!$this->Account_model->get_by_id($account_id)) {
            show_404();
        }

        redirect('accounts/add?accode=' . rawurlencode($account_id));
    }

    /**
     * View account details and ledger
     */
    public function view($account_id) {
        $account = $this->Account_model->get_by_id($account_id);

        if (!$account) {
            show_404();
        }

        // Get account balance
        $account->balance = $this->Account_model->get_balance($account->account_code);

        // Get recent ledger entries (last 25)
        $ledger_entries = $this->Account_model->get_ledger($account->account_code);
        $recent_entries = array_slice($ledger_entries, -25);

        $data = [
            'page_title' => 'Account Details',
            'account' => $account,
            'ledger_entries' => $recent_entries,
            'total_entries' => count($ledger_entries),
            'main_content' => 'accounts/view'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * View full account ledger
     */
    public function ledger($account_id) {
        $account = $this->Account_model->get_by_id($account_id);

        if (!$account) {
            show_404();
        }

        $from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');

        // Get ledger entries
        $ledger_entries = $this->Account_model->get_ledger($account->account_code, $from_date, $to_date);

        // Get opening balance (balance before from_date)
        $opening_balance = $this->calculate_opening_balance($account->account_code, $from_date);

        // Recalculate running balance with opening balance
        $running_balance = $opening_balance;
        foreach ($ledger_entries as $entry) {
            $running_balance += ($entry->debit - $entry->credit);
            $entry->running_balance = $running_balance;
        }

        $data = [
            'page_title' => 'Account Ledger',
            'account' => $account,
            'ledger_entries' => $ledger_entries,
            'opening_balance' => $opening_balance,
            'filters' => [
                'from_date' => $from_date,
                'to_date' => $to_date
            ],
            'main_content' => 'accounts/ledger'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Delete account
     */
    public function delete($account_id) {
        $account = $this->Account_model->get_by_id($account_id);

        if (!$account) {
            show_404();
        }

        // Prevent deleting system accounts
        if ($account->is_system ?? false) {
            $this->session->set_flashdata('error', 'Cannot delete system accounts.');
            redirect('accounts');
        }

        // Check if account has any transactions
        $this->db->where('account_code', $account->account_code);
        $transaction_count = $this->db->count_all_results('daybook');

        if ($transaction_count > 0) {
            $this->session->set_flashdata('error', 'Cannot delete account with existing transactions.');
        } else {
            $deleted = $this->Account_model->delete($account_id);

            if ($deleted) {
                $this->session->set_flashdata('success', 'Account deleted successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to delete account.');
            }
        }

        redirect('accounts');
    }

    /**
     * Trial Balance Report
     */
    public function trial_balance() {
        $as_of_date = $this->input->get('as_of_date') ?? date('Y-m-d');

        $accounts = $this->Account_model->get_trial_balance($as_of_date);

        // Calculate totals
        $total_debit = 0;
        $total_credit = 0;

        foreach ($accounts as $account) {
            $total_debit += $account->debit_balance;
            $total_credit += $account->credit_balance;
        }

        $data = [
            'page_title' => 'Trial Balance',
            'accounts' => $accounts,
            'as_of_date' => $as_of_date,
            'total_debit' => $total_debit,
            'total_credit' => $total_credit,
            'main_content' => 'accounts/trial_balance'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function positions()
    {

        $context = $this->input->get('context') ?? 'accounts';
        $sort = $this->input->get('sort') ?? 'tplpos';

        if ($context === 'groups') {
            $records = $this->AccountStructure_model->get_group_positions();
        } elseif ($context === 'heads') {
            $records = $this->AccountStructure_model->get_head_positions();
        } else {
            $records = $this->AccountStructure_model->get_account_positions($sort);
        }

        $data = [
            'page_title' => 'Account Positions',
            'context' => $context,
            'sort' => $sort,
            'records' => $records,
            'main_content' => 'accounts/positions'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function update_positions()
    {
        $this->ensure_admin();

        $context = $this->input->post('context');
        $records = $this->input->post('records') ?? [];

        switch ($context) {
            case 'groups':
                $updated = $this->AccountStructure_model->update_group_positions($records);
                break;
            case 'heads':
                $updated = $this->AccountStructure_model->update_head_positions($records);
                break;
            default:
                $updated = $this->AccountStructure_model->update_account_positions($records);
                break;
        }

        $this->session->set_flashdata('success', "{$updated} record(s) updated.");
        redirect('accounts/positions?context=' . $context);
    }

    public function legacy_account()
    {
        $this->ensure_admin();
        $edit_code = $this->input->get('accode');
        $account = $edit_code ? $this->AccountStructure_model->get_account($edit_code) : null;
        $schedule_groups = $this->AccountStructure_model->get_schedule_groups();

        if ($this->input->post()) {
            $action = $this->input->post('action');

            if ($action === 'delete' && $this->input->post('accode')) {
                $code = $this->input->post('accode');
                $record = $this->AccountStructure_model->get_account($code);
                if ($record && ($record->reserve ?? 'N') === 'Y') {
                    $this->session->set_flashdata('error', 'Reserved accounts cannot be deleted.');
                    redirect('accounts/add?accode=' . $code);
                }
                $this->AccountStructure_model->delete_account($code);
                $this->session->set_flashdata('success', 'Account removed.');
                redirect('accounts/add');
            }

            $this->load->library('form_validation');
            $this->form_validation->set_rules('accode', 'Account Code', 'required|trim');
            $this->form_validation->set_rules('name', 'Account Name', 'required|trim');
            $this->form_validation->set_rules('actype1', 'Primary Type', 'required|trim');
            $this->form_validation->set_rules('grcode', 'Group', 'required');

            if ($this->form_validation->run()) {
                $code = strtoupper(trim($this->input->post('accode')));
                if (!$this->input->post('is_edit') && $this->AccountStructure_model->get_account($code)) {
                    $this->session->set_flashdata('error', 'Account code already exists.');
                    redirect('accounts/add?accode=' . $code);
                }

                $payload = [
                    'accode' => $code,
                    'name' => strtoupper(trim($this->input->post('name'))),
                    'actype1' => strtoupper($this->input->post('actype1')),
                    'reserve' => $this->input->post('reserve') ? 'Y' : 'N',
                    'grcode' => $this->input->post('grcode') ?: null,
                    'bshead' => $this->input->post('bshead') ?: null,
                    'tplpos' => (int) $this->input->post('tplpos'),
                    'shepos' => (int) $this->input->post('shepos'),
                    'shedgrp' => $this->input->post('shedgrp') ?: null,
                    'opbal' => (float) $this->input->post('opbal'),
                    'opbalb' => (float) $this->input->post('opbalb'),
                    'control' => $this->input->post('control') ? 1 : 0,
                    'hlp' => $this->input->post('hlp') ? 1 : 0,
                    'sp' => $this->input->post('sp') ? 1 : 0,
                    'removed' => $this->input->post('removed') ? 'Y' : 'N',
                    'blocked' => $this->input->post('blocked') ? 'Y' : 'N',
                    'note' => $this->input->post('note')
                ];

                $is_edit = (bool) $this->input->post('is_edit');
                $saved = $this->AccountStructure_model->save_account($payload, $is_edit ? $payload['accode'] : null);

                if ($saved) {
                    $this->session->set_flashdata('success', $is_edit ? 'Account updated.' : 'Account created.');
                    redirect('accounts/add?accode=' . $payload['accode']);
                }

                $this->session->set_flashdata('error', 'Unable to save account.');
            }
        }

        $data = [
            'page_title' => 'Account Details',
            'account' => $account,
            'accounts_legacy' => $this->AccountStructure_model->get_accounts(['search' => $this->input->get('search')]),
            'groups_legacy' => $this->AccountStructure_model->get_groups(),
            'heads_legacy' => $this->AccountStructure_model->get_heads(),
            'schedule_groups' => $schedule_groups,
            'main_content' => 'accounts/legacy_account'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function groups()
    {
        $this->ensure_admin();
        $edit_code = $this->input->get('grcode');
        $group = $edit_code ? $this->AccountStructure_model->get_group($edit_code) : null;

        if ($this->input->post()) {
            $action = $this->input->post('action');

            if ($action === 'delete' && $this->input->post('grcode')) {
                $code = $this->input->post('grcode');
                if ($this->AccountStructure_model->group_has_accounts($code)) {
                    $this->session->set_flashdata('error', 'Group has linked accounts.');
                } elseif (($this->AccountStructure_model->get_group($code)->reserve ?? 'N') === 'Y') {
                    $this->session->set_flashdata('error', 'Reserved groups cannot be deleted.');
                } else {
                    $this->AccountStructure_model->delete_group($code);
                    $this->session->set_flashdata('success', 'Group removed.');
                }
                redirect('accounts/groups');
            }

            $this->load->library('form_validation');
            $this->form_validation->set_rules('grcode', 'Group Code', 'required|trim');
            $this->form_validation->set_rules('name', 'Group Name', 'required|trim');
            $this->form_validation->set_rules('actype1', 'Type', 'required|trim');

            if ($this->form_validation->run()) {
                    $payload = [
                        'grcode' => strtoupper(trim($this->input->post('grcode'))),
                        'name' => strtoupper(trim($this->input->post('name'))),
                        'actype1' => strtoupper($this->input->post('actype1')),
                        'reserve' => $this->input->post('reserve') ? 'Y' : 'N',
                        'position' => (int) $this->input->post('position'),
                    'pos' => (int) $this->input->post('pos'),
                    'mgrp' => $this->input->post('mgrp') ?: null
                ];

                $is_edit = (bool) $this->input->post('is_edit');
                $this->AccountStructure_model->save_group($payload, $is_edit ? $payload['grcode'] : null);
                $this->session->set_flashdata('success', $is_edit ? 'Group updated.' : 'Group created.');
                redirect('accounts/groups?grcode=' . $payload['grcode']);
            }
        }

        $data = [
            'page_title' => 'Group Details',
            'group' => $group,
            'groups_legacy' => $this->AccountStructure_model->get_groups(),
            'main_content' => 'accounts/groups'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function heads()
    {
        $this->ensure_admin();
        $edit_code = $this->input->get('hcode');
        $head = $edit_code ? $this->AccountStructure_model->get_head($edit_code) : null;

        if ($this->input->post()) {
            $action = $this->input->post('action');

            if ($action === 'delete' && $this->input->post('hcode')) {
                $this->AccountStructure_model->delete_head($this->input->post('hcode'));
                $this->session->set_flashdata('success', 'Head removed.');
                redirect('accounts/heads');
            }

            $this->load->library('form_validation');
            $this->form_validation->set_rules('hcode', 'Head Code', 'required|trim');
            $this->form_validation->set_rules('hname', 'Head Name', 'required|trim');

            if ($this->form_validation->run()) {
                $payload = [
                    'hcode' => strtoupper(trim($this->input->post('hcode'))),
                    'hname' => strtoupper(trim($this->input->post('hname'))),
                    'actype1' => strtoupper($this->input->post('actype1')),
                    'pos' => (int) $this->input->post('pos'),
                    'reserve' => $this->input->post('reserve') ? 'Y' : 'N',
                    'expand' => $this->input->post('expand') ? 'Y' : 'N'
                ];

                $is_edit = (bool) $this->input->post('is_edit');
                $this->AccountStructure_model->save_head($payload, $is_edit ? $payload['hcode'] : null);
                $this->session->set_flashdata('success', $is_edit ? 'Head updated.' : 'Head created.');
                redirect('accounts/heads?hcode=' . $payload['hcode']);
            }
        }

        $data = [
            'page_title' => 'Balance Sheet Heads',
            'head' => $head,
            'heads' => $this->AccountStructure_model->get_heads(),
            'main_content' => 'accounts/heads'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function import_legacy_data()
    {
        $this->ensure_admin();
        $type = $this->input->post('type');
        $redirect = $this->input->post('redirect') ?? 'accounts/add';

        $files = [
            'accounts' => FCPATH . 'database/account_data.txt',
            'groups' => FCPATH . 'database/accountg_data.txt',
            'heads' => FCPATH . 'database/accountgbs_data.txt'
        ];

        $import_path = $files[$type] ?? null;
        $upload = $_FILES['upload_file'] ?? null;

        if ($upload && $upload['error'] === UPLOAD_ERR_OK) {
            $tempPath = sys_get_temp_dir() . '/' . uniqid('import_', true) . '.csv';
            move_uploaded_file($upload['tmp_name'], $tempPath);
            $import_path = $tempPath;
        }

        if (!$import_path || !file_exists($import_path)) {
            $this->session->set_flashdata('error', 'Import file not found.');
            redirect($redirect);
        }

        try {
            $result = $this->AccountStructure_model->import_from_file($type, $import_path);
            $this->session->set_flashdata('success', strtoupper($type) . ' import complete: ' . $result['imported'] . ' rows.');
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
        }
        if (isset($tempPath) && file_exists($tempPath)) {
            @unlink($tempPath);
        }

        redirect($redirect);
    }

    /**
     * Quick ledger lookup by account code param e.g. /accounts/ledger_by_code?account_code=CASH
     */
    public function ledger_by_code() {
        $account_code = $this->input->get('account_code');
        $from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');

        if (!$account_code) {
            $this->session->set_flashdata('error', 'Please provide an account code.');
            redirect('accounts');
        }

        $account = $this->Account_model->get_by_code($account_code);

        if (!$account) {
            $this->session->set_flashdata('error', 'Account code not found.');
            redirect('accounts');
        }

        $ledger_entries = $this->Account_model->get_ledger($account->account_code, $from_date, $to_date);
        $opening_balance = $this->calculate_opening_balance($account->account_code, $from_date);

        // Recalculate running balance
        $running_balance = $opening_balance;
        foreach ($ledger_entries as $entry) {
            $running_balance += ($entry->debit - $entry->credit);
            $entry->running_balance = $running_balance;
        }

        $data = [
            'page_title' => 'Account Ledger - ' . $account->account_code,
            'account' => $account,
            'ledger_entries' => $ledger_entries,
            'opening_balance' => $opening_balance,
            'filters' => [
                'from_date' => $from_date,
                'to_date' => $to_date
            ],
            'main_content' => 'accounts/ledger'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    private function calculate_opening_balance(string $account_code, ?string $from_date): float
    {
        if (empty($from_date)) {
            return 0;
        }

        $this->db->select_sum('debit');
        $this->db->select_sum('credit');
        $this->db->where('account_code', $account_code);
        $this->db->where('date <', $from_date);
        $result = $this->db->get('daybook')->row();

        return ($result->debit ?? 0) - ($result->credit ?? 0);
    }

    private function ensure_admin(): void
    {
        $role = strtoupper($this->session->userdata('usertype') ?? '');
        if ($role !== 'ADMIN') {
            show_error('This section is restricted to administrators.', 403);
        }
    }

}
