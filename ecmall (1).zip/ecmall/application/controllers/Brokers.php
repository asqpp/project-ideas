<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Brokers extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Broker_model');
    }

    /**
     * List all brokers
     */
    public function index() {
        redirect('clients?type=broker');
        return;
    }

    /**
     * Add new broker
     */
    public function add() {
        redirect('clients/form/broker');
        return;
    }

    /**
     * Edit broker
     */
    public function edit($broker_id) {
        $broker = $this->Broker_model->get_by_id($broker_id);
        if ($broker && !empty($broker->broker_code)) {
            redirect('clients/form/broker/' . rawurlencode($broker->broker_code));
        } else {
            redirect('clients?type=broker');
        }
        return;
    }

    /**
     * View broker details with commission tracking
     */
    public function view($broker_id) {
        $broker = $this->Broker_model->get_by_id($broker_id);
        if ($broker && !empty($broker->broker_code)) {
            redirect('clients/form/broker/' . rawurlencode($broker->broker_code));
        } else {
            redirect('clients?type=broker');
        }
        return;
    }

    /**
     * Delete broker
     */
    public function delete($broker_id) {
        redirect('clients?type=broker');
        return;
    }

    /**
     * Pay commission
     */
    public function pay_commission($commission_id) {
        if ($this->input->post()) {
            $paid_amount = $this->input->post('paid_amount');
            $payment_date = $this->input->post('payment_date');
            $payment_method = $this->input->post('payment_method');
            $notes = $this->input->post('notes');

            $this->db->set('paid_amount', 'paid_amount + ' . $paid_amount, FALSE);
            $this->db->set('payment_status', 'partial');
            $this->db->set('last_payment_date', $payment_date);
            $this->db->set('payment_method', $payment_method);
            $this->db->set('payment_notes', $notes);
            $this->db->where('commission_id', $commission_id);

            // Check if fully paid
            $this->db->where('(paid_amount + ' . $paid_amount . ') >= commission_amount', null, false);
            $this->db->set('payment_status', 'paid');

            $updated = $this->db->update('broker_commission');

            if ($updated) {
                $this->session->set_flashdata('success', 'Commission payment recorded successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to record payment.');
            }

            // Get broker_id to redirect
            $commission = $this->db->get_where('broker_commission', ['commission_id' => $commission_id])->row();
            redirect('brokers/view/' . $commission->broker_id);
        }
    }

    /**
     * Commission report
     */
    public function commission_report() {
        $from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');
        $broker_id = $this->input->get('broker_id');

        $this->db->select('b.broker_name, b.commission_rate,
                          COUNT(DISTINCT i.invoice_id) as total_invoices,
                          COALESCE(SUM(i.grand_total), 0) as total_sales,
                          COALESCE(SUM(bc.commission_amount), 0) as total_commission,
                          COALESCE(SUM(bc.paid_amount), 0) as commission_paid,
                          (COALESCE(SUM(bc.commission_amount), 0) - COALESCE(SUM(bc.paid_amount), 0)) as commission_due');
        $this->db->from('broker b');
        $this->db->join('invoice i', 'b.broker_id = i.broker_id', 'left');
        $this->db->join('broker_commission bc', 'i.invoice_id = bc.invoice_id', 'left');

        if ($broker_id) {
            $this->db->where('b.broker_id', $broker_id);
        }

        if ($from_date) {
            $this->db->where('i.date >=', $from_date);
        }

        if ($to_date) {
            $this->db->where('i.date <=', $to_date);
        }

        $this->db->group_by('b.broker_id');
        $this->db->order_by('total_commission', 'DESC');
        $report = $this->db->get()->result();

        // Get all brokers for filter
        $brokers = $this->Broker_model->get_for_dropdown();

        $data = [
            'page_title' => 'Broker Commission Report',
            'report' => $report,
            'brokers' => $brokers,
            'filters' => [
                'from_date' => $from_date,
                'to_date' => $to_date,
                'broker_id' => $broker_id
            ],
            'main_content' => 'brokers/commission_report'
        ];

        $this->load->view('templates/modern_layout', $data);
    }
}
