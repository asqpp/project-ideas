<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product_groups extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('ProductGroup_model');
        $this->load->model('Category_model');
    }

    public function index()
    {
        $page = (int) ($this->input->get('page') ?? 1);
        $search = $this->input->get('search') ?? '';

        $result = $this->ProductGroup_model->get_paginated(25, $page, $search);

        $data = [
            'page_title' => 'Product Groups',
            'groups' => $result->data,
            'pagination' => $result,
            'search' => $search,
            'main_content' => 'product_groups/index'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function add()
    {
        $this->handle_form();
    }

    public function edit($id)
    {
        $group = $this->ProductGroup_model->get_by_id($id);
        if (!$group) {
            show_404();
        }
        $this->handle_form($group);
    }

    private function handle_form($group = null): void
    {
        if ($this->input->post()) {
            $this->load->library('form_validation');
            $this->form_validation->set_rules('group_name', 'Group Name', 'required|trim');
            $this->form_validation->set_rules('group_code', 'Group Code', 'required|trim|callback_validate_group_code[' . ($group->id ?? '') . ']');

            if ($this->form_validation->run() === true) {
                $payload = [
                    'group_name' => $this->input->post('group_name'),
                    'group_code' => strtoupper($this->input->post('group_code')),
                    'category_id' => $this->input->post('category_id') ?: null,
                    'description' => $this->input->post('description'),
                    'status' => $this->input->post('status') ? 1 : 0
                ];

                if ($group) {
                    $this->ProductGroup_model->update($group->id, $payload);
                    $this->session->set_flashdata('success', 'Group updated successfully.');
                } else {
                    $this->ProductGroup_model->insert($payload);
                    $this->session->set_flashdata('success', 'Group created successfully.');
                }

                redirect('product_groups');
            }
        }

        $data = [
            'page_title' => $group ? 'Edit Product Group' : 'Add Product Group',
            'group' => $group,
            'categories' => $this->Category_model->get_all(),
            'main_content' => 'product_groups/form'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function delete($id)
    {
        $group = $this->ProductGroup_model->get_by_id($id);
        if (!$group) {
            show_404();
        }

        $this->db->where('group_id', $id);
        $product_count = $this->db->count_all_results('product_information');
        if ($product_count > 0) {
            $this->session->set_flashdata('error', 'Cannot delete group. Products are linked to it.');
            redirect('product_groups');
        }

        $this->ProductGroup_model->delete($id);
        $this->session->set_flashdata('success', 'Group deleted successfully.');
        redirect('product_groups');
    }

    public function validate_group_code($code, $id = null)
    {
        $code = strtoupper($code);
        if ($this->ProductGroup_model->code_exists($code, $id ? (int) $id : null)) {
            $this->form_validation->set_message('validate_group_code', 'The {field} must be unique.');
            return false;
        }
        return true;
    }
}
