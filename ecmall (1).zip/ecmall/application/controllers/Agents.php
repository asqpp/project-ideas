<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agents extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Agent_model');
    }

    /**
     * List all agents
     */
    public function index() {
        redirect('clients?type=agent');
        return;
    }

    /**
     * Add new agent
     */
    public function add() {
        redirect('clients/form/agent');
        return;
    }

    /**
     * Edit agent
     */
    public function edit($agent_id) {
        $agent = $this->Agent_model->get_by_id($agent_id);
        if ($agent && !empty($agent->agent_code)) {
            redirect('clients/form/agent/' . rawurlencode($agent->agent_code));
        } else {
            redirect('clients?type=agent');
        }
        return;
    }

    /**
     * View agent details with commission tracking
     */
    public function view($agent_id) {
        $agent = $this->Agent_model->get_by_id($agent_id);
        if ($agent && !empty($agent->agent_code)) {
            redirect('clients/form/agent/' . rawurlencode($agent->agent_code));
        } else {
            redirect('clients?type=agent');
        }
        return;
    }

    /**
     * Delete agent
     */
    public function delete($agent_id) {
        redirect('clients?type=agent');
        return;
    }

    /**
     * Pay commission
     */
    public function pay_commission($commission_id) {
        if ($this->input->post()) {
            $paid_amount = $this->input->post('paid_amount');
            $payment_date = $this->input->post('payment_date');
            $payment_method = $this->input->post('payment_method');
            $notes = $this->input->post('notes');

            $this->db->set('paid_amount', 'paid_amount + ' . $paid_amount, FALSE);
            $this->db->set('payment_status', 'partial');
            $this->db->set('last_payment_date', $payment_date);
            $this->db->set('payment_method', $payment_method);
            $this->db->set('payment_notes', $notes);
            $this->db->where('commission_id', $commission_id);

            // Check if fully paid
            $this->db->where('(paid_amount + ' . $paid_amount . ') >= commission_amount', null, false);
            $this->db->set('payment_status', 'paid');

            $updated = $this->db->update('agent_commission');

            if ($updated) {
                $this->session->set_flashdata('success', 'Commission payment recorded successfully!');
            } else {
                $this->session->set_flashdata('error', 'Failed to record payment.');
            }

            // Get agent_id to redirect
            $commission = $this->db->get_where('agent_commission', ['commission_id' => $commission_id])->row();
            redirect('agents/view/' . $commission->agent_id);
        }
    }

    /**
     * Commission report
     */
    public function commission_report() {
        $from_date = $this->input->get('from_date');
        $to_date = $this->input->get('to_date');
        $agent_id = $this->input->get('agent_id');

        $this->db->select('a.agent_name, a.commission_rate,
                          COUNT(DISTINCT i.invoice_id) as total_invoices,
                          COALESCE(SUM(i.grand_total), 0) as total_sales,
                          COALESCE(SUM(ac.commission_amount), 0) as total_commission,
                          COALESCE(SUM(ac.paid_amount), 0) as commission_paid,
                          (COALESCE(SUM(ac.commission_amount), 0) - COALESCE(SUM(ac.paid_amount), 0)) as commission_due');
        $this->db->from('agent a');
        $this->db->join('invoice i', 'a.agent_id = i.agent_id', 'left');
        $this->db->join('agent_commission ac', 'i.invoice_id = ac.invoice_id', 'left');

        if ($agent_id) {
            $this->db->where('a.agent_id', $agent_id);
        }

        if ($from_date) {
            $this->db->where('i.date >=', $from_date);
        }

        if ($to_date) {
            $this->db->where('i.date <=', $to_date);
        }

        $this->db->group_by('a.agent_id');
        $this->db->order_by('total_commission', 'DESC');
        $report = $this->db->get()->result();

        // Get all agents for filter
        $agents = $this->Agent_model->get_for_dropdown();

        $data = [
            'page_title' => 'Agent Commission Report',
            'report' => $report,
            'agents' => $agents,
            'filters' => [
                'from_date' => $from_date,
                'to_date' => $to_date,
                'agent_id' => $agent_id
            ],
            'main_content' => 'agents/commission_report'
        ];

        $this->load->view('templates/modern_layout', $data);
    }
}
