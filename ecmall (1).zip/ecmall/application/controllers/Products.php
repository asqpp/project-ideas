<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Product_model');
        $this->load->model('Category_model');
        $this->load->model('Unit_model');
        $this->load->model('ProductGroup_model');
        $this->load->model('ProductSubgroup_model');
    }

    /**
     * List all products with pagination and search
     */
    public function index() {
        $page = $this->input->get('page') ?? 1;
        $search = $this->input->get('search') ?? '';

        $result = $this->Product_model->get_paginated(25, $page, $search);

        $quick_actions = [
            ['label' => 'Add Category', 'icon' => 'fa-plus', 'url' => base_url('categories/add'), 'style' => 'primary'],
            ['label' => 'Category List', 'icon' => 'fa-list', 'url' => base_url('categories'), 'style' => 'secondary'],
            ['label' => 'Add Unit', 'icon' => 'fa-ruler-combined', 'url' => base_url('units/add'), 'style' => 'secondary'],
            ['label' => 'Unit List', 'icon' => 'fa-table', 'url' => base_url('units'), 'style' => 'outline'],
            ['label' => 'Add Product', 'icon' => 'fa-box-open', 'url' => base_url('products/add'), 'style' => 'primary'],
            ['label' => 'Add Product (CSV)', 'icon' => 'fa-file-import', 'url' => base_url('products/import_csv'), 'style' => 'secondary'],
            ['label' => 'Manage Groups', 'icon' => 'fa-layer-group', 'url' => base_url('product_groups'), 'style' => 'outline'],
            ['label' => 'Manage Subgroups', 'icon' => 'fa-diagram-project', 'url' => base_url('product_subgroups'), 'style' => 'outline']
        ];

        $data = [
            'page_title' => 'Products',
            'products' => $result->data,
            'pagination' => $result,
            'search' => $search,
            'quick_actions' => $quick_actions,
            'main_content' => 'products/index'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Add new product
     */
    public function add() {
        $generated_code = $this->Product_model->generate_code();

        if ($this->input->post()) {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('product_code', 'Product Code', 'required|trim|callback_validate_product_code');
            $this->form_validation->set_rules('product_name', 'Product Name', 'required|trim');
            $this->form_validation->set_rules('category_id', 'Category', 'required');
            $this->form_validation->set_rules('unit_id', 'Unit', 'required');
            $this->form_validation->set_rules('price', 'Price', 'required|numeric');
            $this->form_validation->set_rules('default_qty', 'Default Quantity', 'numeric');
            $this->form_validation->set_rules('tax_percent', 'Tax Percentage', 'numeric');

            if ($this->form_validation->run() === TRUE) {
                $product_data = [
                    'product_code' => strtoupper($this->input->post('product_code')),
                    'product_name' => $this->input->post('product_name'),
                    'product_model' => $this->input->post('product_model'),
                    'category_id' => $this->input->post('category_id'),
                    'group_id' => $this->input->post('group_id') ?: null,
                    'subgroup_id' => $this->input->post('subgroup_id') ?: null,
                    'unit_id' => $this->input->post('unit_id'),
                    'default_qty' => $this->input->post('default_qty') ?? 1,
                    'price' => $this->input->post('price'),
                    'quantity' => $this->input->post('quantity') ?? 0,
                    'supplier_price' => $this->input->post('supplier_price') ?? 0,
                    'product_details' => $this->input->post('product_details'),
                    'status' => $this->input->post('status') ? 1 : 0,
                    'image' => $this->input->post('image'),
                    'tax_percent' => $this->input->post('tax_percent') ?? 0,
                    'taxable' => $this->input->post('taxable') ? 1 : 0,
                    'no_discount' => $this->input->post('no_discount') ? 1 : 0
                ];

                $product_id = $this->Product_model->insert($product_data);

                if ($product_id) {
                    $this->session->set_flashdata('success', 'Product added successfully!');
                    redirect('products/view/' . $product_id);
                } else {
                    $this->session->set_flashdata('error', 'Failed to add product. Please try again.');
                }
            }
        }

        // Get categories and units for dropdowns
        $categories = $this->Category_model->get_all() ?: [];
        $units = $this->Unit_model->get_all() ?: [];
        $groups = $this->ProductGroup_model->get_all() ?: [];
        $subgroups = $this->ProductSubgroup_model->get_all() ?: [];

        $data = [
            'page_title' => 'Add Product',
            'categories' => $categories,
            'units' => $units,
            'groups' => $groups,
            'subgroups' => $subgroups,
            'generated_code' => $generated_code,
            'product' => null,
            'main_content' => 'products/form'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Edit product
     */
    public function edit($product_id) {
        $product = $this->Product_model->get_by_id($product_id);

        if (!$product) {
            show_404();
        }

        if ($this->input->post()) {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('product_code', 'Product Code', 'required|trim|callback_validate_product_code[' . $product_id . ']');
            $this->form_validation->set_rules('product_name', 'Product Name', 'required|trim');
            $this->form_validation->set_rules('category_id', 'Category', 'required');
            $this->form_validation->set_rules('unit_id', 'Unit', 'required');
            $this->form_validation->set_rules('price', 'Price', 'required|numeric');
            $this->form_validation->set_rules('default_qty', 'Default Quantity', 'numeric');
            $this->form_validation->set_rules('tax_percent', 'Tax Percentage', 'numeric');

            if ($this->form_validation->run() === TRUE) {
                $product_data = [
                    'product_code' => strtoupper($this->input->post('product_code')),
                    'product_name' => $this->input->post('product_name'),
                    'product_model' => $this->input->post('product_model'),
                    'category_id' => $this->input->post('category_id'),
                    'group_id' => $this->input->post('group_id') ?: null,
                    'subgroup_id' => $this->input->post('subgroup_id') ?: null,
                    'unit_id' => $this->input->post('unit_id'),
                    'default_qty' => $this->input->post('default_qty') ?? $product->default_qty ?? 1,
                    'price' => $this->input->post('price'),
                    'supplier_price' => $this->input->post('supplier_price') ?? 0,
                    'product_details' => $this->input->post('product_details'),
                    'status' => $this->input->post('status') ? 1 : 0,
                    'image' => $this->input->post('image'),
                    'tax_percent' => $this->input->post('tax_percent') ?? 0,
                    'taxable' => $this->input->post('taxable') ? 1 : 0,
                    'no_discount' => $this->input->post('no_discount') ? 1 : 0
                ];

                $updated = $this->Product_model->update($product_id, $product_data);

                if ($updated) {
                    $this->session->set_flashdata('success', 'Product updated successfully!');
                    redirect('products/view/' . $product_id);
                } else {
                    $this->session->set_flashdata('error', 'Failed to update product. Please try again.');
                }
            }
        }

        // Get categories and units for dropdowns
        $categories = $this->Category_model->get_all() ?: [];
        $units = $this->Unit_model->get_all() ?: [];
        $groups = $this->ProductGroup_model->get_all() ?: [];
        $subgroups = $this->ProductSubgroup_model->get_all() ?: [];

        $data = [
            'page_title' => 'Edit Product',
            'categories' => $categories,
            'units' => $units,
            'groups' => $groups,
            'subgroups' => $subgroups,
            'generated_code' => $product->product_code,
            'product' => $product,
            'main_content' => 'products/form'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * View product details
     */
    public function view($product_id) {
        $product = $this->Product_model->get_with_stock($product_id);

        if (!$product) {
            show_404();
        }

        // Get stock movements from itemsstk if table exists
        $stock_movements = [];
        if ($this->db->table_exists('itemsstk')) {
            $this->db->where('code', $product_id);
            $this->db->order_by('tdate', 'DESC');
            $this->db->limit(50);
            $stock_movements = $this->db->get('itemsstk')->result();
        }

        $data = [
            'page_title' => 'Product Details',
            'product' => $product,
            'stock_movements' => $stock_movements,
            'main_content' => 'products/view'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Delete product
     */
    public function delete($product_id) {
        $product = $this->Product_model->get_by_id($product_id);

        if (!$product) {
            show_404();
        }

        // Check if product is used in any transactions
        $this->db->where('product_id', $product_id);
        $invoice_items = $this->db->count_all_results('invoice_details');

        $this->db->where('product_id', $product_id);
        $purchase_items = $this->db->count_all_results('product_purchase_details');

        if ($invoice_items > 0 || $purchase_items > 0) {
            $this->session->set_flashdata('error', 'Cannot delete product. It is used in transactions.');
            redirect('products');
        }

        $deleted = $this->Product_model->delete($product_id);

        if ($deleted) {
            $this->session->set_flashdata('success', 'Product deleted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete product. Please try again.');
        }

        redirect('products');
    }

    /**
     * Export products to CSV
     */
    public function export() {
        $products = $this->Product_model->get_all();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="products_' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Code', 'Name', 'Model', 'Category', 'Unit', 'Price', 'Supplier Price', 'Quantity', 'Tax %', 'Taxable', 'No Discount', 'Status']);

        foreach ($products as $product) {
            fputcsv($output, [
                $product->product_id,
                $product->product_code,
                $product->product_name,
                $product->product_model,
                $product->category_id,
                $product->unit_id,
                $product->price,
                $product->supplier_price,
                $product->quantity,
                $product->tax_percent ?? 0,
                ($product->taxable ?? 1) ? 'Yes' : 'No',
                ($product->no_discount ?? 0) ? 'Yes' : 'No',
                $product->status == 1 ? 'Active' : 'Inactive'
            ]);
        }

        fclose($output);
    }

    public function import_csv()
    {
        $import_summary = null;

        if ($this->input->post() && !empty($_FILES['csv_file']['tmp_name'])) {
            $file = $_FILES['csv_file']['tmp_name'];
            $handle = fopen($file, 'r');
            if ($handle !== false) {
                $header = fgetcsv($handle);
                $inserted = $updated = $skipped = 0;
                if ($header) {
                    $header = array_map('strtolower', $header);
                    while (($row = fgetcsv($handle)) !== false) {
                        $rowData = array_combine($header, $row);
                        if (!$rowData || empty($rowData['product_code']) || empty($rowData['product_name'])) {
                            $skipped++;
                            continue;
                        }

                        $categoryId = null;
                        if (!empty($rowData['category_code'])) {
                            $category = $this->Category_model->find_by_code($rowData['category_code']);
                            $categoryId = $category->category_id ?? null;
                        }

                        $groupId = null;
                        if (!empty($rowData['group_code'])) {
                            $group = $this->ProductGroup_model->find_by_code($rowData['group_code']);
                            $groupId = $group->id ?? null;
                        }

                        $subgroupId = null;
                        if (!empty($rowData['subgroup_code'])) {
                            $subgroup = $this->ProductSubgroup_model->find_by_code($rowData['subgroup_code']);
                            $subgroupId = $subgroup->id ?? null;
                        }

                        $payload = [
                            'product_code' => strtoupper(trim($rowData['product_code'])),
                            'product_name' => $rowData['product_name'],
                            'product_model' => $rowData['product_model'] ?? null,
                            'category_id' => $categoryId,
                            'group_id' => $groupId,
                            'subgroup_id' => $subgroupId,
                            'unit_id' => $rowData['unit_id'] ?? null,
                            'default_qty' => $rowData['default_qty'] ?? 1,
                            'price' => $rowData['price'] ?? 0,
                            'supplier_price' => $rowData['supplier_price'] ?? 0,
                            'quantity' => $rowData['quantity'] ?? 0,
                            'tax_percent' => $rowData['tax_percent'] ?? 0,
                            'taxable' => isset($rowData['taxable']) ? (int) $rowData['taxable'] : 1,
                            'no_discount' => isset($rowData['no_discount']) ? (int) $rowData['no_discount'] : 0,
                            'status' => isset($rowData['status']) ? (int) $rowData['status'] : 1,
                            'product_details' => $rowData['product_details'] ?? null
                        ];

                        if ($this->Product_model->code_exists($payload['product_code'])) {
                            $this->db->where('product_code', $payload['product_code']);
                            $this->db->update('product_information', $payload);
                            $updated++;
                        } else {
                            $this->Product_model->insert($payload);
                            $inserted++;
                        }
                    }
                }

                fclose($handle);
                $import_summary = compact('inserted', 'updated', 'skipped');
                $this->session->set_flashdata('success', "Imported {$inserted} products. Updated {$updated}, skipped {$skipped}.");
                redirect('products');
            }
        } elseif ($this->input->post()) {
            $this->session->set_flashdata('error', 'Please upload a CSV file.');
        }

        $data = [
            'page_title' => 'Import Products (CSV)',
            'import_summary' => $import_summary,
            'main_content' => 'products/import_csv'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Search products (for autocomplete)
     */
    public function search() {
        $term = $this->input->get('term');
        $products = $this->Product_model->search_for_autocomplete($term);

        echo json_encode($products);
    }

    /**
     * Get low stock products
     */
    public function low_stock() {
        $threshold = $this->input->get('threshold') ?? 10;
        $products = $this->Product_model->get_low_stock($threshold);

        $data = [
            'page_title' => 'Low Stock Products',
            'products' => $products,
            'threshold' => $threshold,
            'main_content' => 'products/low_stock'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function validate_product_code($code, $product_id = null)
    {
        $code = strtoupper($code);
        if ($this->Product_model->code_exists($code, $product_id ? (int) $product_id : null)) {
            $this->form_validation->set_message('validate_product_code', 'The {field} must be unique.');
            return false;
        }
        return true;
    }
}
