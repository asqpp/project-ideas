<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Legacy_purchase extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->load->model('Legacy_purchase_model');
        $this->load->model('Supplier_model');
        $this->load->model('Product_model');
        $this->load->model('Daybook_model');
        $this->load->helper(['form', 'url']);
    }

    public function index()
    {
        $page = max(1, (int) ($this->input->get('page') ?? 1));
        $search = trim($this->input->get('search') ?? '');
        $purchases = $this->Legacy_purchase_model->get_paginated(25, $page, $search);

        $data = [
            'page_title' => 'Legacy Purchases',
            'main_content' => 'purchases/legacy_index',
            'purchases' => $purchases->data,
            'pagination' => $purchases,
            'search' => $search
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function form($slno = null)
    {
        $purchase = null;
        $items = [];
        $is_edit = false;

        if ($slno) {
            $purchase = $this->Legacy_purchase_model->get_purchase((int) $slno);
            if ($purchase) {
                $items = $purchase['items'];
                $is_edit = true;
            } else {
                $this->session->set_flashdata('error', 'Purchase not found.');
                redirect('legacy_purchase');
            }
        }

        if ($this->input->method() === 'post') {
            $result = $this->handle_form_submission($purchase ? (int) $purchase['slno'] : null);
            if ($result['success']) {
                $this->session->set_flashdata('success', 'Purchase saved successfully.');
                redirect('legacy_purchase');
            }
            $this->session->set_flashdata('error', implode('<br>', $result['errors']));
            $purchase = $result['input']['purchase'];
            $items = $result['input']['items'];
            $is_edit = (bool) $slno;
        }

        $purchase = $purchase ?? [
            'docno' => $this->Legacy_purchase_model->preview_next_docno(),
            'billno' => '',
            'suppcode' => '',
            'name' => '',
            'addr' => '',
            'mobile' => '',
            'pan' => '',
            'ob' => 0,
            'discperc' => 0,
            'discount' => 0,
            'taxperc' => 5,
            'taxamt' => 0,
            'tcsperc' => 0,
            'tcsamt' => 0,
            'billamt' => 0,
            'addamt' => 0,
            'netamt' => 0,
            'pamt' => 0,
            'tdate' => date('Y-m-d'),
            'duedate' => '',
            'billtype' => '',
            'statecode' => '',
            'counter' => '',
            'note' => ''
        ];

        $data = [
            'page_title' => $is_edit ? 'Edit Purchase' : 'Add Purchase',
            'main_content' => 'purchases/legacy_form',
            'purchase' => $purchase,
            'items' => $items,
            'is_edit' => $is_edit
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    private function handle_form_submission(?int $slno): array
    {
        $errors = [];

        $suppcode = trim($this->input->post('suppcode') ?? '');
        $suppname = trim($this->input->post('suppname') ?? '');
        $billno = trim($this->input->post('billno') ?? '');
        $addr = trim($this->input->post('addr') ?? '');
        $mobile = trim($this->input->post('mobile') ?? '');
        $pan = trim($this->input->post('pan') ?? '');
        $billtype = trim($this->input->post('billtype') ?? '');
        $statecode = trim($this->input->post('statecode') ?? '');
        $counter = trim($this->input->post('counter') ?? '');
        $note = trim($this->input->post('note') ?? '');
        $date = $this->input->post('date') ?? date('Y-m-d');
        $duedate = $this->input->post('duedate') ?? null;
        $docno = trim($this->input->post('docno') ?? '');

        $discperc = (float) ($this->input->post('discperc') ?? 0);
        $taxperc = (float) ($this->input->post('taxperc') ?? 0);
        $tcsperc = (float) ($this->input->post('tcsperc') ?? 0);
        $others = (float) ($this->input->post('others') ?? 0);
        $paid = (float) ($this->input->post('pamt') ?? 0);

        $itemsInput = $this->input->post('items') ?? [];
        $items = [];
        $billtotal = 0;
        foreach ($itemsInput as $row) {
            $code = trim($row['code'] ?? '');
            $qty = (float) ($row['qty'] ?? 0);
            $rate = (float) ($row['rate'] ?? 0);
            if ($code === '' || $qty <= 0 || $rate <= 0) {
                continue;
            }
            $amount = $qty * $rate;
            $billtotal += $amount;
            $items[] = [
                'code' => $code,
                'qty' => $qty,
                'rate' => $rate,
                'amount' => $amount
            ];
        }

        if ($billtotal <= 0 || empty($items)) {
            $errors[] = 'Please add at least one valid item.';
        }

        if ($suppcode === '' && $paid < $billtotal) {
            $errors[] = 'Supplier code is required for credit purchases.';
        }

        $discount = round(($billtotal * $discperc) / 100, 2);
        $tax = round((($billtotal - $discount) * $taxperc) / 100, 2);
        $tcsamt = round((($billtotal - $discount) * $tcsperc) / 100, 2);
        $nettotal = $billtotal - $discount + $tax + $tcsamt;
        $balance = $nettotal + $others - $paid;

        $purchase = [
            'docno' => $docno,
            'billno' => $billno,
            'suppcode' => $suppcode,
            'name' => $suppname,
            'billamt' => $billtotal,
            'pamt' => $paid,
            'addamt' => $others,
            'taxamt' => $tax,
            'netamt' => $nettotal,
            'ob' => (float) ($this->input->post('ob') ?? 0),
            'taxperc' => $taxperc,
            'discperc' => $discperc,
            'discount' => $discount,
            'addr' => $addr,
            'note' => $note,
            'tdate' => $date,
            'duedate' => $duedate ?: null,
            'billtype' => $billtype,
            'statecode' => $statecode,
            'mobile' => $mobile,
            'pan' => $pan,
            'counter' => $counter,
            'tcsperc' => $tcsperc,
            'tcsamt' => $tcsamt,
            'status' => ($nettotal + $others - $paid) == 0 ? 3 : ($paid > 0 ? 2 : 1)
        ];

        if (!empty($errors)) {
            return [
                'success' => false,
                'errors' => $errors,
                'input' => ['purchase' => $purchase, 'items' => $items]
            ];
        }

        $saved = $this->Legacy_purchase_model->save($purchase, $items, $slno);

        if (!$saved) {
            return [
                'success' => false,
                'errors' => ['Failed to save purchase.'],
                'input' => ['purchase' => $purchase, 'items' => $items]
            ];
        }

        return ['success' => true];
    }
}
