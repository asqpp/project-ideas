<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounting extends CI_Controller
{
    private $pages = [];

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->load->model('Accounting_operations_model');
        $this->load->model('Account_model');
        $this->load->model('Insurance_model');
        $this->load->model('Invoice_model');
        $this->load->library('form_validation');

        $this->pages = $this->buildPages();
    }

    private function buildPages(): array
    {
        return [
            'bank_reconciliation' => [
                'title' => 'Bank Reconciliation',
                'description' => 'Match ledger entries with bank statements, flag variances and generate reconciliation statements.',
                'form' => [
                    'title' => 'Reconciliation Worksheet',
                    'fields' => [
                        ['label' => 'Bank Account', 'name' => 'bank_account', 'type' => 'select', 'options' => ['Main Account', 'Claims Account', 'Payroll Account']],
                        ['label' => 'Statement Date', 'name' => 'statement_date', 'type' => 'date'],
                        ['label' => 'Ledger Balance', 'name' => 'ledger_balance', 'type' => 'currency'],
                        ['label' => 'Statement Balance', 'name' => 'statement_balance', 'type' => 'currency'],
                        ['label' => 'Unpresented Cheques', 'name' => 'unpresented', 'type' => 'currency'],
                        ['label' => 'Deposits in Transit', 'name' => 'transit', 'type' => 'currency'],
                        ['label' => 'Adjustment Notes', 'name' => 'notes', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Match Entries', 'variant' => 'outline', 'icon' => 'fas fa-equals'],
                        ['label' => 'Finalize Statement', 'variant' => 'primary', 'icon' => 'fas fa-file-signature']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Last Reconciled', 'value' => 'Oct 31, 2025', 'icon' => 'fas fa-calendar'],
                    ['label' => 'Open Items', 'value' => '5 differences', 'icon' => 'fas fa-list-check']
                ],
                'checklist' => [
                    ['label' => 'Statement Imported', 'description' => 'Bank CSV uploaded to system'],
                    ['label' => 'Variance Explained', 'description' => 'Notes documented for audit']
                ]
            ],
            'credit_note' => [
                'title' => 'Credit Note',
                'description' => 'Issue credit notes for policy adjustments, discounts or commission claw backs.',
                'form' => [
                    'title' => 'Credit Note Entry',
                    'fields' => [
                        ['label' => 'Reference Type', 'name' => 'reference_type', 'type' => 'select', 'options' => ['Policy', 'Invoice', 'Commission']],
                        ['label' => 'Reference Number', 'name' => 'reference_number', 'placeholder' => 'Link to document'],
                        ['label' => 'Credit Date', 'name' => 'credit_date', 'type' => 'date'],
                        ['label' => 'Account Impact', 'name' => 'account_code', 'type' => 'select', 'options' => ['Accounts Receivable', 'Commission Payable']],
                        ['label' => 'Amount', 'name' => 'amount', 'type' => 'currency'],
                        ['label' => 'Reason', 'name' => 'reason', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Post Credit', 'variant' => 'primary', 'icon' => 'fas fa-arrow-down'],
                        ['label' => 'Notify Stakeholders', 'variant' => 'outline', 'icon' => 'fas fa-envelope-open']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Credits this month', 'value' => 'AED 32K', 'icon' => 'fas fa-receipt'],
                    ['label' => 'Awaiting Approval', 'value' => '2 notes', 'icon' => 'fas fa-user-check']
                ]
            ],
            'debit_note' => [
                'title' => 'Debit Note',
                'description' => 'Raise debit notes to recover premiums, fees or recoveries with double-entry validation.',
                'form' => [
                    'title' => 'Debit Note Entry',
                    'fields' => [
                        ['label' => 'Customer / Partner', 'name' => 'party', 'placeholder' => 'Search customer/partner'],
                        ['label' => 'Debit Date', 'name' => 'debit_date', 'type' => 'date'],
                        ['label' => 'Account Impact', 'name' => 'account_code', 'type' => 'select', 'options' => ['Accounts Receivable', 'Commission Receivable']],
                        ['label' => 'VAT %', 'name' => 'vat_pct', 'type' => 'number'],
                        ['label' => 'Net Amount', 'name' => 'net_amount', 'type' => 'currency'],
                        ['label' => 'Narration', 'name' => 'narration', 'type' => 'textarea', 'col_span' => 'md:col-span-2']
                    ],
                    'actions' => [
                        ['label' => 'Post Debit', 'variant' => 'primary', 'icon' => 'fas fa-arrow-up'],
                        ['label' => 'Attach Documents', 'variant' => 'outline', 'icon' => 'fas fa-paperclip']
                    ]
                ],
                'meta_cards' => [
                    ['label' => 'Debits this month', 'value' => 'AED 54K', 'icon' => 'fas fa-file-invoice-dollar'],
                    ['label' => 'Pending Receipts', 'value' => '11', 'icon' => 'fas fa-clipboard-list']
                ]
            ]
        ];
    }

    private function render(string $slug): void
    {
        if (!isset($this->pages[$slug])) {
            show_404();
        }

        $this->process_form_submission($slug);

        $config = $this->pages[$slug];
        $form_config = $this->hydrate_form_config($slug, $config['form'] ?? []);

        $data = [
            'page_title' => $config['title'],
            'page_description' => $config['description'],
            'form_title' => $form_config['title'] ?? $config['title'],
            'form_fields' => $form_config['fields'] ?? [],
            'form_actions' => $form_config['actions'] ?? $this->default_form_actions(),
            'form_action' => $form_config['action'] ?? current_url(),
            'form_method' => $form_config['method'] ?? 'post',
            'meta_cards' => $this->resolve_meta_cards($slug, $config['meta_cards'] ?? []),
            'checklist' => $config['checklist'] ?? [],
            'main_content' => 'shared/dynamic_form',
            'active_menu' => 'accounting'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function bank_reconciliation()
    {
        $this->render('bank_reconciliation');
    }

    public function credit_note()
    {
        $this->render('credit_note');
    }

    public function debit_note()
    {
        $this->render('debit_note');
    }

    private function default_form_actions(): array
    {
        return [
            ['label' => 'Save', 'variant' => 'primary', 'icon' => 'fas fa-save'],
            ['label' => 'Reset', 'variant' => 'outline', 'icon' => 'fas fa-rotate-left']
        ];
    }

    private function hydrate_form_config(string $slug, array $form): array
    {
        $fields = $form['fields'] ?? [];

        switch ($slug) {
            case 'bank_reconciliation':
                $fields = $this->inject_select_options($fields, 'bank_account', $this->bank_account_options(), 'Select Bank Account');
                break;
            case 'credit_note':
                $fields = $this->inject_select_options($fields, 'reference_type', $this->enum_options(['Policy', 'Invoice', 'Commission']));
                $fields = $this->inject_select_options($fields, 'account_code', $this->account_options(), 'Select Account');
                $fields = $this->inject_select_options($fields, 'reference_number', $this->reference_options(), 'Select Reference');
                break;
            case 'debit_note':
                $fields = $this->inject_select_options($fields, 'account_code', $this->account_options(), 'Select Account');
                break;
        }

        $form['fields'] = $fields;
        $form['action'] = current_url();
        $form['method'] = 'post';

        return $form;
    }

    private function process_form_submission(string $slug): void
    {
        if ($this->input->method() !== 'post') {
            return;
        }

        switch ($slug) {
            case 'bank_reconciliation':
                $this->form_validation->set_rules('bank_account', 'Bank Account', 'required');
                $this->form_validation->set_rules('statement_date', 'Statement Date', 'required');
                $this->form_validation->set_rules('ledger_balance', 'Ledger Balance', 'required|numeric');
                $this->form_validation->set_rules('statement_balance', 'Statement Balance', 'required|numeric');

                if ($this->form_validation->run()) {
                    $this->Accounting_operations_model->create_bank_reconciliation([
                        'bank_account' => $this->input->post('bank_account', TRUE),
                        'statement_date' => $this->input->post('statement_date', TRUE),
                        'ledger_balance' => $this->decimal_input('ledger_balance'),
                        'statement_balance' => $this->decimal_input('statement_balance'),
                        'unpresented_cheques' => $this->decimal_input('unpresented'),
                        'deposits_in_transit' => $this->decimal_input('transit'),
                        'notes' => $this->input->post('notes', TRUE)
                    ]);
                    $this->session->set_flashdata('success', 'Bank reconciliation saved.');
                    redirect(current_url());
                }
                break;

            case 'credit_note':
                $this->form_validation->set_rules('reference_type', 'Reference Type', 'required');
                $this->form_validation->set_rules('reference_number', 'Reference Number', 'required');
                $this->form_validation->set_rules('credit_date', 'Credit Date', 'required');
                $this->form_validation->set_rules('account_code', 'Account', 'required');
                $this->form_validation->set_rules('amount', 'Amount', 'required|numeric');

                if ($this->form_validation->run()) {
                    $this->Accounting_operations_model->create_credit_note([
                        'reference_type' => strtolower($this->input->post('reference_type', TRUE)),
                        'reference_number' => $this->input->post('reference_number', TRUE),
                        'entry_date' => $this->input->post('credit_date', TRUE),
                        'account_code' => $this->input->post('account_code', TRUE),
                        'amount' => $this->decimal_input('amount'),
                        'reason' => $this->input->post('reason', TRUE)
                    ]);
                    $this->session->set_flashdata('success', 'Credit note recorded.');
                    redirect(current_url());
                }
                break;

            case 'debit_note':
                $this->form_validation->set_rules('party', 'Customer / Partner', 'required');
                $this->form_validation->set_rules('debit_date', 'Debit Date', 'required');
                $this->form_validation->set_rules('account_code', 'Account', 'required');
                $this->form_validation->set_rules('vat_pct', 'VAT %', 'numeric');
                $this->form_validation->set_rules('net_amount', 'Net Amount', 'required|numeric');

                if ($this->form_validation->run()) {
                    $net = $this->decimal_input('net_amount');
                    $vat = $this->decimal_input('vat_pct');
                    $gross = $net + ($net * ($vat / 100));

                    $this->Accounting_operations_model->create_debit_note([
                        'reference_type' => 'partner',
                        'reference_number' => $this->input->post('party', TRUE),
                        'entry_date' => $this->input->post('debit_date', TRUE),
                        'account_code' => $this->input->post('account_code', TRUE),
                        'amount' => $gross,
                        'reason' => $this->input->post('narration', TRUE)
                    ]);
                    $this->session->set_flashdata('success', 'Debit note posted.');
                    redirect(current_url());
                }
                break;
        }

        if (!empty($_POST)) {
            $this->session->set_flashdata('error', 'Please fix the highlighted fields.');
        }
    }

    private function inject_select_options(array $fields, string $name, array $options, string $placeholder = '')
    {
        foreach ($fields as &$field) {
            if (($field['name'] ?? '') === $name) {
                $field['type'] = 'select';
                $field['options'] = $options;
                if ($placeholder) {
                    $field['placeholder'] = $placeholder;
                }
                break;
            }
        }
        return $fields;
    }

    private function bank_account_options(): array
    {
        $accounts = $this->Account_model->get_for_dropdown('asset');
        return array_map(function ($account) {
            return [
                'value' => $account->account_code,
                'label' => $account->account_code . ' - ' . $account->account_name
            ];
        }, $accounts);
    }

    private function account_options(): array
    {
        $accounts = $this->Account_model->get_for_dropdown();
        return array_map(function ($account) {
            return [
                'value' => $account->account_code,
                'label' => $account->account_code . ' - ' . $account->account_name
            ];
        }, $accounts);
    }

    private function reference_options(): array
    {
        $options = [];

        foreach ($this->Insurance_model->get_policy_dropdown() as $policy) {
            $options[] = [
                'value' => $policy->policy_number,
                'label' => 'Policy - ' . $policy->policy_number
            ];
        }

        $this->db->select('invoice');
        $this->db->from('invoice');
        $this->db->order_by('invoice_id', 'DESC');
        foreach ($this->db->get()->result() as $invoice) {
            $options[] = [
                'value' => 'INV:' . $invoice->invoice,
                'label' => 'Invoice - ' . $invoice->invoice
            ];
        }

        return $options;
    }

    private function enum_options(array $values): array
    {
        return array_map(function ($value) {
            return ['value' => $value, 'label' => $value];
        }, $values);
    }

    private function resolve_meta_cards(string $slug, array $defaults): array
    {
        switch ($slug) {
            case 'bank_reconciliation':
                $records = $this->Accounting_operations_model->get_bank_reconciliations(['from_date' => date('Y-m-01'), 'to_date' => date('Y-m-d')]);
                return [
                    ['label' => 'Statements This Month', 'value' => number_format(count($records)), 'icon' => 'fas fa-file-invoice'],
                    ['label' => 'Pending Differences', 'value' => number_format(array_sum(array_map(function ($row) {
                        return ($row->ledger_balance ?? 0) - ($row->statement_balance ?? 0);
                    }, $records))), 'icon' => 'fas fa-scale-unbalanced']
                ];
            case 'credit_note':
                return [
                    ['label' => 'Credit Notes', 'value' => number_format(count($this->Accounting_operations_model->get_credit_notes())), 'icon' => 'fas fa-receipt']
                ];
            case 'debit_note':
                return [
                    ['label' => 'Debit Notes', 'value' => number_format(count($this->Accounting_operations_model->get_debit_notes())), 'icon' => 'fas fa-file-invoice-dollar']
                ];
            default:
                return $defaults;
        }
    }

    private function decimal_input(string $key): float
    {
        $value = str_replace(',', '', (string) $this->input->post($key));
        return (float) ($value !== '' ? $value : 0);
    }
}
