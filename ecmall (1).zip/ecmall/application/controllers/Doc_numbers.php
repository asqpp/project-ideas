<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Doc_numbers extends CI_Controller
{
    private $generaliCodes = [
        "SERIALNO","SALESB","TSALESB","SRETURNB","PURCHASEB","DPURCHASEB",
        "PRETURNB","DPRETURNB","JEWLB","JEWLRB","PDEPB","SMITHB","SMITHRB",
        "REPAIRB","REFINEB","ORDERB","VCHNORB","VCHNOPB","VCHNOJB",
        "OTHERTSB","OTHERTPB","BCDOCNO","RM2B","RM3B","RM4B","WTRANB",
        "KRCPTNO","VCHNOKRB","VCHNOKPB"
    ];

    private $generalsCodes = [
        "SBPREF","SBLEN","SRBPREF","SRBLEN","PBPREF","PBLEN",
        "DPBPREF","DPBLEN","PRBPREF","PRBLEN","DPRBPREF","DPRBLEN",
        "JBPREF","JBLEN","JRBPREF","JRBLEN",
        "GSBPREF","GSBLEN","GSRBPREF","GSRBLEN",
        "DBPREF","DBLEN","ORDBPREF","ORDBLEN",
        "ORDBSTART","SLNOSTART"
    ];

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }
    }

    public function index()
    {
        $data = [
            'page_title' => 'Document Numbers',
            'main_content' => 'admin/doc_numbers',
            'generali_codes' => $this->generaliCodes,
            'generals_codes' => $this->generalsCodes,
            'active_menu' => 'settings'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function api()
    {
        $method = strtoupper($this->input->server('REQUEST_METHOD'));

        if ($method === 'GET') {
            $payload = [
                'generali' => $this->fetch_values('generali', $this->generaliCodes),
                'generals' => $this->fetch_values('generals', $this->generalsCodes)
            ];
            return $this->respond($payload);
        }

        if ($method === 'POST') {
            $input = json_decode($this->input->raw_input_stream, true);
            if (!is_array($input)) {
                return $this->respond(['error' => 'Invalid JSON body'], 400);
            }

            $generali = $input['generali'] ?? [];
            $generals = $input['generals'] ?? [];

            $this->db->trans_start();

            $this->update_values('generali', $generali, $this->generaliCodes);
            $this->update_values('generals', $generals, $this->generalsCodes);

            $this->db->trans_complete();

            if (!$this->db->trans_status()) {
                return $this->respond(['error' => 'Failed to update document numbers'], 500);
            }

            return $this->respond(['status' => 'success']);
        }

        return $this->respond(['error' => 'Method not allowed'], 405);
    }

    private function fetch_values(string $table, array $codes): array
    {
        $values = [];
        foreach ($codes as $code) {
            $values[$code] = $this->get_value($table, $code);
        }
        return $values;
    }

    private function update_values(string $table, array $input, array $allowedCodes): void
    {
        foreach ($allowedCodes as $code) {
            if (!array_key_exists($code, $input)) {
                continue;
            }
            $this->set_value($table, $code, $input[$code]);
        }
    }

    private function get_value(string $table, string $code): ?string
    {
        $row = $this->db
            ->select('cvalue')
            ->where('code', $code)
            ->get($table)
            ->row();

        return $row ? $row->cvalue : null;
    }

    private function set_value(string $table, string $code, $value): void
    {
        $this->db
            ->set('cvalue', $value)
            ->where('code', $code)
            ->update($table);
    }

    private function respond(array $payload, int $status = 200)
    {
        return $this->output
            ->set_status_header($status)
            ->set_content_type('application/json')
            ->set_output(json_encode($payload, JSON_UNESCAPED_UNICODE));
    }
}
