<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_access extends CI_Controller
{
    private $jewelleryKeys = [
        'ALLOWJEWLSMITHMANUALDOCNO',
        'ALLOWBCCREATIONINSMITHJEWLENTRY'
    ];

    public function __construct()
    {
        parent::__construct();

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }
    }

    public function index()
    {
        $data = [
            'page_title' => 'User Access',
            'main_content' => 'admin/user_access',
            'active_menu' => 'settings'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function api()
    {
        $method = strtoupper($this->input->server('REQUEST_METHOD'));

        if ($method === 'GET') {
            $code = trim($this->input->get('code') ?? '');
            if ($code === '') {
                $users = $this->db
                    ->select('code, name')
                    ->order_by('code', 'ASC')
                    ->get('userm')
                    ->result_array();
                return $this->respond(['users' => $users]);
            }

            $user = $this->db
                ->select('code, name, pcode, maxcredit, maxdisc, maxadjwgtbc, minvaperc, maxdiscperc')
                ->where('code', $code)
                ->get('userm')
                ->row_array();

            if (!$user) {
                return $this->respond(['error' => 'User not found.'], 404);
            }

            $menuitems = $this->db
                ->select('menuitem')
                ->where('code', $code)
                ->get('userd')
                ->result_array();

            $menuitems = array_values(array_filter(array_map(function ($row) {
                return $row['menuitem'] ?? '';
            }, $menuitems), function ($item) {
                return $item !== '' && !in_array($item, $this->jewelleryKeys, true);
            }));

            $user['pcode_display'] = !empty($user['pcode']) ? '********' : '';
            unset($user['pcode']);

            return $this->respond(['user' => $user, 'menuitems' => $menuitems]);
        }

        if ($method === 'POST') {
            $input = json_decode($this->input->raw_input_stream, true);
            if (!is_array($input)) {
                return $this->respond(['error' => 'Invalid JSON body'], 400);
            }

            $action = $input['action'] ?? '';
            $user = $input['user'] ?? [];
            $menuitems = $input['menuitems'] ?? [];

            if (!in_array($action, ['create', 'update', 'delete', 'save'], true)) {
                return $this->respond(['error' => 'Unsupported action'], 400);
            }

            $code = trim((string)($user['code'] ?? ''));
            if ($code === '') {
                return $this->respond(['error' => 'User code is required'], 400);
            }

            $this->db->trans_start();

            if ($action === 'delete') {
                $this->db->where('code', $code)->delete('userd');
                $this->db->where('code', $code)->delete('userm');
                $this->db->trans_complete();
                return $this->respond(['status' => 'deleted', 'code' => $code]);
            }

            $name = trim((string)($user['name'] ?? ''));
            $maxcredit = $this->sanitize_number($user['maxcredit'] ?? null);
            $maxdisc = $this->sanitize_number($user['maxdisc'] ?? null);
            $maxadjwgt = $this->sanitize_number($user['maxadjwgtbc'] ?? null);
            $minvaperc = $this->sanitize_number($user['minvaperc'] ?? null);
            $maxdiscperc = $this->sanitize_number($user['maxdiscperc'] ?? null);
            $plainPassword = trim((string)($user['psw'] ?? ''));

            $menuitems = $this->filter_menuitems($menuitems);

            $exists = $this->db->where('code', $code)->count_all_results('userm') > 0;

            if (!$exists) {
                $data = [
                    'code' => $code,
                    'name' => $name,
                    'pcode' => $plainPassword !== '' ? password_hash($plainPassword, PASSWORD_DEFAULT) : null,
                    'maxcredit' => $maxcredit,
                    'maxdisc' => $maxdisc,
                    'maxadjwgtbc' => $maxadjwgt,
                    'minvaperc' => $minvaperc,
                    'maxdiscperc' => $maxdiscperc
                ];
                $this->db->insert('userm', $data);
            } else {
                $data = [
                    'name' => $name,
                    'maxcredit' => $maxcredit,
                    'maxdisc' => $maxdisc,
                    'maxadjwgtbc' => $maxadjwgt,
                    'minvaperc' => $minvaperc,
                    'maxdiscperc' => $maxdiscperc
                ];
                if ($plainPassword !== '') {
                    $data['pcode'] = password_hash($plainPassword, PASSWORD_DEFAULT);
                }
                $this->db->where('code', $code)->update('userm', $data);
            }

            $this->db->where('code', $code)->delete('userd');
            if (!empty($menuitems)) {
                $batch = [];
                foreach ($menuitems as $item) {
                    $batch[] = ['code' => $code, 'menuitem' => $item];
                }
                $this->db->insert_batch('userd', $batch);
            }

            $this->db->trans_complete();

            if (!$this->db->trans_status()) {
                return $this->respond(['error' => 'Database error'], 500);
            }

            return $this->respond(['status' => 'ok', 'code' => $code, 'exists' => $exists]);
        }

        return $this->respond(['error' => 'Method not allowed'], 405);
    }

    private function filter_menuitems(array $menuitems): array
    {
        $clean = [];
        foreach ($menuitems as $item) {
            $value = trim((string)$item);
            if ($value === '' || in_array($value, $this->jewelleryKeys, true)) {
                continue;
            }
            $clean[] = $value;
        }
        return array_values(array_unique($clean));
    }

    private function sanitize_number($value): ?float
    {
        if ($value === '' || $value === null) {
            return null;
        }
        return (float)$value;
    }

    private function respond(array $payload, int $status = 200)
    {
        return $this->output
            ->set_status_header($status)
            ->set_content_type('application/json')
            ->set_output(json_encode($payload, JSON_UNESCAPED_UNICODE));
    }
}
