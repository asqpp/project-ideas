<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->load->model('Client_model');
        $this->load->model('ClientSettings_model');
        $this->load->model('AccountStructure_model');
    }

    public function index($type = null)
    {
        $type = $type ?? $this->input->get('type') ?? 'customer';
        $type = strtolower($type);
        $types = $this->Client_model->get_types();
        if (!isset($types[$type])) {
            $type = 'customer';
        }

        $page = max(1, (int) ($this->input->get('page') ?? 1));
        $search = $this->input->get('search') ?? '';
        $perPage = 25;
        $result = $this->Client_model->list($type, $perPage, $page, $search);

        $data = [
            'page_title' => 'Clients',
            'active_menu' => 'clients',
            'types' => $types,
            'active_type' => $type,
            'clients' => $result->data,
            'pagination' => $result,
            'search' => $search,
            'main_content' => 'clients/index'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function form($type = 'customer', $code = null)
    {
        $type = strtolower($type);
        $types = $this->Client_model->get_types();
        if (!isset($types[$type])) {
            $type = 'customer';
        }

        $autoConfig = $this->ClientSettings_model->get_autocode($type);
        $client = null;
        if ($code) {
            try {
                $client = $this->Client_model->get_client($type, $code);
            } catch (Exception $e) {
                $this->session->set_flashdata('error', $e->getMessage());
                redirect('clients?type=' . $type);
            }
        }

        if (!$client) {
            $client = ['advanced' => [], 'address' => []];
        }

        if (!$code && $this->input->method() !== 'post' && !empty($types[$type]['auto_code']) && !empty($autoConfig['enabled']) && empty($client['code'])) {
            $nextNumber = (int) ($autoConfig['next'] ?? 1);
            $padding = max(1, (int) ($autoConfig['padding'] ?? 4));
            $prefix = strtoupper($autoConfig['prefix'] ?? '');
            $client['code'] = $prefix . str_pad((string) $nextNumber, $padding, '0', STR_PAD_LEFT);
        }

        if ($this->input->method() === 'post') {
            $post = $this->input->post();
            $photo = $_FILES['photo'] ?? null;
            try {
                $result = $this->Client_model->save_client($type, $post, $photo);
                $this->session->set_flashdata('success', 'Client saved successfully.');
                redirect('clients/form/' . $type . '/' . rawurlencode($result['code']));
            } catch (Exception $e) {
                $this->session->set_flashdata('error', $e->getMessage());
                $client = $this->rehydrate_from_post($post);
            }
        }

        $data = [
            'page_title' => ($code ? 'Edit ' : 'Add ') . $types[$type]['singular'],
            'active_menu' => 'clients',
            'types' => $types,
            'active_type' => $type,
            'client' => $client,
            'groups' => $this->AccountStructure_model->get_groups(),
            'heads' => $this->AccountStructure_model->get_heads(),
            'auto_code' => $autoConfig,
            'is_advanced_user' => strtoupper($this->session->userdata('usertype') ?? '') === 'ADMIN',
            'main_content' => 'clients/form'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    public function delete($type, $code)
    {
        $type = strtolower($type);
        try {
            $this->Client_model->delete_client($type, $code);
            $this->session->set_flashdata('success', 'Client removed.');
        } catch (Exception $e) {
            $this->session->set_flashdata('error', $e->getMessage());
        }
        redirect('clients?type=' . $type);
    }

    private function rehydrate_from_post(array $post): array
    {
        $advanced = [
            'route' => $post['route'] ?? '',
            'area' => $post['area'] ?? '',
            'salesman' => $post['salesman'] ?? '',
            'vat_no' => $post['vat_no'] ?? '',
            'gstin' => $post['vat_no'] ?? '',
            'cr_no' => $post['cr_no'] ?? '',
            'cst' => $post['cr_no'] ?? '',
            'pan' => $post['pan'] ?? '',
            'fax' => $post['fax'] ?? '',
            'distance' => $post['distance'] ?? '',
            'card_type' => $post['card_type'] ?? '',
            'card_number' => $post['card_number'] ?? '',
            'card_points' => $post['card_points'] ?? '',
            'care_of_code' => $post['care_of_code'] ?? '',
            'commissions' => [
                'percentage' => $post['commission_pct'] ?? '',
                'cut_rate' => $post['cut_rate'] ?? '',
                'staff_commission' => $post['staff_commission'] ?? ''
            ],
            'dates' => [
                'reference_date' => $post['date'] ?? '',
                'due_date' => $post['due_date'] ?? '',
                'contract_date' => $post['contract_date'] ?? ''
            ],
            'salary' => $post['salary'] ?? '',
            'id_number' => $post['id_number'] ?? '',
            'pos_password' => $post['pos_password'] ?? '',
            'approval' => $post['approval_authority'] ?? '',
            'notes' => $post['notes'] ?? '',
            'link_phonebook' => !empty($post['link_phonebook']),
            'flags' => [
                'display' => !empty($post['display']),
                'care_of_party' => !empty($post['care_of_party']),
                'agent_staff' => !empty($post['staff_agent']),
                'print_card' => !empty($post['print_card']),
                'show_camera' => !empty($post['show_camera']),
                'update_foreign' => !empty($post['update_foreign'])
            ]
        ];

        return [
            'record_id' => $post['record_id'] ?? null,
            'code' => $post['code'] ?? '',
            'name' => $post['name'] ?? '',
            'mobile' => $post['mobile'] ?? '',
            'email' => $post['email'] ?? '',
            'phone' => $post['phone'] ?? '',
            'fax' => $post['fax'] ?? '',
            'contact_person' => $post['contact_person'] ?? '',
            'address' => [
                'addr1' => $post['addr1'] ?? '',
                'addr2' => $post['addr2'] ?? '',
                'addr3' => $post['addr3'] ?? '',
                'city' => $post['city'] ?? '',
                'state' => $post['state'] ?? '',
                'pin' => $post['pin'] ?? '',
                'country' => $post['country'] ?? ''
            ],
            'opening_balance' => $post['opening_balance'] ?? 0,
            'secondary_balance' => $post['secondary_balance'] ?? 0,
            'balance_type' => $post['balance_type'] ?? 'cr',
            'secondary_balance_type' => $post['secondary_balance_type'] ?? 'cr',
            'account_group' => $post['account_group'] ?? '',
            'bshead' => $post['bshead'] ?? '',
            'advanced' => $advanced
        ];
    }
}
