<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Reports extends CI_Controller {

    private $report_definitions = [];
    private $report_builders = [];

    public function __construct() {
        parent::__construct();
        $this->load->model('Account_model');
        $this->load->model('Daybook_model');
        $this->load->model('Invoice_model');
        $this->load->model('Purchase_model');
        $this->load->model('Insurance_model');
        $this->load->model('Hr_model');
        $this->load->model('Accounting_operations_model');
        $this->load->model('Quotation_model');
        $this->load->model('Customer_model');
        $this->load->model('Supplier_model');

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }

        $this->report_definitions = $this->defineReports();
        $this->report_builders = $this->register_report_builders();
    }

    /**
     * Trial Balance Report
     */
    public function trial_balance() {
        $as_of_date = $this->input->get('as_of_date') ?: date('Y-m-d');

        // Get trial balance from Account_model (already has the method!)
        $accounts = $this->Account_model->get_trial_balance($as_of_date);

        // Calculate totals
        $total_debit = 0;
        $total_credit = 0;

        foreach ($accounts as $account) {
            $total_debit += $account->debit_balance;
            $total_credit += $account->credit_balance;
        }

        $data = [
            'page_title' => 'Trial Balance',
            'active_menu' => 'reports',
            'main_content' => 'reports/trial_balance',
            'accounts' => $accounts,
            'total_debit' => $total_debit,
            'total_credit' => $total_credit,
            'as_of_date' => $as_of_date,
            'is_balanced' => abs($total_debit - $total_credit) < 0.01
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Cash Book Report
     */
    public function cash_book() {
        $from_date = $this->input->get('from_date') ?: date('Y-m-01');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');

        // Get cash book from Daybook_model (already has the method!)
        $entries = $this->Daybook_model->get_cash_book($from_date, $to_date);

        $data = [
            'page_title' => 'Cash Book',
            'active_menu' => 'reports',
            'main_content' => 'reports/cash_book',
            'entries' => $entries,
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Bank Book Report
     */
    public function bank_book() {
        $from_date = $this->input->get('from_date') ?: date('Y-m-01');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');
        $bank_account = $this->input->get('bank_account') ?: 'BANK';

        // Get bank book from Daybook_model
        $entries = $this->Daybook_model->get_bank_book($bank_account, $from_date, $to_date);

        $data = [
            'page_title' => 'Bank Book',
            'active_menu' => 'reports',
            'main_content' => 'reports/bank_book',
            'entries' => $entries,
            'from_date' => $from_date,
            'to_date' => $to_date,
            'bank_account' => $bank_account
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Day Book Report
     */
    public function day_book() {
        $from_date = $this->input->get('from_date') ?: date('Y-m-d');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');

        $filters = [
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $result = $this->Daybook_model->get_paginated(1000, 1, $filters);

        $data = [
            'page_title' => 'Day Book',
            'active_menu' => 'reports',
            'main_content' => 'reports/day_book',
            'entries' => $result->data,
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * General Ledger Report
     */
    public function general_ledger() {
        $account_code = $this->input->get('account_code');
        $from_date = $this->input->get('from_date') ?: date('Y-m-01');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');

        $ledger = [];
        $account = null;

        if ($account_code) {
            $account = $this->Account_model->get_by_code($account_code);
            $ledger = $this->Account_model->get_ledger($account_code, $from_date, $to_date);
        }

        // Get all accounts for dropdown
        $accounts = $this->Account_model->get_all();

        $data = [
            'page_title' => 'General Ledger',
            'active_menu' => 'reports',
            'main_content' => 'reports/general_ledger',
            'ledger' => $ledger,
            'account' => $account,
            'accounts' => $accounts,
            'account_code' => $account_code,
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Profit & Loss Statement
     */
    public function profit_loss() {
        $from_date = $this->input->get('from_date') ?: date('Y-01-01');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');

        // Get income accounts
        $this->db->select('a.accode as account_code, a.name as account_name,
            COALESCE(SUM(d.credit - d.debit), 0) as amount');
        $this->db->from('accountm a');
        $this->db->join('daybook d', 'a.accode = d.account_code', 'left');
        $this->db->where('a.actype1', 'R');
        $this->db->where('d.date >=', $from_date);
        $this->db->where('d.date <=', $to_date);
        $this->db->group_by('a.account_id');
        $income_accounts = $this->db->get()->result();

        $total_income = array_sum(array_column($income_accounts, 'amount'));

        // Get expense accounts
        $this->db->select('a.accode as account_code, a.name as account_name,
            COALESCE(SUM(d.debit - d.credit), 0) as amount');
        $this->db->from('accountm a');
        $this->db->join('daybook d', 'a.accode = d.account_code', 'left');
        $this->db->where('a.actype1', 'E');
        $this->db->where('d.date >=', $from_date);
        $this->db->where('d.date <=', $to_date);
        $this->db->group_by('a.accode');
        $expense_accounts = $this->db->get()->result();

        $total_expenses = array_sum(array_column($expense_accounts, 'amount'));
        $net_profit = $total_income - $total_expenses;

        $data = [
            'page_title' => 'Profit & Loss Statement',
            'active_menu' => 'reports',
            'main_content' => 'reports/profit_loss',
            'income_accounts' => $income_accounts,
            'expense_accounts' => $expense_accounts,
            'total_income' => $total_income,
            'total_expenses' => $total_expenses,
            'net_profit' => $net_profit,
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Sales Report
     */
    public function sales_report() {
        $from_date = $this->input->get('from_date') ?: date('Y-m-01');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');

        $filters = [
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $result = $this->Invoice_model->get_paginated(1000, 1, '', $filters);

        // Calculate totals
        $total_sales = 0;
        $total_vat = 0;
        $total_paid = 0;
        $total_outstanding = 0;

        foreach ($result->data as $invoice) {
            $total_sales += $invoice->grand_total;
            $total_vat += $invoice->vat;
        }

        $data = [
            'page_title' => 'Sales Report',
            'active_menu' => 'reports',
            'main_content' => 'reports/sales_report',
            'invoices' => $result->data,
            'total_sales' => $total_sales,
            'total_vat' => $total_vat,
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Purchase Report
     */
    public function purchase_report() {
        $from_date = $this->input->get('from_date') ?: date('Y-m-01');
        $to_date = $this->input->get('to_date') ?: date('Y-m-d');

        $filters = [
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $result = $this->Purchase_model->get_paginated(1000, 1, '', $filters);

        // Calculate totals
        $total_purchases = 0;
        $total_vat = 0;

        foreach ($result->data as $purchase) {
            $total_purchases += $purchase->grand_total_amount;
            $total_vat += ($purchase->vat ?? 0);
        }

        $data = [
            'page_title' => 'Purchase Report',
            'active_menu' => 'reports',
            'main_content' => 'reports/purchase_report',
            'purchases' => $result->data,
            'total_purchases' => $total_purchases,
            'total_vat' => $total_vat,
            'from_date' => $from_date,
            'to_date' => $to_date
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Additional consolidated report endpoints
     */
    public function balance_sheet() { $this->render_configured_report('balance_sheet'); }
    public function cash_flow_statement() { $this->render_configured_report('cash_flow'); }
    public function accounts_receivable() { $this->render_configured_report('accounts_receivable'); }
    public function accounts_payable() { $this->render_configured_report('accounts_payable'); }
    public function sales_book() { $this->render_configured_report('sales_book'); }
    public function purchase_book() { $this->render_configured_report('purchase_book'); }
    public function quotation_book() { $this->render_configured_report('quotation_book'); }
    public function sales_summary() { $this->render_configured_report('sales_summary'); }
    public function customer_sales() { $this->render_configured_report('customer_sales'); }
    public function product_sales() { $this->render_configured_report('product_sales'); }
    public function salesman_sales() { $this->render_configured_report('salesman_sales'); }
    public function credit_sales_report() { $this->render_configured_report('credit_sales'); }
    public function purchase_summary() { $this->render_configured_report('purchase_summary'); }
    public function supplier_purchase() { $this->render_configured_report('supplier_purchase'); }
    public function product_purchase() { $this->render_configured_report('product_purchase'); }
    public function policy_register() { $this->render_configured_report('policy_register'); }
    public function claims_register() { $this->render_configured_report('claims_register'); }
    public function premium_analysis() { $this->render_configured_report('premium_analysis'); }
    public function commission_report() { $this->render_configured_report('commission_report'); }
    public function loss_ratio_analysis() { $this->render_configured_report('loss_ratio'); }
    public function renewal_tracker() { $this->render_configured_report('renewal_tracker'); }
    public function customer_list() { $this->render_configured_report('customer_list'); }
    public function customer_ledger() { $this->render_configured_report('customer_ledger'); }
    public function customer_ageing() { $this->render_configured_report('customer_ageing'); }
    public function outstanding_report() { $this->render_configured_report('outstanding_report'); }
    public function attendance_report() { $this->render_configured_report('attendance_report'); }
    public function leave_report() { $this->render_configured_report('leave_report'); }
    public function payroll_report() { $this->render_configured_report('payroll_report'); }
    public function salary_register() { $this->render_configured_report('salary_register'); }

    private function render_configured_report(string $slug): void
    {
        if (!isset($this->report_definitions[$slug])) {
            show_404();
        }

        $config = $this->report_definitions[$slug];
        $filters = $this->input->get();
        $per_page = (int) ($filters['per_page'] ?? 25);
        $per_page = $per_page > 0 ? $per_page : 25;
        $page = max(1, (int) ($filters['page'] ?? 1));

        $dataset = null;
        if (isset($this->report_builders[$slug])) {
            $builder = $this->report_builders[$slug];
            $dataset = $this->{$builder}($filters, $per_page, $page);
        }

        if ($dataset && $this->input->get('export') === 'csv') {
            $this->export_csv($slug, $dataset['columns'], $dataset['rows']);
            return;
        }

        if ($dataset) {
            $config['columns'] = $dataset['columns'];
            $config['rows'] = $dataset['rows'];
            $config['summary_cards'] = $dataset['summary_cards'] ?? ($config['summary_cards'] ?? []);
            $config['pagination'] = $dataset['pagination'] ?? null;
        }

        $data = [
            'page_title' => $config['title'],
            'page_description' => $config['description'] ?? '',
            'filters' => $config['filters'] ?? [],
            'summary_cards' => $config['summary_cards'] ?? [],
            'columns' => $config['columns'] ?? [],
            'rows' => $config['rows'] ?? [],
            'notes' => $config['notes'] ?? [],
            'empty_state' => $config['empty_state'] ?? null,
            'actions' => $config['actions'] ?? [],
            'pagination' => $config['pagination'] ?? null,
            'active_menu' => 'reports',
            'main_content' => 'shared/report_page'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    private function defineReports(): array
    {
        $reports = [];

        $reports['balance_sheet'] = [
            'title' => 'Balance Sheet',
            'description' => 'Snapshot of assets, liabilities and equity across Insurance ERP branches.',
            'filters' => $this->asOfFilter(),
            'summary_cards' => [
                ['label' => 'Total Assets', 'value' => 'AED 5.2M', 'trend' => '+4.1% vs LY', 'trend_positive' => true],
                ['label' => 'Total Liabilities', 'value' => 'AED 3.1M'],
                ['label' => 'Shareholder Equity', 'value' => 'AED 2.1M'],
                ['label' => 'Working Capital', 'value' => 'AED 1.2M']
            ],
            'columns' => [
                ['label' => 'Account', 'key' => 'account'],
                ['label' => 'Category', 'key' => 'category'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right']
            ],
            'rows' => [
                ['account' => 'Cash & Bank', 'category' => 'Current Assets', 'amount' => 'AED 980,000'],
                ['account' => 'Accounts Receivable', 'category' => 'Current Assets', 'amount' => 'AED 640,000'],
                ['account' => 'Deferred Acquisition Cost', 'category' => 'Non Current Assets', 'amount' => 'AED 420,000'],
                ['account' => 'Accounts Payable', 'category' => 'Current Liabilities', 'amount' => 'AED 510,000'],
                ['account' => 'Unearned Premium Reserve', 'category' => 'Non Current Liabilities', 'amount' => 'AED 1,120,000']
            ],
            'notes' => [
                [
                    'title' => 'Account Structure',
                    'icon' => 'fas fa-sitemap',
                    'items' => [
                        ['label' => 'Dashboard', 'description' => 'Overview, company & branch insights with notifications.'],
                        ['label' => 'Masters', 'description' => 'Manage customers, brokers, suppliers & products.']
                    ]
                ]
            ]
        ];

        $reports['cash_flow'] = [
            'title' => 'Cash Flow Statement',
            'description' => 'Operating, investing and financing cash movements with comparison to last period.',
            'filters' => $this->dateRangeFilters(),
            'summary_cards' => [
                ['label' => 'Operating Cash Flow', 'value' => 'AED 612K', 'trend' => '+12% vs LY', 'trend_positive' => true],
                ['label' => 'Investing Cash Flow', 'value' => '-AED 180K'],
                ['label' => 'Financing Cash Flow', 'value' => 'AED 95K'],
                ['label' => 'Closing Cash', 'value' => 'AED 842K']
            ],
            'columns' => [
                ['label' => 'Activity', 'key' => 'activity'],
                ['label' => 'Description', 'key' => 'description'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right']
            ],
            'rows' => [
                ['activity' => 'Operating', 'description' => 'Premium collections less claims paid', 'amount' => 'AED 612,000'],
                ['activity' => 'Investing', 'description' => 'Technology & capital investments', 'amount' => '-AED 180,000'],
                ['activity' => 'Financing', 'description' => 'Loan repayments & shareholder funding', 'amount' => 'AED 95,000']
            ]
        ];

        $reports['accounts_receivable'] = [
            'title' => 'Accounts Receivable',
            'description' => 'Customer wise receivable position with due dates and credit follow-up.',
            'filters' => $this->dateRangeFilters(),
            'summary_cards' => [
                ['label' => 'Total Receivables', 'value' => 'AED 742K'],
                ['label' => 'Current', 'value' => 'AED 402K'],
                ['label' => 'Past Due', 'value' => 'AED 340K', 'trend' => '46% > 60 days']
            ],
            'columns' => [
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Reference', 'key' => 'reference'],
                ['label' => 'Due Date', 'key' => 'due_date'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => [
                ['customer' => 'Allied Insurance Brokers', 'reference' => 'INV-2025-118', 'due_date' => '05 Feb 2025', 'amount' => 'AED 82,500', 'status' => 'Current'],
                ['customer' => 'Prime Medical Group', 'reference' => 'INV-2025-097', 'due_date' => '21 Jan 2025', 'amount' => 'AED 134,200', 'status' => 'Overdue 15d'],
                ['customer' => 'Emirates Trading LLC', 'reference' => 'INV-2024-441', 'due_date' => '15 Dec 2024', 'amount' => 'AED 214,750', 'status' => 'Overdue 60d']
            ]
        ];

        $reports['accounts_payable'] = [
            'title' => 'Accounts Payable',
            'description' => 'Supplier liabilities by age bucket and payment owner.',
            'filters' => $this->dateRangeFilters(),
            'summary_cards' => [
                ['label' => 'Total Payables', 'value' => 'AED 533K'],
                ['label' => 'Due this week', 'value' => 'AED 95K'],
                ['label' => 'Average Days', 'value' => '36 days']
            ],
            'columns' => [
                ['label' => 'Supplier', 'key' => 'supplier'],
                ['label' => 'Bill No', 'key' => 'bill'],
                ['label' => 'Due Date', 'key' => 'due_date'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Owner', 'key' => 'owner']
            ],
            'rows' => [
                ['supplier' => 'HealthFirst TPA', 'bill' => 'PB-5521', 'due_date' => '07 Feb 2025', 'amount' => 'AED 62,100', 'owner' => 'Finance'],
                ['supplier' => 'Motor Repairs LLC', 'bill' => 'PB-5498', 'due_date' => '28 Jan 2025', 'amount' => 'AED 38,900', 'owner' => 'Claims'],
                ['supplier' => 'Reinsurance Co.', 'bill' => 'PB-5484', 'due_date' => '18 Jan 2025', 'amount' => 'AED 211,000', 'owner' => 'Reinsurance']
            ]
        ];

        $reports['sales_book'] = [
            'title' => 'Sales Book',
            'description' => 'Chronological log of invoices generated from Transactions module.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Invoice', 'key' => 'reference'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => [
                ['date' => '03 Jan 2025', 'reference' => 'INV-2025-122', 'customer' => 'Global Transport LLC', 'amount' => 'AED 48,900', 'status' => 'Paid'],
                ['date' => '05 Jan 2025', 'reference' => 'INV-2025-123', 'customer' => 'Alpha Holdings', 'amount' => 'AED 112,400', 'status' => 'Partially Paid'],
                ['date' => '07 Jan 2025', 'reference' => 'INV-2025-124', 'customer' => 'Sunrise Clinics', 'amount' => 'AED 86,650', 'status' => 'Pending']
            ]
        ];

        $reports['purchase_book'] = [
            'title' => 'Purchase Book',
            'description' => 'List of supplier bills posted from Purchase module.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Bill', 'key' => 'reference'],
                ['label' => 'Supplier', 'key' => 'supplier'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => [
                ['date' => '02 Jan 2025', 'reference' => 'PB-5632', 'supplier' => 'Insurance Authority', 'amount' => 'AED 32,840', 'status' => 'Paid'],
                ['date' => '04 Jan 2025', 'reference' => 'PB-5633', 'supplier' => 'Claims Garage', 'amount' => 'AED 18,250', 'status' => 'Pending'],
                ['date' => '05 Jan 2025', 'reference' => 'PB-5634', 'supplier' => 'IT Services', 'amount' => 'AED 14,000', 'status' => 'Pending']
            ]
        ];

        $reports['quotation_book'] = [
            'title' => 'Quotation Book',
            'description' => 'Track quotes issued with validity and conversion ratio.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Quotation #', 'key' => 'reference'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Value', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Validity', 'key' => 'validity']
            ],
            'rows' => [
                ['date' => '10 Jan 2025', 'reference' => 'QT-2025-019', 'customer' => 'Metro Logistics', 'amount' => 'AED 65,000', 'validity' => '30 days'],
                ['date' => '11 Jan 2025', 'reference' => 'QT-2025-020', 'customer' => 'Starlight Hotels', 'amount' => 'AED 145,500', 'validity' => '45 days']
            ]
        ];

        $reports['sales_summary'] = [
            'title' => 'Sales Summary',
            'description' => 'Month wise sales trend with conversion and collection percentages.',
            'filters' => $this->dateRangeFilters(),
            'summary_cards' => [
                ['label' => 'YTD Premium', 'value' => 'AED 12.4M', 'trend' => '+9% YoY', 'trend_positive' => true],
                ['label' => 'Conversion', 'value' => '62%'],
                ['label' => 'Collection', 'value' => '88%']
            ],
            'columns' => [
                ['label' => 'Period', 'key' => 'period'],
                ['label' => 'Policies', 'key' => 'policies'],
                ['label' => 'Revenue', 'key' => 'revenue', 'align' => 'right'],
                ['label' => 'Collection %', 'key' => 'collection', 'align' => 'right']
            ],
            'rows' => [
                ['period' => 'Oct 2024', 'policies' => '142', 'revenue' => 'AED 1.05M', 'collection' => '84%'],
                ['period' => 'Nov 2024', 'policies' => '151', 'revenue' => 'AED 1.18M', 'collection' => '89%'],
                ['period' => 'Dec 2024', 'policies' => '167', 'revenue' => 'AED 1.32M', 'collection' => '91%']
            ]
        ];

        $reports['customer_sales'] = [
            'title' => 'Customer Wise Sales',
            'description' => 'Top customers with premium split and outstanding balances.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Policies', 'key' => 'policies'],
                ['label' => 'Premium', 'key' => 'premium', 'align' => 'right'],
                ['label' => 'Outstanding', 'key' => 'outstanding', 'align' => 'right']
            ],
            'rows' => [
                ['customer' => 'Prime Medical Group', 'policies' => '42', 'premium' => 'AED 1.82M', 'outstanding' => 'AED 210K'],
                ['customer' => 'Metro Logistics', 'policies' => '28', 'premium' => 'AED 0.98M', 'outstanding' => 'AED 45K']
            ]
        ];

        $reports['product_sales'] = [
            'title' => 'Product Wise Sales',
            'description' => 'Policy count and premium share by product line.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Product', 'key' => 'product'],
                ['label' => 'Policies', 'key' => 'policies'],
                ['label' => 'Premium', 'key' => 'premium', 'align' => 'right'],
                ['label' => 'Share %', 'key' => 'share', 'align' => 'right']
            ],
            'rows' => [
                ['product' => 'Motor Comprehensive', 'policies' => '214', 'premium' => 'AED 4.32M', 'share' => '35%'],
                ['product' => 'Medical Corporate', 'policies' => '87', 'premium' => 'AED 3.65M', 'share' => '29%'],
                ['product' => 'Property All Risk', 'policies' => '41', 'premium' => 'AED 2.12M', 'share' => '17%']
            ]
        ];

        $reports['salesman_sales'] = [
            'title' => 'Salesman Wise Sales',
            'description' => 'Performance by sales owners with conversion ratios.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Salesperson', 'key' => 'owner'],
                ['label' => 'Policies', 'key' => 'policies'],
                ['label' => 'Revenue', 'key' => 'revenue', 'align' => 'right'],
                ['label' => 'Conversion %', 'key' => 'conversion', 'align' => 'right']
            ],
            'rows' => [
                ['owner' => 'Sara Al Zaabi', 'policies' => '76', 'revenue' => 'AED 1.42M', 'conversion' => '64%'],
                ['owner' => 'Dinesh Kumar', 'policies' => '68', 'revenue' => 'AED 1.15M', 'conversion' => '59%']
            ]
        ];

        $reports['credit_sales'] = [
            'title' => 'Credit Sales Report',
            'description' => 'Invoices on credit terms with ageing buckets.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Invoice', 'key' => 'reference'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Due Date', 'key' => 'due_date'],
                ['label' => 'Ageing', 'key' => 'ageing'],
                ['label' => 'Outstanding', 'key' => 'amount', 'align' => 'right']
            ],
            'rows' => [
                ['reference' => 'INV-2024-441', 'customer' => 'Emirates Trading LLC', 'due_date' => '15 Dec 2024', 'ageing' => '60+ days', 'amount' => 'AED 214,750'],
                ['reference' => 'INV-2025-097', 'customer' => 'Prime Medical Group', 'due_date' => '21 Jan 2025', 'ageing' => '15 days', 'amount' => 'AED 134,200']
            ]
        ];

        $reports['purchase_summary'] = [
            'title' => 'Purchase Summary',
            'description' => 'Month wise purchases with VAT split.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Period', 'key' => 'period'],
                ['label' => 'Bills', 'key' => 'bills'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'VAT', 'key' => 'vat', 'align' => 'right']
            ],
            'rows' => [
                ['period' => 'Oct 2024', 'bills' => '64', 'amount' => 'AED 612K', 'vat' => 'AED 30K'],
                ['period' => 'Nov 2024', 'bills' => '59', 'amount' => 'AED 588K', 'vat' => 'AED 28K']
            ]
        ];

        $reports['supplier_purchase'] = [
            'title' => 'Supplier Wise Purchase',
            'description' => 'Top suppliers with spend and credit terms.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Supplier', 'key' => 'supplier'],
                ['label' => 'Bills', 'key' => 'bills'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Credit Days', 'key' => 'credit_days', 'align' => 'right']
            ],
            'rows' => [
                ['supplier' => 'Reinsurance Co.', 'bills' => '12', 'amount' => 'AED 1.12M', 'credit_days' => '45'],
                ['supplier' => 'HealthFirst TPA', 'bills' => '18', 'amount' => 'AED 0.54M', 'credit_days' => '30']
            ]
        ];

        $reports['product_purchase'] = [
            'title' => 'Product Wise Purchase',
            'description' => 'Spend by expense category.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Category', 'key' => 'category'],
                ['label' => 'Quantity', 'key' => 'quantity'],
                ['label' => 'Spend', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Share', 'key' => 'share', 'align' => 'right']
            ],
            'rows' => [
                ['category' => 'Claims Repairs', 'quantity' => '218 jobs', 'amount' => 'AED 0.68M', 'share' => '38%'],
                ['category' => 'Medical Network', 'quantity' => '52 approvals', 'amount' => 'AED 0.41M', 'share' => '23%']
            ]
        ];

        $reports['policy_register'] = [
            'title' => 'Policy Register',
            'description' => 'Policy issuance register with coverage dates and premium.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Policy No', 'key' => 'policy'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Effective', 'key' => 'effective'],
                ['label' => 'Expiry', 'key' => 'expiry'],
                ['label' => 'Premium', 'key' => 'premium', 'align' => 'right']
            ],
            'rows' => [
                ['policy' => 'POL-2025-00045', 'customer' => 'Metro Logistics', 'effective' => '01 Jan 2025', 'expiry' => '31 Dec 2025', 'premium' => 'AED 265,000'],
                ['policy' => 'POL-2025-00046', 'customer' => 'Starlight Hotels', 'effective' => '05 Jan 2025', 'expiry' => '04 Jan 2026', 'premium' => 'AED 410,000']
            ]
        ];

        $reports['claims_register'] = [
            'title' => 'Claims Register',
            'description' => 'Claims lifecycle overview with reserves and status.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Claim No', 'key' => 'claim'],
                ['label' => 'Policy', 'key' => 'policy'],
                ['label' => 'Type', 'key' => 'type'],
                ['label' => 'Reserve', 'key' => 'reserve', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => [
                ['claim' => 'CLM-2025-0031', 'policy' => 'POL-2024-0088', 'type' => 'Motor', 'reserve' => 'AED 28,500', 'status' => 'Assessment'],
                ['claim' => 'CLM-2025-0032', 'policy' => 'POL-2024-0041', 'type' => 'Medical', 'reserve' => 'AED 42,100', 'status' => 'Approved']
            ]
        ];

        $reports['premium_analysis'] = [
            'title' => 'Premium Analysis',
            'description' => 'Written vs earned premium by customer segment.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Segment', 'key' => 'segment'],
                ['label' => 'Policies', 'key' => 'policies'],
                ['label' => 'Written Premium', 'key' => 'written', 'align' => 'right'],
                ['label' => 'Earned Premium', 'key' => 'earned', 'align' => 'right']
            ],
            'rows' => [
                ['segment' => 'Corporate', 'policies' => '124', 'written' => 'AED 6.8M', 'earned' => 'AED 4.3M'],
                ['segment' => 'Retail', 'policies' => '298', 'written' => 'AED 2.6M', 'earned' => 'AED 1.9M']
            ]
        ];

        $reports['commission_report'] = [
            'title' => 'Commission Report',
            'description' => 'Broker/agent commissions with rate and payout schedule.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Partner', 'key' => 'partner'],
                ['label' => 'Policies', 'key' => 'policies'],
                ['label' => 'Rate %', 'key' => 'rate', 'align' => 'right'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => [
                ['partner' => 'Allied Brokers', 'policies' => '24', 'rate' => '17%', 'amount' => 'AED 148,200', 'status' => 'Approved'],
                ['partner' => 'Swift Agents', 'policies' => '18', 'rate' => '12%', 'amount' => 'AED 68,400', 'status' => 'Pending']
            ]
        ];

        $reports['loss_ratio'] = [
            'title' => 'Loss Ratio Analysis',
            'description' => 'Written premium vs claims paid by product to monitor profitability.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Segment', 'key' => 'segment'],
                ['label' => 'Written Premium', 'key' => 'written', 'align' => 'right'],
                ['label' => 'Claims Paid', 'key' => 'claims', 'align' => 'right'],
                ['label' => 'Loss Ratio', 'key' => 'ratio', 'align' => 'right']
            ],
            'rows' => [
                ['segment' => 'Motor', 'written' => 'AED 4.3M', 'claims' => 'AED 2.1M', 'ratio' => '49%'],
                ['segment' => 'Medical', 'written' => 'AED 3.6M', 'claims' => 'AED 2.9M', 'ratio' => '81%']
            ]
        ];

        $reports['renewal_tracker'] = [
            'title' => 'Renewal Tracker',
            'description' => 'Policies approaching expiry with owner assignment.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Policy', 'key' => 'policy'],
                ['label' => 'Expiry', 'key' => 'expiry'],
                ['label' => 'Owner', 'key' => 'owner'],
                ['label' => 'Status', 'key' => 'status'],
                ['label' => 'Premium', 'key' => 'premium', 'align' => 'right']
            ],
            'rows' => [
                ['policy' => 'POL-2024-0112', 'expiry' => '12 Feb 2025', 'owner' => 'Renewal Desk', 'status' => 'Proposal Sent', 'premium' => 'AED 128,400'],
                ['policy' => 'POL-2024-0098', 'expiry' => '05 Feb 2025', 'owner' => 'Agent Team', 'status' => 'Negotiation', 'premium' => 'AED 86,930']
            ]
        ];

        $reports['customer_list'] = [
            'title' => 'Customer List',
            'description' => 'Master list with outstanding balances.',
            'filters' => [],
            'columns' => [
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Category', 'key' => 'category'],
                ['label' => 'Primary Contact', 'key' => 'contact'],
                ['label' => 'Outstanding', 'key' => 'outstanding', 'align' => 'right']
            ],
            'rows' => [
                ['customer' => 'Prime Medical Group', 'category' => 'Corporate', 'contact' => 'finance@pmg.ae', 'outstanding' => 'AED 210K'],
                ['customer' => 'Metro Logistics', 'category' => 'Corporate', 'contact' => 'accounts@metro-logistics.ae', 'outstanding' => 'AED 45K']
            ]
        ];

        $reports['customer_ledger'] = [
            'title' => 'Customer Ledger',
            'description' => 'Detailed ledger with running balance.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Reference', 'key' => 'reference'],
                ['label' => 'Debit', 'key' => 'debit', 'align' => 'right'],
                ['label' => 'Credit', 'key' => 'credit', 'align' => 'right'],
                ['label' => 'Balance', 'key' => 'balance', 'align' => 'right']
            ],
            'rows' => [
                ['date' => '02 Jan 2025', 'reference' => 'INV-2025-123', 'debit' => 'AED 112,400', 'credit' => '-', 'balance' => 'AED 112,400'],
                ['date' => '09 Jan 2025', 'reference' => 'RCPT-986', 'debit' => '-', 'credit' => 'AED 50,000', 'balance' => 'AED 62,400']
            ]
        ];

        $reports['customer_ageing'] = [
            'title' => 'Customer Ageing',
            'description' => 'Receivable ageing buckets with percentage mix.',
            'filters' => [],
            'columns' => [
                ['label' => 'Bucket', 'key' => 'bucket'],
                ['label' => 'Invoices', 'key' => 'invoices'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Mix %', 'key' => 'mix', 'align' => 'right']
            ],
            'rows' => [
                ['bucket' => 'Current (0-30)', 'invoices' => '54', 'amount' => 'AED 402K', 'mix' => '54%'],
                ['bucket' => '31-60 Days', 'invoices' => '19', 'amount' => 'AED 126K', 'mix' => '17%'],
                ['bucket' => '61-90 Days', 'invoices' => '11', 'amount' => 'AED 94K', 'mix' => '13%'],
                ['bucket' => '90+ Days', 'invoices' => '7', 'amount' => 'AED 120K', 'mix' => '16%']
            ]
        ];

        $reports['outstanding_report'] = [
            'title' => 'Outstanding Report',
            'description' => 'Customer wise overdue tracker with owner assignment.',
            'filters' => [],
            'columns' => [
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Oldest Invoice', 'key' => 'reference'],
                ['label' => 'Days', 'key' => 'days', 'align' => 'right'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Owner', 'key' => 'owner']
            ],
            'rows' => [
                ['customer' => 'Emirates Trading LLC', 'reference' => 'INV-2024-441', 'days' => '60+', 'amount' => 'AED 214K', 'owner' => 'Collections'],
                ['customer' => 'Prime Medical Group', 'reference' => 'INV-2025-097', 'days' => '15', 'amount' => 'AED 134K', 'owner' => 'Finance']
            ]
        ];

        $reports['attendance_report'] = [
            'title' => 'Attendance Report',
            'description' => 'HR attendance dashboard for compliance and payroll syncing.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Employee', 'key' => 'employee'],
                ['label' => 'Present Days', 'key' => 'present', 'align' => 'right'],
                ['label' => 'Absent Days', 'key' => 'absent', 'align' => 'right'],
                ['label' => 'Late Entries', 'key' => 'late', 'align' => 'right'],
                ['label' => 'Location', 'key' => 'location']
            ],
            'rows' => [
                ['employee' => 'Sara Al Zaabi', 'present' => '22', 'absent' => '0', 'late' => '1', 'location' => 'Head Office'],
                ['employee' => 'Dinesh Kumar', 'present' => '20', 'absent' => '1', 'late' => '2', 'location' => 'Client Site']
            ]
        ];

        $reports['leave_report'] = [
            'title' => 'Leave Report',
            'description' => 'Leave utilization with approval status.',
            'filters' => $this->dateRangeFilters(),
            'columns' => [
                ['label' => 'Employee', 'key' => 'employee'],
                ['label' => 'Leave Type', 'key' => 'leave_type'],
                ['label' => 'Days', 'key' => 'days', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status'],
                ['label' => 'Approver', 'key' => 'approver']
            ],
            'rows' => [
                ['employee' => 'Huda Salem', 'leave_type' => 'Annual', 'days' => '5', 'status' => 'Approved', 'approver' => 'HR'],
                ['employee' => 'Lee Wong', 'leave_type' => 'Sick', 'days' => '2', 'status' => 'Pending', 'approver' => 'Operations']
            ]
        ];

        $reports['payroll_report'] = [
            'title' => 'Payroll Report',
            'description' => 'Payroll cycle summary ready for WPS/export.',
            'filters' => [],
            'columns' => [
                ['label' => 'Employee', 'key' => 'employee'],
                ['label' => 'Basic', 'key' => 'basic', 'align' => 'right'],
                ['label' => 'Allowances', 'key' => 'allowances', 'align' => 'right'],
                ['label' => 'Deductions', 'key' => 'deductions', 'align' => 'right'],
                ['label' => 'Net Pay', 'key' => 'net', 'align' => 'right']
            ],
            'rows' => [
                ['employee' => 'Sara Al Zaabi', 'basic' => 'AED 12,000', 'allowances' => 'AED 5,500', 'deductions' => 'AED 500', 'net' => 'AED 17,000'],
                ['employee' => 'Dinesh Kumar', 'basic' => 'AED 9,000', 'allowances' => 'AED 3,200', 'deductions' => 'AED 300', 'net' => 'AED 11,900']
            ]
        ];

        $reports['salary_register'] = [
            'title' => 'Salary Register',
            'description' => 'Bank/WPS ready salary register with payment status.',
            'filters' => [],
            'columns' => [
                ['label' => 'Employee', 'key' => 'employee'],
                ['label' => 'IBAN', 'key' => 'iban'],
                ['label' => 'Net Pay', 'key' => 'net', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => [
                ['employee' => 'Sara Al Zaabi', 'iban' => 'AE45 1234 5698 0001', 'net' => 'AED 17,000', 'status' => 'Processed'],
                ['employee' => 'Dinesh Kumar', 'iban' => 'AE09 9988 2211 0044', 'net' => 'AED 11,900', 'status' => 'Pending']
            ]
        ];

        return $reports;
    }

    private function register_report_builders(): array
    {
        return [
            'balance_sheet' => 'dataset_balance_sheet',
            'accounts_receivable' => 'dataset_accounts_receivable',
            'accounts_payable' => 'dataset_accounts_payable',
            'sales_book' => 'dataset_sales_book',
            'purchase_book' => 'dataset_purchase_book',
            'quotation_book' => 'dataset_quotation_book',
            'sales_summary' => 'dataset_sales_summary',
            'purchase_summary' => 'dataset_purchase_summary',
            'policy_register' => 'dataset_policy_register',
            'claims_register' => 'dataset_claims_register',
            'commission_report' => 'dataset_commission_report',
            'premium_analysis' => 'dataset_premium_analysis',
            'loss_ratio' => 'dataset_loss_ratio',
            'renewal_tracker' => 'dataset_renewal_tracker',
            'customer_list' => 'dataset_customer_list',
            'customer_ageing' => 'dataset_customer_ageing',
            'outstanding_report' => 'dataset_outstanding_report',
            'attendance_report' => 'dataset_attendance_report',
            'leave_report' => 'dataset_leave_report',
            'payroll_report' => 'dataset_payroll_report',
            'salary_register' => 'dataset_salary_register',
        ];
    }

    private function dateRangeFilters(): array
    {
        return [
            ['label' => 'From Date', 'type' => 'date', 'name' => 'from_date'],
            ['label' => 'To Date', 'type' => 'date', 'name' => 'to_date']
        ];
    }

    private function asOfFilter(string $label = 'As of Date', string $name = 'as_of_date'): array
    {
        return [
            ['label' => $label, 'type' => 'date', 'name' => $name]
        ];
    }

    private function pagination_meta(int $total, int $per_page, int $page): array
    {
        $total_pages = max(1, (int) ceil(max(1, $total) / max(1, $per_page)));
        $page = min($page, $total_pages);

        return [
            'total' => $total,
            'per_page' => $per_page,
            'current_page' => $page,
            'total_pages' => $total_pages,
            'from' => $total ? (($page - 1) * $per_page) + 1 : 0,
            'to' => min($total, $page * $per_page)
        ];
    }

    private function dataset_balance_sheet(array $filters, int $per_page, int $page): array
    {
        $as_of = $filters['as_of_date'] ?? date('Y-m-d');
        $accounts = $this->Account_model->get_trial_balance($as_of);

        $rows = [];
        $assets = $liabilities = $equity = 0;

        foreach ($accounts as $account) {
            $amount = $account->balance ?? 0;
            $rows[] = [
                'account' => $account->account_name,
                'category' => ucfirst($account->account_type),
                'amount' => number_format($amount, 2)
            ];

            switch ($account->account_type) {
                case 'asset':
                    $assets += $amount;
                    break;
                case 'liability':
                    $liabilities += $amount;
                    break;
                case 'equity':
                    $equity += $amount;
                    break;
            }
        }

        $total = count($rows);
        $offset = ($page - 1) * $per_page;
        $paginated_rows = array_slice($rows, $offset, $per_page);

        return [
            'columns' => [
                ['label' => 'Account', 'key' => 'account'],
                ['label' => 'Category', 'key' => 'category'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right']
            ],
            'rows' => $paginated_rows,
            'summary_cards' => [
                ['label' => 'Assets', 'value' => 'AED ' . number_format($assets, 2)],
                ['label' => 'Liabilities', 'value' => 'AED ' . number_format($liabilities, 2)],
                ['label' => 'Equity', 'value' => 'AED ' . number_format($equity, 2)],
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_accounts_receivable(array $filters, int $per_page, int $page): array
    {
        $this->db->start_cache();
        $this->db->select('i.invoice, i.date, c.customer_name, i.due_amount, i.payment_status');
        $this->db->from('invoice i');
        $this->db->join('customer_information c', 'c.customer_id = i.customer_id', 'left');
        $this->db->where('i.due_amount >', 0);

        if (!empty($filters['from_date'])) {
            $this->db->where('i.date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $this->db->where('i.date <=', $filters['to_date']);
        }
        $this->db->stop_cache();

        $total = $this->db->count_all_results();
        $offset = ($page - 1) * $per_page;
        $rows = $this->db
            ->order_by('i.date', 'DESC')
            ->limit($per_page, $offset)
            ->get()
            ->result();
        $this->db->flush_cache();

        $rows = array_map(function ($row) {
            return [
                'invoice' => $row->invoice,
                'customer' => $row->customer_name,
                'date' => format_date($row->date),
                'amount' => number_format($row->due_amount, 2),
                'status' => ucfirst($row->payment_status)
            ];
        }, $rows);

        $this->db->select_sum('due_amount', 'total_due');
        $sum_row = $this->db->get('invoice')->row();
        $total_due = (float) ($sum_row->total_due ?? 0);

        return [
            'columns' => [
                ['label' => 'Invoice', 'key' => 'invoice'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Outstanding', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Outstanding', 'value' => 'AED ' . number_format($total_due, 2)],
                ['label' => 'Invoices', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_accounts_payable(array $filters, int $per_page, int $page): array
    {
        $this->db->start_cache();
        $this->db->select('p.chalan_no, p.purchase_date, s.supplier_name, p.grand_total_amount, p.payment_status');
        $this->db->from('product_purchase p');
        $this->db->join('supplier_information s', 's.supplier_id = p.supplier_id', 'left');
        $this->db->where('p.payment_status !=', 'paid');

        if (!empty($filters['from_date'])) {
            $this->db->where('p.purchase_date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $this->db->where('p.purchase_date <=', $filters['to_date']);
        }
        $this->db->stop_cache();

        $total = $this->db->count_all_results();
        $offset = ($page - 1) * $per_page;
        $rows = $this->db
            ->order_by('p.purchase_date', 'DESC')
            ->limit($per_page, $offset)
            ->get()
            ->result();
        $this->db->flush_cache();

        $rows = array_map(function ($row) {
            return [
                'reference' => $row->chalan_no,
                'supplier' => $row->supplier_name,
                'date' => format_date($row->purchase_date),
                'amount' => number_format($row->grand_total_amount, 2),
                'status' => ucfirst($row->payment_status)
            ];
        }, $rows);

        $this->db->select_sum('grand_total_amount', 'total_payable');
        $sum_row = $this->db->get('product_purchase')->row();
        $total_due = (float) ($sum_row->total_payable ?? 0);

        return [
            'columns' => [
                ['label' => 'Bill', 'key' => 'reference'],
                ['label' => 'Supplier', 'key' => 'supplier'],
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Payables', 'value' => 'AED ' . number_format($total_due, 2)],
                ['label' => 'Bills Pending', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_sales_book(array $filters, int $per_page, int $page): array
    {
        $result = $this->Invoice_model->get_paginated($per_page, $page, '', [
            'from_date' => $filters['from_date'] ?? '',
            'to_date' => $filters['to_date'] ?? ''
        ]);

        $rows = array_map(function ($invoice) {
            return [
                'date' => format_date($invoice->date),
                'reference' => $invoice->invoice,
                'customer' => $invoice->customer_name ?? $invoice->customer_id,
                'amount' => number_format($invoice->grand_total, 2),
                'status' => ucfirst($invoice->payment_status)
            ];
        }, $result->data);

        return [
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Invoice', 'key' => 'reference'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Invoices', 'value' => number_format($result->total)],
                ['label' => 'Total Sales', 'value' => 'AED ' . number_format(array_sum(array_column($rows, 'amount')), 2)]
            ],
            'pagination' => [
                'total' => $result->total,
                'per_page' => $result->per_page,
                'current_page' => $result->current_page,
                'total_pages' => $result->total_pages
            ]
        ];
    }

    private function dataset_purchase_book(array $filters, int $per_page, int $page): array
    {
        $result = $this->Purchase_model->get_paginated($per_page, $page, '', [
            'from_date' => $filters['from_date'] ?? '',
            'to_date' => $filters['to_date'] ?? ''
        ]);

        $rows = array_map(function ($purchase) {
            return [
                'date' => format_date($purchase->purchase_date),
                'reference' => $purchase->chalan_no,
                'supplier' => $purchase->supplier_name ?? $purchase->supplier_id,
                'amount' => number_format($purchase->grand_total_amount, 2),
                'status' => ucfirst($purchase->payment_status)
            ];
        }, $result->data);

        return [
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Bill', 'key' => 'reference'],
                ['label' => 'Supplier', 'key' => 'supplier'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Bills', 'value' => number_format($result->total)],
                ['label' => 'Total Purchases', 'value' => 'AED ' . number_format(array_sum(array_column($rows, 'amount')), 2)]
            ],
            'pagination' => [
                'total' => $result->total,
                'per_page' => $result->per_page,
                'current_page' => $result->current_page,
                'total_pages' => $result->total_pages
            ]
        ];
    }

    private function dataset_quotation_book(array $filters, int $per_page, int $page): array
    {
        $result = $this->Quotation_model->get_paginated($per_page, $page, '', [
            'from_date' => $filters['from_date'] ?? '',
            'to_date' => $filters['to_date'] ?? '',
            'status' => $filters['status'] ?? ''
        ]);

        $rows = array_map(function ($quotation) {
            return [
                'date' => format_date($quotation->quotation_date ?? $quotation->created_at ?? ''),
                'reference' => $quotation->quotation_number ?? $quotation->quotation_id,
                'customer' => $quotation->customer_name ?? $quotation->customer_id,
                'amount' => number_format($quotation->grand_total ?? $quotation->total_amount ?? 0, 2),
                'validity' => isset($quotation->valid_till) ? format_date($quotation->valid_till) : 'N/A'
            ];
        }, $result->data);

        $page_total = array_sum(array_map(function ($item) {
            return (float) ($item->grand_total ?? $item->total_amount ?? 0);
        }, $result->data));

        return [
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Quotation #', 'key' => 'reference'],
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Value', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Validity', 'key' => 'validity']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Quotations', 'value' => number_format($result->total)],
                ['label' => 'Page Value', 'value' => 'AED ' . number_format($page_total, 2)]
            ],
            'pagination' => [
                'total' => $result->total,
                'per_page' => $result->per_page,
                'current_page' => $result->current_page,
                'total_pages' => $result->total_pages
            ]
        ];
    }

    private function dataset_sales_summary(array $filters, int $per_page, int $page): array
    {
        $this->db->select('DATE(date) as sale_date, COUNT(*) as invoices, SUM(grand_total) as total_amount, SUM(paid_amount) as collected, SUM(due_amount) as outstanding', false);
        $this->db->from('invoice');
        $this->apply_date_filter('date', $filters);
        $this->db->group_by('sale_date');
        $this->db->order_by('sale_date', 'DESC');
        $data = $this->db->get()->result();

        $total = count($data);
        $offset = ($page - 1) * $per_page;
        $slice = array_slice($data, $offset, $per_page);

        $rows = array_map(function ($row) {
            return [
                'date' => format_date($row->sale_date),
                'invoices' => (int) $row->invoices,
                'amount' => number_format($row->total_amount, 2),
                'collected' => number_format($row->collected, 2),
                'outstanding' => number_format($row->outstanding, 2)
            ];
        }, $slice);

        $total_sales = array_sum(array_column($data, 'total_amount'));
        $total_outstanding = array_sum(array_column($data, 'outstanding'));

        return [
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Invoices', 'key' => 'invoices', 'align' => 'right'],
                ['label' => 'Sales', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Collected', 'key' => 'collected', 'align' => 'right'],
                ['label' => 'Outstanding', 'key' => 'outstanding', 'align' => 'right'],
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Sales', 'value' => 'AED ' . number_format($total_sales, 2)],
                ['label' => 'Outstanding', 'value' => 'AED ' . number_format($total_outstanding, 2)],
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_purchase_summary(array $filters, int $per_page, int $page): array
    {
        $this->db->select('DATE(purchase_date) as purchase_day, COUNT(*) as bills, SUM(grand_total_amount) as total_amount', false);
        $this->db->from('product_purchase');
        $this->apply_date_filter('purchase_date', $filters);
        $this->db->group_by('purchase_day');
        $this->db->order_by('purchase_day', 'DESC');
        $data = $this->db->get()->result();

        $total = count($data);
        $rows = array_slice($data, ($page - 1) * $per_page, $per_page);

        $rows = array_map(function ($row) {
            return [
                'date' => format_date($row->purchase_day),
                'bills' => (int) $row->bills,
                'amount' => number_format($row->total_amount, 2)
            ];
        }, $rows);

        $total_amount = array_sum(array_column($data, 'total_amount'));

        return [
            'columns' => [
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Bills', 'key' => 'bills', 'align' => 'right'],
                ['label' => 'Purchases', 'key' => 'amount', 'align' => 'right'],
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Purchases', 'value' => 'AED ' . number_format($total_amount, 2)],
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_premium_analysis(array $filters, int $per_page, int $page): array
    {
        $data = $this->Insurance_model->get_premium_collections($filters, $per_page, ($page - 1) * $per_page);

        $rows = array_map(function ($row) {
            return [
                'segment' => $row->reference_type ?? 'General',
                'policies' => $row->installment_no ?? 1,
                'written' => number_format($row->due_amount ?? 0, 2),
                'earned' => number_format(($row->status ?? '') === 'Collected' ? ($row->due_amount ?? 0) : 0, 2)
            ];
        }, $data);

        $written_total = array_sum(array_map(function ($row) {
            return (float) ($row->due_amount ?? 0);
        }, $data));

        $earned_total = array_sum(array_map(function ($row) {
            return ($row->status ?? '') === 'Collected' ? (float) ($row->due_amount ?? 0) : 0;
        }, $data));

        return [
            'columns' => [
                ['label' => 'Segment', 'key' => 'segment'],
                ['label' => 'Policies', 'key' => 'policies', 'align' => 'right'],
                ['label' => 'Written Premium', 'key' => 'written', 'align' => 'right'],
                ['label' => 'Earned Premium', 'key' => 'earned', 'align' => 'right'],
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Written', 'value' => 'AED ' . number_format($written_total, 2)],
                ['label' => 'Earned', 'value' => 'AED ' . number_format($earned_total, 2)],
            ],
            'pagination' => $this->pagination_meta(count($data), $per_page, $page)
        ];
    }

    private function dataset_loss_ratio(array $filters, int $per_page, int $page): array
    {
        $premium = $this->sum_insurance_table(Insurance_model::TABLE_PREMIUM_COLLECTIONS, 'due_amount', $filters, 'due_date');
        $claims = $this->sum_insurance_table(Insurance_model::TABLE_CLAIMS, 'reserve_amount', $filters, 'loss_date');
        $ratio = $premium > 0 ? ($claims / $premium) * 100 : 0;

        $rows = [[
            'segment' => 'All',
            'written' => 'AED ' . number_format($premium, 2),
            'claims' => 'AED ' . number_format($claims, 2),
            'ratio' => number_format($ratio, 2) . '%'
        ]];

        return [
            'columns' => [
                ['label' => 'Segment', 'key' => 'segment'],
                ['label' => 'Written Premium', 'key' => 'written', 'align' => 'right'],
                ['label' => 'Claims Paid', 'key' => 'claims', 'align' => 'right'],
                ['label' => 'Loss Ratio', 'key' => 'ratio', 'align' => 'right'],
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Loss Ratio', 'value' => number_format($ratio, 2) . '%']
            ],
            'pagination' => $this->pagination_meta(1, $per_page, 1)
        ];
    }

    private function dataset_customer_ageing(array $filters, int $per_page, int $page): array
    {
        $this->db->select('due_amount, DATEDIFF(CURDATE(), date) as age_days', false);
        $this->db->from('invoice');
        $this->db->where('due_amount >', 0);
        $this->apply_date_filter('date', $filters);
        $invoices = $this->db->get()->result();

        $buckets = [
            '0-30 Days' => ['min' => 0, 'max' => 30],
            '31-60 Days' => ['min' => 31, 'max' => 60],
            '61-90 Days' => ['min' => 61, 'max' => 90],
            '90+ Days' => ['min' => 91, 'max' => PHP_INT_MAX],
        ];

        $rows = [];
        $total_due = array_sum(array_column($invoices, 'due_amount'));

        foreach ($buckets as $label => $range) {
            $filtered = array_filter($invoices, function ($invoice) use ($range) {
                $age = (int) $invoice->age_days;
                return $age >= $range['min'] && $age <= $range['max'];
            });
            $amount = array_sum(array_map(function ($row) {
                return (float) $row->due_amount;
            }, $filtered));

            $rows[] = [
                'bucket' => $label,
                'invoices' => count($filtered),
                'amount' => number_format($amount, 2),
                'mix' => $total_due > 0 ? number_format(($amount / $total_due) * 100, 2) . '%' : '0%'
            ];
        }

        return [
            'columns' => [
                ['label' => 'Bucket', 'key' => 'bucket'],
                ['label' => 'Invoices', 'key' => 'invoices', 'align' => 'right'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Mix %', 'key' => 'mix', 'align' => 'right'],
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Outstanding', 'value' => 'AED ' . number_format($total_due, 2)]
            ],
            'pagination' => null
        ];
    }

    private function dataset_outstanding_report(array $filters, int $per_page, int $page): array
    {
        $this->db->select('c.customer_name, MIN(i.date) as oldest_invoice, SUM(i.due_amount) as outstanding');
        $this->db->from('invoice i');
        $this->db->join('customer_information c', 'c.customer_id = i.customer_id', 'left');
        $this->db->where('i.due_amount >', 0);
        $this->apply_date_filter('i.date', $filters);
        $this->db->group_by('i.customer_id');
        $this->db->order_by('oldest_invoice', 'ASC');
        $records = $this->db->get()->result();

        $total = count($records);
        $rows = array_slice($records, ($page - 1) * $per_page, $per_page);

        $rows = array_map(function ($row) {
            $oldest_days = $row->oldest_invoice ? (int) ((time() - strtotime($row->oldest_invoice)) / 86400) : 0;
            return [
                'customer' => $row->customer_name ?? 'Unknown',
                'reference' => format_date($row->oldest_invoice ?? date('Y-m-d')),
                'days' => $oldest_days,
                'amount' => number_format($row->outstanding, 2),
                'owner' => 'AR Team'
            ];
        }, $rows);

        $total_outstanding = array_sum(array_column($records, 'outstanding'));

        return [
            'columns' => [
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Oldest Invoice', 'key' => 'reference'],
                ['label' => 'Days', 'key' => 'days', 'align' => 'right'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Owner', 'key' => 'owner'],
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Outstanding', 'value' => 'AED ' . number_format($total_outstanding, 2)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_policy_register(array $filters, int $per_page, int $page): array
    {
        $data = $this->Insurance_model->get_policies($filters, $per_page, ($page - 1) * $per_page);
        $total = $this->Insurance_model->count_where(Insurance_model::TABLE_POLICIES);

        $rows = array_map(function ($policy) {
            return [
                'policy' => $policy->policy_number,
                'customer' => $policy->customer_id,
                'effective' => format_date($policy->effective_date),
                'expiry' => format_date($policy->expiry_date),
                'premium' => number_format($policy->premium_amount, 2)
            ];
        }, $data);

        return [
            'columns' => [
                ['label' => 'Policy No', 'key' => 'policy'],
                ['label' => 'Customer ID', 'key' => 'customer'],
                ['label' => 'Effective', 'key' => 'effective'],
                ['label' => 'Expiry', 'key' => 'expiry'],
                ['label' => 'Premium', 'key' => 'premium', 'align' => 'right']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Policies', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_claims_register(array $filters, int $per_page, int $page): array
    {
        $data = $this->Insurance_model->get_claims($filters, $per_page, ($page - 1) * $per_page);
        $total = $this->Insurance_model->count_where(Insurance_model::TABLE_CLAIMS);

        $rows = array_map(function ($claim) {
            return [
                'claim' => $claim->claim_number,
                'policy' => $claim->policy_number,
                'type' => $claim->loss_type,
                'reserve' => number_format($claim->reserve_amount, 2),
                'status' => ucfirst($claim->status)
            ];
        }, $data);

        return [
            'columns' => [
                ['label' => 'Claim No', 'key' => 'claim'],
                ['label' => 'Policy', 'key' => 'policy'],
                ['label' => 'Type', 'key' => 'type'],
                ['label' => 'Reserve', 'key' => 'reserve', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Claims', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_commission_report(array $filters, int $per_page, int $page): array
    {
        $data = $this->Insurance_model->get_commissions($filters, $per_page, ($page - 1) * $per_page);
        $total = $this->Insurance_model->count_where(Insurance_model::TABLE_COMMISSIONS);

        $rows = array_map(function ($commission) {
            return [
                'partner' => $commission->partner_name ?? $commission->partner_type,
                'policy' => $commission->policy_number,
                'rate' => number_format($commission->commission_pct, 2) . '%',
                'amount' => number_format($commission->commission_amount, 2),
                'status' => ucfirst($commission->approval_status)
            ];
        }, $data);

        return [
            'columns' => [
                ['label' => 'Partner', 'key' => 'partner'],
                ['label' => 'Policy', 'key' => 'policy'],
                ['label' => 'Rate', 'key' => 'rate', 'align' => 'right'],
                ['label' => 'Amount', 'key' => 'amount', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Total Commissions', 'value' => 'AED ' . number_format(array_sum(array_map(function ($row) { return $row->commission_amount; }, $data)), 2)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_renewal_tracker(array $filters, int $per_page, int $page): array
    {
        $data = $this->Insurance_model->get_renewals($filters, $per_page, ($page - 1) * $per_page);
        $total = $this->Insurance_model->count_where(Insurance_model::TABLE_RENEWALS);

        $rows = array_map(function ($renewal) {
            return [
                'policy' => $renewal->policy_number,
                'expiry' => format_date($renewal->current_expiry),
                'owner' => $renewal->assigned_to,
                'status' => $renewal->status ?? 'Planned',
                'premium' => number_format($renewal->proposed_premium, 2)
            ];
        }, $data);

        return [
            'columns' => [
                ['label' => 'Policy', 'key' => 'policy'],
                ['label' => 'Expiry', 'key' => 'expiry'],
                ['label' => 'Owner', 'key' => 'owner'],
                ['label' => 'Status', 'key' => 'status'],
                ['label' => 'Premium', 'key' => 'premium', 'align' => 'right']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Tracked Renewals', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_customer_list(array $filters, int $per_page, int $page): array
    {
        $this->db->start_cache();
        $this->db->from('customer_information');
        if (!empty($filters['search'])) {
            $this->db->like('customer_name', $filters['search']);
        }
        $this->db->stop_cache();

        $total = $this->db->count_all_results();
        $rows = $this->db->order_by('customer_name', 'ASC')->limit($per_page, ($page - 1) * $per_page)->get()->result();
        $this->db->flush_cache();

        $rows = array_map(function ($customer) {
            return [
                'customer' => $customer->customer_name,
                'category' => $customer->customer_type ?? 'General',
                'contact' => $customer->email ?? $customer->customer_mobile ?? '',
                'outstanding' => number_format($customer->outstanding ?? 0, 2)
            ];
        }, $rows);

        return [
            'columns' => [
                ['label' => 'Customer', 'key' => 'customer'],
                ['label' => 'Category', 'key' => 'category'],
                ['label' => 'Primary Contact', 'key' => 'contact'],
                ['label' => 'Outstanding', 'key' => 'outstanding', 'align' => 'right']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Customers', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_attendance_report(array $filters, int $per_page, int $page): array
    {
        $data = $this->Hr_model->get_attendance_report($filters);
        $total = count($data);
        $rows = array_slice($data, ($page - 1) * $per_page, $per_page);

        $rows = array_map(function ($row) {
            return [
                'employee' => $row->full_name ?? $row->employee_id,
                'date' => format_date($row->attendance_date),
                'check_in' => $row->check_in,
                'check_out' => $row->check_out,
                'location' => $row->work_location
            ];
        }, $rows);

        return [
            'columns' => [
                ['label' => 'Employee', 'key' => 'employee'],
                ['label' => 'Date', 'key' => 'date'],
                ['label' => 'Check In', 'key' => 'check_in'],
                ['label' => 'Check Out', 'key' => 'check_out'],
                ['label' => 'Location', 'key' => 'location']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Records', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_leave_report(array $filters, int $per_page, int $page): array
    {
        $data = $this->Hr_model->get_leave_report($filters);
        $total = count($data);
        $rows = array_slice($data, ($page - 1) * $per_page, $per_page);

        $rows = array_map(function ($row) {
            return [
                'employee' => $row->full_name ?? $row->employee_id,
                'leave_type' => $row->leave_type,
                'days' => $row->total_days,
                'status' => $row->status,
                'approver' => $row->approver
            ];
        }, $rows);

        return [
            'columns' => [
                ['label' => 'Employee', 'key' => 'employee'],
                ['label' => 'Leave Type', 'key' => 'leave_type'],
                ['label' => 'Days', 'key' => 'days', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status'],
                ['label' => 'Approver', 'key' => 'approver']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Requests', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_payroll_report(array $filters, int $per_page, int $page): array
    {
        $data = $this->Hr_model->get_payroll_report();
        $total = count($data);
        $rows = array_slice($data, ($page - 1) * $per_page, $per_page);

        $rows = array_map(function ($row) {
            return [
                'month' => $row->payroll_month,
                'group' => $row->pay_group,
                'basic' => number_format($row->basic_salary, 2),
                'allowances' => number_format($row->allowances, 2),
                'net' => number_format($row->net_pay, 2)
            ];
        }, $rows);

        return [
            'columns' => [
                ['label' => 'Month', 'key' => 'month'],
                ['label' => 'Pay Group', 'key' => 'group'],
                ['label' => 'Basic', 'key' => 'basic', 'align' => 'right'],
                ['label' => 'Allowances', 'key' => 'allowances', 'align' => 'right'],
                ['label' => 'Net Pay', 'key' => 'net', 'align' => 'right']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Records', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function dataset_salary_register(array $filters, int $per_page, int $page): array
    {
        $data = $this->Hr_model->get_salary_register();
        $total = count($data);
        $rows = array_slice($data, ($page - 1) * $per_page, $per_page);

        $rows = array_map(function ($row) {
            return [
                'employee' => $row->pay_group ?? 'General',
                'iban' => $row->iban ?? 'N/A',
                'net' => number_format($row->net_pay, 2),
                'status' => $row->status ?? 'Draft'
            ];
        }, $rows);

        return [
            'columns' => [
                ['label' => 'Group', 'key' => 'employee'],
                ['label' => 'IBAN', 'key' => 'iban'],
                ['label' => 'Net Pay', 'key' => 'net', 'align' => 'right'],
                ['label' => 'Status', 'key' => 'status']
            ],
            'rows' => $rows,
            'summary_cards' => [
                ['label' => 'Entries', 'value' => number_format($total)]
            ],
            'pagination' => $this->pagination_meta($total, $per_page, $page)
        ];
    }

    private function apply_date_filter(string $column, array $filters): void
    {
        if (!empty($filters['from_date'])) {
            $this->db->where($column . ' >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $this->db->where($column . ' <=', $filters['to_date']);
        }
    }

    private function sum_insurance_table(string $table, string $column, array $filters, string $date_column): float
    {
        $this->db->select_sum($column, 'agg_total');
        $this->db->from($table);
        $this->apply_date_filter($date_column, $filters);
        $row = $this->db->get()->row();
        return (float) ($row->agg_total ?? 0);
    }

    private function export_csv(string $slug, array $columns, array $rows): void
    {
        $filename = $slug . '_' . date('Ymd_His') . '.csv';
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename="' . $filename . '"');

        $output = fopen('php://output', 'w');
        fputcsv($output, array_map(function ($column) {
            return $column['label'] ?? $column['key'];
        }, $columns));

        foreach ($rows as $row) {
            $line = [];
            foreach ($columns as $column) {
                $key = $column['key'] ?? '';
                $line[] = isset($row[$key]) ? strip_tags((string) $row[$key]) : '';
            }
            fputcsv($output, $line);
        }
        fclose($output);
        exit;
    }
}
