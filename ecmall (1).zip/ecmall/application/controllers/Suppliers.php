<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Suppliers extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Supplier_model');

        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }
    }

    public function index() {
        redirect('clients?type=supplier');
        return;
    }

    public function add() {
        redirect('clients/form/supplier');
        return;
    }

    public function edit($supplier_id) {
        $supplier = $this->Supplier_model->get_by_id($supplier_id);
        if ($supplier && !empty($supplier->supplier_code)) {
            redirect('clients/form/supplier/' . rawurlencode($supplier->supplier_code));
        } else {
            redirect('clients?type=supplier');
        }
        return;
    }

    public function view($supplier_id) {
        $supplier = $this->Supplier_model->get_by_id($supplier_id);
        if ($supplier && !empty($supplier->supplier_code)) {
            redirect('clients/form/supplier/' . rawurlencode($supplier->supplier_code));
        } else {
            redirect('clients?type=supplier');
        }
        return;
    }

    public function delete($supplier_id) {
        redirect('clients?type=supplier');
        return;
    }

    public function export() {
        redirect('clients?type=supplier');
        return;
    }

    public function search() {
        $term = $this->input->get('term');

        $this->db->select('supplier_id, supplier_name, supplier_mobile, emailnumber');
        $this->db->like('supplier_name', $term);
        $this->db->or_like('supplier_mobile', $term);
        $this->db->limit(10);
        $suppliers = $this->db->get('supplier_information')->result();

        $results = [];
        foreach ($suppliers as $supplier) {
            $results[] = [
                'id' => $supplier->supplier_id,
                'label' => $supplier->supplier_name . ' (' . $supplier->supplier_mobile . ')',
                'value' => $supplier->supplier_name,
                'mobile' => $supplier->supplier_mobile,
                'email' => $supplier->emailnumber
            ];
        }

        echo json_encode($results);
    }
}
