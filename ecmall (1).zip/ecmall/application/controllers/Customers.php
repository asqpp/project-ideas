<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Customers extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Customer_model');

        // Check if user is logged in
        if (!$this->session->userdata('user_id')) {
            redirect('login');
        }
    }

    /**
     * List all customers
     */
    public function index() {
        redirect('clients?type=customer');
        return;
    }

    /**
     * Add new customer
     */
    public function add() {
        redirect('clients/form/customer');
        return;
    }

    /**
     * Edit customer
     */
    public function edit($customer_id) {
        $customer = $this->Customer_model->get_by_id($customer_id);
        if ($customer && !empty($customer->customer_code)) {
            redirect('clients/form/customer/' . rawurlencode($customer->customer_code));
        } else {
            redirect('clients?type=customer');
        }
        return;
    }

    /**
     * View customer details
     */
    public function view($customer_id) {
        $customer = $this->Customer_model->get_by_id($customer_id);
        if ($customer && !empty($customer->customer_code)) {
            redirect('clients/form/customer/' . rawurlencode($customer->customer_code));
        } else {
            redirect('clients?type=customer');
        }
        return;
    }

    /**
     * Delete customer
     */
    public function delete($customer_id) {
        redirect('clients?type=customer');
        return;
    }

    /**
     * Export customers to CSV
     */
    public function export() {
        redirect('clients?type=customer');
        return;
    }

    /**
     * AJAX: Get customer by ID for autocomplete
     */
    public function get_customer($customer_id) {
        $customer = $this->Customer_model->get_with_outstanding($customer_id);

        if ($customer) {
            echo json_encode(['success' => true, 'customer' => $customer]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Customer not found']);
        }
    }

    /**
     * AJAX: Search customers for autocomplete
     */
    public function search() {
        $term = $this->input->get('term');
        $customers = $this->Customer_model->search_for_autocomplete($term);

        $results = [];
        foreach ($customers as $customer) {
            $results[] = [
                'id' => $customer->customer_id,
                'label' => $customer->customer_name . ' (' . $customer->customer_mobile . ')',
                'value' => $customer->customer_name,
                'mobile' => $customer->customer_mobile,
                'email' => $customer->customer_email
            ];
        }

        echo json_encode($results);
    }
}
