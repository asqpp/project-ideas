<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchases extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Purchase_model');
        $this->load->model('Supplier_model');
        $this->load->model('Product_model');
    }

    /**
     * List all purchases
     */
    public function index() {
        $page = $this->input->get('page') ?? 1;
        $search = $this->input->get('search') ?? '';

        $filters = [
            'from_date' => $this->input->get('from_date'),
            'to_date' => $this->input->get('to_date')
        ];

        $result = $this->Purchase_model->get_paginated(25, $page, $search, $filters);

        $data = [
            'page_title' => 'Purchases',
            'purchases' => $result->data,
            'pagination' => $result,
            'search' => $search,
            'filters' => $filters,
            'main_content' => 'purchases/index'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Add new purchase
     */
    public function add() {
        if ($this->input->post()) {
            $this->load->library('form_validation');

            $this->form_validation->set_rules('supplier_id', 'Supplier', 'required');
            $this->form_validation->set_rules('purchase_date', 'Purchase Date', 'required');
            $this->form_validation->set_rules('items', 'Items', 'required');
            $this->form_validation->set_rules('purchase_discount', 'Purchase Discount', 'numeric');

            if ($this->form_validation->run() === TRUE) {
                // Parse items JSON
                $items_json = $this->input->post('items');
                $items = json_decode($items_json, true);

                if (empty($items)) {
                    $this->session->set_flashdata('error', 'Please add at least one item to the purchase.');
                } else {
                    $purchase_discount = (float) ($this->input->post('purchase_discount') ?? 0);
                    $totals = $this->calculate_purchase_totals($items, $purchase_discount);

                    $payments_json = $this->input->post('payments') ?? '[]';
                    $payments = $this->parse_payments_from_json($payments_json);
                    $paid_amount = 0;
                    foreach ($payments as $payment) {
                        $paid_amount += $payment['amount'];
                    }

                    if ($paid_amount > round($totals['grand_total'] + 0.01, 2)) {
                        $this->session->set_flashdata('error', 'Paid amount cannot exceed the grand total.');
                        redirect(current_url());
                        return;
                    }

                    $due_amount = max($totals['grand_total'] - $paid_amount, 0);
                    if ($due_amount && $due_amount < 0.01) {
                        $due_amount = 0;
                    }

                    $payment_status = 'unpaid';
                    if ($paid_amount >= $totals['grand_total']) {
                        $payment_status = 'paid';
                    } elseif ($paid_amount > 0) {
                        $payment_status = 'partial';
                    }

                    $payment_type = null;
                    if (!empty($payments)) {
                        $payment_type = count($payments) > 1 ? 'split' : ($payments[0]['method'] ?? null);
                    }

                    // Prepare purchase data
                    $purchase_data = [
                        'supplier_id' => $this->input->post('supplier_id'),
                        'purchase_date' => $this->input->post('purchase_date'),
                        'total_amount' => $totals['subtotal'],
                        'line_discount_total' => $totals['line_discount_total'],
                        'purchase_discount' => $totals['purchase_discount'],
                        'total_discount' => $totals['total_discount'],
                        'vat' => $totals['total_vat'],
                        'grand_total_amount' => $totals['grand_total'],
                        'paid_amount' => $paid_amount,
                        'due_amount' => $due_amount,
                        'payment_type' => $payment_type,
                        'payment_summary' => !empty($payments) ? json_encode($payments) : null,
                        'details' => $this->input->post('notes'),
                        'payment_status' => $payment_status,
                        'created_at' => date('Y-m-d H:i:s')
                    ];

                    $purchase_id = $this->Purchase_model->create_purchase($purchase_data, $items);

                    if ($purchase_id) {
                        $this->session->set_flashdata('success', 'Purchase recorded successfully! Stock has been updated.');
                        redirect('purchases/view/' . $purchase_id);
                    } else {
                        $this->session->set_flashdata('error', 'Failed to record purchase. Please try again.');
                    }
                }
            }
        }

        // Get suppliers and products for dropdowns
        $data = [
            'page_title' => 'Add Purchase',
            'suppliers' => $this->Supplier_model->get_all(),
            'products' => $this->Product_model->get_all(),
            'generated_chalan' => $this->Purchase_model->generate_chalan_number(),
            'main_content' => 'purchases/form'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * View purchase details
     */
    public function view($purchase_id) {
        $purchase = $this->Purchase_model->get_purchase_details($purchase_id);

        if (!$purchase) {
            show_404();
        }

        $data = [
            'page_title' => 'Purchase Details',
            'purchase' => $purchase,
            'main_content' => 'purchases/view'
        ];

        $this->load->view('templates/modern_layout', $data);
    }

    /**
     * Delete purchase
     */
    public function delete($purchase_id) {
        $purchase = $this->Purchase_model->get_by_id($purchase_id);

        if (!$purchase) {
            show_404();
        }

        // Check if there are payments
        $this->db->where('purchase_id', $purchase_id);
        $payments_count = $this->db->count_all_results('payment');

        if ($payments_count > 0) {
            $this->session->set_flashdata('error', 'Cannot delete purchase. It has associated payments.');
            redirect('purchases');
        }

        // Delete purchase (should also reverse accounting entries and stock)
        $this->load->model('Daybook_model');
        $this->Daybook_model->reverse_entries('purchase', $purchase_id);

        // TODO: Reverse stock changes

        $deleted = $this->Purchase_model->delete($purchase_id);

        if ($deleted) {
            $this->session->set_flashdata('success', 'Purchase deleted successfully!');
        } else {
            $this->session->set_flashdata('error', 'Failed to delete purchase. Please try again.');
        }

        redirect('purchases');
    }

    /**
     * Export purchases to CSV
     */
    public function export() {
        $purchases = $this->Purchase_model->get_all();

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="purchases_' . date('Y-m-d') . '.csv"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Chalan No', 'Supplier', 'Date', 'Total', 'VAT', 'Grand Total', 'Payment Status']);

        foreach ($purchases as $purchase) {
            fputcsv($output, [
                $purchase->purchase_id,
                $purchase->chalan_no,
                $purchase->supplier_name ?? 'N/A',
                $purchase->purchase_date,
                $purchase->total_amount,
                $purchase->vat,
                $purchase->grand_total_amount,
                ucfirst($purchase->payment_status ?? 'unpaid')
            ]);
        }

        fclose($output);
    }

    /**
     * Get product details (AJAX)
     */
    public function get_product($product_id) {
        $product = $this->Product_model->get_by_id($product_id);

        if ($product) {
            echo json_encode([
                'success' => true,
                'product' => $product
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Product not found'
            ]);
        }
    }
    /**
     * Calculate purchase totals from item payload.
     */
    private function calculate_purchase_totals(array &$items, float $purchase_discount = 0): array
    {
        $subtotal = 0;
        $lineDiscountTotal = 0;
        $totalVat = 0;

        foreach ($items as &$item) {
            $quantity = (float) ($item['quantity'] ?? 0);
            $rate = (float) ($item['rate'] ?? 0);
            $discountPct = (float) ($item['discount_pct'] ?? 0);
            $vatPct = (float) ($item['vat_pct'] ?? 0);

            $lineSubtotal = $quantity * $rate;
            $discountValue = round($lineSubtotal * ($discountPct / 100), 2);
            $taxable = $lineSubtotal - $discountValue;
            $vatValue = round($taxable * ($vatPct / 100), 2);
            $lineTotal = $taxable + $vatValue;

            $item['discount_pct'] = $discountPct;
            $item['discount_value'] = $discountValue;
            $item['vat_pct'] = $vatPct;
            $item['vat_value'] = $vatValue;
            $item['total_amount'] = $lineSubtotal;
            $item['line_total'] = $lineTotal;

            $subtotal += $lineSubtotal;
            $lineDiscountTotal += $discountValue;
            $totalVat += $vatValue;
        }

        $purchase_discount = max(0, round($purchase_discount, 2));
        $totalDiscount = $lineDiscountTotal + $purchase_discount;
        $grandTotal = max($subtotal - $totalDiscount + $totalVat, 0);

        return [
            'subtotal' => round($subtotal, 2),
            'line_discount_total' => round($lineDiscountTotal, 2),
            'purchase_discount' => $purchase_discount,
            'total_discount' => round($totalDiscount, 2),
            'total_vat' => round($totalVat, 2),
            'grand_total' => round($grandTotal, 2)
        ];
    }

    /**
     * Decode payment breakdown rows from JSON payload.
     */
    private function parse_payments_from_json(?string $jsonPayload): array
    {
        if (!$jsonPayload) {
            return [];
        }

        $rows = json_decode($jsonPayload, true);
        if (!is_array($rows)) {
            return [];
        }

        $payments = [];
        foreach ($rows as $row) {
            $amount = isset($row['amount']) ? (float) $row['amount'] : 0;
            $method = isset($row['method']) ? strtolower(trim($row['method'])) : '';
            if ($amount <= 0) {
                continue;
            }
            $payments[] = [
                'method' => $method ?: 'cash',
                'amount' => round($amount, 2)
            ];
        }

        return $payments;
    }
}
