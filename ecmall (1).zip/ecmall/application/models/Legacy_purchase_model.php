<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Legacy_purchase_model extends CI_Model
{
    const TABLE_MASTER = 'purchasem';
    const TABLE_DETAIL = 'purchased';
    const COUNTER_CODE = 'PURCHASEB';

    public function get_paginated($perPage = 25, $page = 1, $search = '')
    {
        $offset = ($page - 1) * $perPage;

        $this->db->from(self::TABLE_MASTER);
        if ($search !== '') {
            $this->db->group_start()
                ->like('docno', $search)
                ->or_like('billno', $search)
                ->or_like('suppcode', $search)
                ->or_like('name', $search)
                ->group_end();
        }

        $total = $this->db->count_all_results('', false);

        $this->db->order_by('tdate', 'DESC');
        $this->db->limit($perPage, $offset);
        $records = $this->db->get()->result();

        return (object) [
            'data' => $records,
            'total' => $total,
            'per_page' => $perPage,
            'current_page' => $page,
            'total_pages' => max(1, ceil($total / $perPage))
        ];
    }

    public function get_purchase($slno)
    {
        $purchase = $this->db
            ->where('slno', $slno)
            ->get(self::TABLE_MASTER)
            ->row_array();

        if (!$purchase) {
            return null;
        }

        $purchase['items'] = $this->db
            ->where('slno', $slno)
            ->order_by('sno', 'ASC')
            ->get(self::TABLE_DETAIL)
            ->result_array();

        return $purchase;
    }

    public function preview_next_docno(): string
    {
        $next = $this->get_next_counter_value();
        return $this->format_docno($next + 1);
    }

    public function save(array $payload, array $items, ?int $slno = null)
    {
        $this->db->trans_start();

        if ($slno) {
            $payload['slno'] = $slno;
            $this->db->where('slno', $slno)->update(self::TABLE_MASTER, $payload);
            $this->db->where('slno', $slno)->delete(self::TABLE_DETAIL);
            $this->cleanup_daybook_entries($slno);
        } else {
            $nextCounter = $this->increment_counter();
            $payload['slno'] = $nextCounter;
            if (empty($payload['docno'])) {
                $payload['docno'] = $this->format_docno($nextCounter);
            }
            $this->db->insert(self::TABLE_MASTER, $payload);
            $slno = $payload['slno'];
        }

        $sno = 1;
        foreach ($items as $item) {
            $this->db->insert(self::TABLE_DETAIL, [
                'slno' => $slno,
                'code' => $item['code'],
                'qty' => $item['qty'],
                'rate' => $item['rate'],
                'amount' => $item['amount'],
                'sno' => $sno++
            ]);
        }

        $this->post_daybook_entries($slno, $payload);

        $this->db->trans_complete();

        return $this->db->trans_status() ? $slno : false;
    }

    private function get_next_counter_value(): int
    {
        $row = $this->db->where('code', self::COUNTER_CODE)->get('generali')->row();
        return $row ? (int) $row->cvalue : 0;
    }

    private function increment_counter(): int
    {
        $this->db->query("
            INSERT INTO generali (code, cvalue, description)
            VALUES (?, 1, 'Legacy purchase counter')
            ON DUPLICATE KEY UPDATE cvalue = cvalue + 1
        ", [self::COUNTER_CODE]);

        return $this->get_next_counter_value();
    }

    private function format_docno(int $counter): string
    {
        $config = $this->get_doc_config();
        $length = max(1, (int) ($config['length'] ?? 5));
        $prefix = $config['prefix'] ?? 'PB';
        return $prefix . str_pad((string) $counter, $length, '0', STR_PAD_LEFT);
    }

    private function get_doc_config(): array
    {
        static $config = null;
        if ($config !== null) {
            return $config;
        }

        $prefixRow = $this->db->select('cvalue')
            ->where('code', 'PBPREF')
            ->get('generals')
            ->row();

        $lengthRow = $this->db->select('cvalue')
            ->where('code', 'PBLEN')
            ->get('generals')
            ->row();

        $config = [
            'prefix' => $prefixRow->cvalue ?? 'PB',
            'length' => is_numeric($lengthRow->cvalue ?? null) ? (int) $lengthRow->cvalue : 5
        ];

        return $config;
    }

    private function post_daybook_entries(int $slno, array $purchase): void
    {
        $this->load->model('Daybook_model');

        $goods = max(($purchase['billamt'] ?? 0) - ($purchase['discount'] ?? 0), 0);
        $vat = (float) ($purchase['taxamt'] ?? 0);
        $total = (float) ($purchase['netamt'] ?? 0);
        $date = $purchase['tdate'] ?? date('Y-m-d');
        $supplierAccount = 'SUPP_' . ($purchase['suppcode'] ?: $slno);
        $desc = 'Legacy Purchase #' . ($purchase['docno'] ?? $slno);

        $entries = [];
        if ($goods > 0) {
            $entries[] = [
                'date' => $date,
                'account_code' => 'PURCHASE',
                'description' => $desc,
                'debit' => $goods,
                'credit' => 0,
                'reference_type' => 'legacy_purchase',
                'reference_id' => $slno
            ];
        }

        if ($vat > 0) {
            $entries[] = [
                'date' => $date,
                'account_code' => 'VAT-IN',
                'description' => 'VAT ' . $desc,
                'debit' => $vat,
                'credit' => 0,
                'reference_type' => 'legacy_purchase',
                'reference_id' => $slno
            ];
        }

        $entries[] = [
            'date' => $date,
            'account_code' => $supplierAccount,
            'description' => $desc,
            'debit' => 0,
            'credit' => $total,
            'reference_type' => 'legacy_purchase',
            'reference_id' => $slno
        ];

        $this->Daybook_model->post_entries($entries);
    }

    private function cleanup_daybook_entries(int $slno): void
    {
        $this->db->where('reference_type', 'legacy_purchase')
            ->where('reference_id', $slno)
            ->delete('daybook');
    }
}
