<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Purchase_model extends MY_Model {

    protected $table = 'product_purchase';
    protected $primary_key = 'purchase_id';
    protected $timestamps = false;
    private $docConfig = null;

    /**
     * Get purchases with pagination and search
     */
    public function get_paginated($per_page = 25, $page = 1, $search = '', $filters = []) {
        $offset = ($page - 1) * $per_page;

        $this->db->select('p.*, s.supplier_name, s.supplier_mobile');
        $this->db->from($this->table . ' p');
        $this->db->join('supplier_information s', 'p.supplier_id = s.supplier_id', 'left');

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('p.chalan_no', $search);
            $this->db->or_like('s.supplier_name', $search);
            $this->db->or_like('s.supplier_mobile', $search);
            $this->db->group_end();
        }

        // Apply filters
        if (!empty($filters['from_date'])) {
            $this->db->where('p.purchase_date >=', $filters['from_date']);
        }

        if (!empty($filters['to_date'])) {
            $this->db->where('p.purchase_date <=', $filters['to_date']);
        }

        // Get total count
        $total = $this->db->count_all_results('', false);

        // Get paginated results
        $this->db->limit($per_page, $offset);
        $this->db->order_by('p.purchase_date', 'DESC');
        $data = $this->db->get()->result();

        return (object) [
            'data' => $data,
            'total' => $total,
            'per_page' => $per_page,
            'current_page' => $page,
            'total_pages' => ceil($total / $per_page)
        ];
    }

    /**
     * Get purchase with full details
     */
    public function get_purchase_details($purchase_id) {
        // Get purchase header
        $this->db->select('p.*, s.*, p.details as purchase_details');
        $this->db->from($this->table . ' p');
        $this->db->join('supplier_information s', 'p.supplier_id = s.supplier_id', 'left');
        $this->db->where('p.purchase_id', $purchase_id);
        $purchase = $this->db->get()->row();

        if (!$purchase) {
            return null;
        }

        // Get purchase items
        $this->db->select('pi.*, pi.total_amount as total_price, prod.product_name, prod.product_model');
        $this->db->from('product_purchase_details pi');
        $this->db->join('product_information prod', 'pi.product_id = prod.product_id', 'left');
        $this->db->where('pi.purchase_id', $purchase_id);
        $purchase->items = $this->db->get()->result();

        // Get payments
        $this->db->select('*');
        $this->db->from('payment');
        $this->db->where('purchase_id', $purchase_id);
        $purchase->payments = $this->db->get()->result();

        return $purchase;
    }

    /**
     * Create purchase with items and accounting entries
     * Enhanced with stock tracking
     */
    public function create_purchase($purchase_data, $items) {
        $this->db->trans_start();

        $allocation = $this->allocate_chalan_sequence();
        $purchase_data['chalan_no'] = $allocation['formatted'];

        $this->db->insert($this->table, $purchase_data);
        $purchase_id = $this->db->insert_id();

        // Insert items and update stock
        foreach ($items as $item) {
            $purchaseItem = [
                'purchase_id' => $purchase_id,
                'product_id' => $item['product_id'],
                'quantity' => $item['quantity'],
                'rate' => $item['rate'],
                'discount_pct' => $item['discount_pct'] ?? 0,
                'discount_value' => $item['discount_value'] ?? 0,
                'vat_pct' => $item['vat_pct'] ?? 0,
                'vat_value' => $item['vat_value'] ?? 0,
                'batch_no' => $item['batch_no'] ?? ($item['batch'] ?? null),
                'expiry_date' => !empty($item['expiry_date']) ? $item['expiry_date'] : null,
                'total_amount' => $item['total_amount'] ?? ($item['quantity'] * $item['rate']),
                'line_total' => $item['line_total'] ?? ($item['total_amount'] ?? ($item['quantity'] * $item['rate']))
            ];
            $this->db->insert('product_purchase_details', $purchaseItem);
            $item_id = $this->db->insert_id();

            // Update product stock (increase inventory)
            $this->update_product_stock(
                $item['product_id'],
                $item['quantity'],
                'add',
                $purchase_data['purchase_date'],
                $purchase_id
            );

            // Create batch tracking if batch info provided
            $batchCode = $purchaseItem['batch_no'] ?? null;
            if (!empty($batchCode)) {
                $this->create_batch_entry([
                    'product_id' => $item['product_id'],
                    'batch' => $batchCode,
                    'weight' => $item['weight'] ?? 0,
                    'touch' => $item['touch'] ?? 0,
                    'less_weight' => $item['less_weight'] ?? 0,
                    'amount' => $purchaseItem['line_total'],
                    'issued_weight' => 0,
                    'pending' => 1,
                    'transaction_date' => $purchase_data['purchase_date'],
                    'document_no' => $purchase_data['chalan_no'],
                    'purchase_item_id' => $item_id
                ]);
            }

            // Update stock ledger (itemsstk table)
            $this->update_stock_ledger([
                'product_id' => $item['product_id'],
                'transaction_date' => $purchase_data['purchase_date'],
                'document_no' => $purchase_data['chalan_no'],
                'transaction_type' => 'purchase',
                'quantity_in' => $item['quantity'],
                'quantity_out' => 0,
                'rate' => $item['rate'],
                'reference_id' => $purchase_id
            ]);
        }

        // Post to daybook (double-entry once purchase is saved)
        $this->load->model('Daybook_model');

        $supplier = $this->db
            ->select('supplier_name')
            ->where('supplier_id', $purchase_data['supplier_id'])
            ->get('supplier_information')
            ->row();

        $supplierName = $supplier->supplier_name ?? 'Supplier';
        $referenceDescription = 'Purchase #' . $purchase_data['chalan_no'] . ' - ' . $supplierName;
        $date = $purchase_data['purchase_date'];

        $subtotal = (float) ($purchase_data['total_amount'] ?? 0);
        $totalDiscount = (float) ($purchase_data['total_discount'] ?? 0);
        $goodsDebit = max($subtotal - $totalDiscount, 0);
        $vatAmount = (float) ($purchase_data['vat'] ?? 0);
        $grandTotal = (float) ($purchase_data['grand_total_amount'] ?? 0);

        if ($goodsDebit > 0) {
            $this->Daybook_model->post_entry([
                'date' => $date,
                'account_code' => 'PURCHASE',
                'description' => $referenceDescription,
                'debit' => $goodsDebit,
                'credit' => 0,
                'reference_type' => 'purchase',
                'reference_id' => $purchase_id
            ]);
        }

        if ($vatAmount > 0) {
            $this->Daybook_model->post_entry([
                'date' => $date,
                'account_code' => 'VAT-IN',
                'description' => 'VAT on ' . $referenceDescription,
                'debit' => $vatAmount,
                'credit' => 0,
                'reference_type' => 'purchase',
                'reference_id' => $purchase_id
            ]);
        }

        $this->Daybook_model->post_entry([
            'date' => $date,
            'account_code' => 'SUPP_' . $purchase_data['supplier_id'],
            'description' => $referenceDescription,
            'debit' => 0,
            'credit' => $grandTotal,
            'reference_type' => 'purchase',
            'reference_id' => $purchase_id
        ]);

        $this->db->trans_complete();

        return $this->db->trans_status() ? $purchase_id : false;
    }

    public function generate_chalan_number(): string
    {
        $next = $this->get_purchase_counter() + 1;
        return $this->format_purchase_doc($next);
    }

    /**
     * Update product stock quantity
     *
     * @param int $product_id Product ID
     * @param float $quantity Quantity to add/subtract
     * @param string $operation 'add' or 'subtract'
     * @param string $date Transaction date
     * @param int $reference_id Reference transaction ID
     * @return bool
     */
    public function update_product_stock($product_id, $quantity, $operation = 'add', $date = null, $reference_id = null) {
        // Get current product details
        $this->db->select('quantity, price');
        $this->db->where('product_id', $product_id);
        $product = $this->db->get('product_information')->row();

        if (!$product) {
            return false;
        }

        // Calculate new quantity
        if ($operation == 'add') {
            $new_quantity = $product->quantity + $quantity;
        } else {
            $new_quantity = $product->quantity - $quantity;
        }

        // Update product quantity
        $this->db->where('product_id', $product_id);
        $this->db->update('product_information', [
            'quantity' => $new_quantity
        ]);

        return true;
    }

    /**
     * Create batch tracking entry (for items with batch/lot numbers)
     *
     * @param array $batch_data Batch data
     * @return int|false Batch ID or false
     */
    public function create_batch_entry($batch_data) {
        // Check if oglist table exists
        if (!$this->db->table_exists('oglist')) {
            return false;
        }

        $entry = [
            'code' => $batch_data['product_id'],
            'batch' => $batch_data['batch'],
            'weight' => $batch_data['weight'],
            'touch' => $batch_data['touch'],
            'lesswgt' => $batch_data['less_weight'],
            'amount' => $batch_data['amount'],
            'issuedwgt' => $batch_data['issued_weight'],
            'pend' => $batch_data['pending'],
            'tdate' => $batch_data['transaction_date'],
            'docno' => $batch_data['document_no']
        ];

        $this->db->insert('oglist', $entry);
        return $this->db->insert_id();
    }

    /**
     * Update stock ledger (itemsstk table)
     *
     * @param array $ledger_data Stock ledger data
     * @return int|false Entry ID or false
     */
    public function update_stock_ledger($ledger_data) {
        // Check if itemsstk table exists
        if (!$this->db->table_exists('itemsstk')) {
            return false;
        }

        $entry = [
            'code' => $ledger_data['product_id'],
            'tdate' => $ledger_data['transaction_date'],
            'docno' => $ledger_data['document_no'],
            'ttype' => $ledger_data['transaction_type'],
            'qtyin' => $ledger_data['quantity_in'],
            'qtyout' => $ledger_data['quantity_out'],
            'rate' => $ledger_data['rate']
        ];

        $this->db->insert('itemsstk', $entry);
        return $this->db->insert_id();
    }

    /**
     * Update payment status based on payments received
     */
    public function update_payment_status($purchase_id) {
        // Get purchase total
        $this->db->select('grand_total_amount');
        $this->db->where('purchase_id', $purchase_id);
        $purchase = $this->db->get($this->table)->row();

        if (!$purchase) {
            return false;
        }

        // Get total payments
        $this->db->select('SUM(amount) as total_paid');
        $this->db->where('purchase_id', $purchase_id);
        $payment_result = $this->db->get('payment')->row();
        $total_paid = $payment_result->total_paid ?? 0;

        // Determine payment status
        if ($total_paid >= $purchase->grand_total_amount) {
            $payment_status = 'paid';
        } elseif ($total_paid > 0) {
            $payment_status = 'partial';
        } else {
            $payment_status = 'unpaid';
        }

        // Update purchase
        $this->db->where('purchase_id', $purchase_id);
        $this->db->update($this->table, [
            'payment_status' => $payment_status,
            'paid_amount' => $total_paid,
            'due_amount' => max($purchase->grand_total_amount - $total_paid, 0)
        ]);

        return true;
    }

    private function allocate_chalan_sequence(): array
    {
        $current = $this->get_purchase_counter();
        $next = $current + 1;
        $this->set_purchase_counter($next);

        return [
            'counter' => $next,
            'formatted' => $this->format_purchase_doc($next)
        ];
    }

    private function get_purchase_counter(): int
    {
        $row = $this->db
            ->select('cvalue')
            ->where('code', 'PURCHASEB')
            ->get('generali')
            ->row();

        if (!$row) {
            $this->db->insert('generali', [
                'code' => 'PURCHASEB',
                'cvalue' => 0,
                'description' => 'Purchase counter'
            ]);
            return 0;
        }

        return (int) ($row->cvalue ?? 0);
    }

    private function set_purchase_counter(int $value): void
    {
        $this->db->replace('generali', [
            'code' => 'PURCHASEB',
            'cvalue' => $value,
            'description' => 'Purchase counter'
        ]);
    }

    private function format_purchase_doc(int $counter): string
    {
        $config = $this->get_doc_config();
        $length = max(1, (int) ($config['length'] ?? 5));
        $prefix = $config['prefix'] ?? 'PUR-';
        return $prefix . str_pad((string) $counter, $length, '0', STR_PAD_LEFT);
    }

    private function get_doc_config(): array
    {
        if ($this->docConfig !== null) {
            return $this->docConfig;
        }

        $prefixRow = $this->db->select('cvalue')
            ->where('code', 'PBPREF')
            ->get('generals')
            ->row();

        $lengthRow = $this->db->select('cvalue')
            ->where('code', 'PBLEN')
            ->get('generals')
            ->row();

        $this->docConfig = [
            'prefix' => $prefixRow->cvalue ?? 'PUR-',
            'length' => is_numeric($lengthRow->cvalue ?? null) ? (int) $lengthRow->cvalue : 5
        ];

        return $this->docConfig;
    }
}
