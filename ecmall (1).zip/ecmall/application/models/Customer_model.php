<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Customer Model
 * Handles customer data operations
 */
class Customer_model extends MY_Model {

    protected $table = 'customer_information';
    protected $primary_key = 'customer_id';
    protected $timestamps = false;

    /**
     * Cache of table columns to avoid repeated DESCRIBE calls.
     *
     * @var array|null
     */
    private $column_cache = null;

    public function __construct() {
        parent::__construct();
    }

    /**
     * Get customers with pagination and search
     *
     * @param int $per_page Items per page
     * @param int $page Current page
     * @param string $search Search term
     * @return object
     */
    public function get_paginated($per_page = 25, $page = 1, $search = '') {
        $per_page = max(1, (int) $per_page);
        $page = max(1, (int) $page);

        $this->db->start_cache();
        $this->db->from($this->table . ' c');
        $this->db->select('c.*');
        $this->db->select('COALESCE(outstanding_data.outstanding, 0) as outstanding', false);
        $this->db->join(
            '(SELECT customer_id, SUM(due_amount) AS outstanding FROM invoice GROUP BY customer_id) outstanding_data',
            'outstanding_data.customer_id = c.customer_id',
            'left'
        );

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('c.customer_name', $search);
            if ($this->has_column('customer_code')) {
                $this->db->or_like('c.customer_code', $search);
            }
            $this->db->or_like('c.customer_mobile', $search);
            if ($this->has_column('phone')) {
                $this->db->or_like('c.phone', $search);
            }
            $this->db->or_like('c.customer_email', $search);
            if ($this->has_column('email')) {
                $this->db->or_like('c.email', $search);
            }
            $this->db->group_end();
        }

        $this->db->stop_cache();

        $total = (int) $this->db->count_all_results();
        $total_pages = max(1, (int) ceil($total / $per_page));
        $page = min($page, $total_pages);
        $offset = ($page - 1) * $per_page;

        $this->db->order_by('c.customer_id', 'DESC');
        $this->db->limit($per_page, $offset);
        $rows = $this->db->get()->result();

        $this->db->flush_cache();

        return (object) [
            'data' => $rows,
            'total' => $total,
            'per_page' => $per_page,
            'current_page' => $page,
            'last_page' => $total_pages,
            'total_pages' => $total_pages,
            'from' => $total ? $offset + 1 : 0,
            'to' => min($offset + $per_page, $total)
        ];
    }

    /**
     * Get customer with outstanding balance
     *
     * @param int $customer_id Customer ID
     * @return object
     */
    public function get_with_outstanding($customer_id) {
        $code_field = $this->has_column('customer_code') ? 'c.customer_code' : 'c.customer_id';

        $this->db->select('c.*');
        $this->db->select($code_field . ' as customer_code', false);
        $this->db->select('COALESCE(SUM(i.grand_total), 0) as total_invoiced', false);
        $this->db->select('COALESCE(SUM(i.paid_amount), 0) as total_paid', false);
        $this->db->select('COALESCE(SUM(i.due_amount), 0) as total_outstanding', false);
        $this->db->from($this->table . ' c');
        $this->db->join('invoice i', 'i.customer_id = c.customer_id', 'left');
        $this->db->where('c.customer_id', $customer_id);
        $this->db->group_by('c.customer_id');

        $query = $this->db->get();
        return $query->row();
    }

    /**
     * Get top customers by revenue
     *
     * @param int $limit Number of customers
     * @param string $period Period (month, year, all)
     * @return array
     */
    public function get_top_customers($limit = 10, $period = 'year') {
        $this->db->select('
            c.customer_id,
            c.customer_name,
            c.customer_mobile,
            c.customer_email,
            COUNT(DISTINCT i.invoice_id) as invoice_count,
            COALESCE(SUM(i.grand_total), 0) as total_revenue,
            COALESCE(SUM(i.paid_amount), 0) as total_paid,
            COALESCE(SUM(i.due_amount), 0) as total_outstanding
        ');
        $this->db->from($this->table . ' c');
        $this->db->join('invoice i', 'i.customer_id = c.customer_id', 'left');

        // Apply period filter
        if ($period == 'month') {
            $this->db->where('MONTH(i.date)', date('m'));
            $this->db->where('YEAR(i.date)', date('Y'));
        } elseif ($period == 'year') {
            $this->db->where('YEAR(i.date)', date('Y'));
        }

        $this->db->where('c.status', 1);
        $this->db->group_by('c.customer_id');
        $this->db->order_by('total_revenue', 'DESC');
        $this->db->limit($limit);

        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Get customer ledger
     *
     * @param int $customer_id Customer ID
     * @param string $from_date Start date
     * @param string $to_date End date
     * @return array
     */
    public function get_ledger($customer_id, $from_date = null, $to_date = null) {
        $this->db->select('
            i.invoice,
            i.date,
            i.grand_total as debit,
            i.paid_amount as credit,
            i.due_amount as balance,
            i.payment_status,
            "Invoice" as type
        ');
        $this->db->from('invoice i');
        $this->db->where('i.customer_id', $customer_id);

        if ($from_date) {
            $this->db->where('i.date >=', $from_date);
        }
        if ($to_date) {
            $this->db->where('i.date <=', $to_date);
        }

        $this->db->order_by('i.date', 'ASC');

        $query = $this->db->get();
        return $query->result();
    }

    /**
     * Check whether a mobile number already exists on another customer.
     */
    public function mobile_exists($mobile, $exclude_id = null) {
        $mobile = trim((string) $mobile);
        if ($mobile === '') {
            return false;
        }

        $this->db->group_start();
        $this->db->where('customer_mobile', $mobile);
        if ($this->has_column('phone')) {
            $this->db->or_where('phone', $mobile);
        }
        $this->db->group_end();

        if ($exclude_id) {
            $this->db->where($this->primary_key . ' !=', $exclude_id);
        }

        return $this->db->count_all_results($this->table) > 0;
    }

    /**
     * Lightweight autocomplete dataset.
     */
    public function search_for_autocomplete($term = '') {
        $this->db->select('customer_id, customer_name, customer_mobile, customer_email');
        if ($this->has_column('customer_code')) {
            $this->db->select('customer_code');
        }
        $this->db->from($this->table);

        if (!empty($term)) {
            $this->db->group_start();
            $this->db->like('customer_name', $term);
            $this->db->or_like('customer_mobile', $term);
            if ($this->has_column('customer_code')) {
                $this->db->or_like('customer_code', $term);
            }
            $this->db->group_end();
        }

        $this->db->order_by('customer_name', 'ASC');
        $this->db->limit(10);
        return $this->db->get()->result();
    }

    /**
     * Override insert/update to mirror data into legacy columns.
     */
    public function insert($data) {
        $data = $this->sync_legacy_columns($data, true);
        return parent::insert($data);
    }

    public function update($id, $data) {
        $data = $this->sync_legacy_columns($data, false);
        return parent::update($id, $data);
    }

    /**
     * Generate customer code
     *
     * @return string
     */
    public function generate_code() {
        $this->db->select_max('customer_id');
        $query = $this->db->get($this->table);
        $row = $query->row();

        $next_id = $row->customer_id ? $row->customer_id + 1 : 1;
        return 'CUST-' . str_pad($next_id, 4, '0', STR_PAD_LEFT);
    }

    /**
     * Apply backwards-compatible column mappings for the legacy schema.
     */
    private function sync_legacy_columns(array $data, bool $ensure_code = true): array {
        if ($this->has_column('customer_code') && $ensure_code && empty($data['customer_code'])) {
            $data['customer_code'] = $this->generate_code();
        }

        if ($this->has_column('phone') && isset($data['customer_mobile']) && !array_key_exists('phone', $data)) {
            $data['phone'] = $data['customer_mobile'];
        }

        if ($this->has_column('email') && isset($data['customer_email']) && !array_key_exists('email', $data)) {
            $data['email'] = $data['customer_email'];
        }

        return $data;
    }

    /**
     * Determine if the underlying table contains the provided column.
     */
    private function has_column(string $column): bool {
        if ($this->column_cache === null) {
            $fields = $this->db->list_fields($this->table);
            $this->column_cache = array_flip($fields);
        }

        return isset($this->column_cache[$column]);
    }
}
