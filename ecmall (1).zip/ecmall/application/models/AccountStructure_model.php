<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class AccountStructure_model extends CI_Model
{
    const TABLE_ACCOUNTS = 'accountm';
    const TABLE_GROUPS = 'accountg';
    const TABLE_HEADS = 'accountgbs';

    public function get_account_positions(string $sort = 'tplpos')
    {
        $this->db->from(self::TABLE_ACCOUNTS);

        switch ($sort) {
            case 'shepos':
                $this->db->order_by('shepos ASC');
                break;
            case 'name':
                $this->db->order_by('name ASC');
                break;
            default:
                $this->db->order_by('tplpos ASC');
        }

        $this->db->order_by('name ASC');
        return $this->db->get()->result();
    }

    public function update_account_positions(array $records): int
    {
        $count = 0;
        foreach ($records as $accode => $fields) {
            $data = [
                'tplpos' => (int) ($fields['tplpos'] ?? 0),
                'shepos' => (int) ($fields['shepos'] ?? 0),
                'shedgrp' => $fields['shedgrp'] ?? null
            ];
            $this->db->where('accode', $accode);
            if ($this->db->update(self::TABLE_ACCOUNTS, $data)) {
                $count++;
            }
        }
        return $count;
    }

    public function get_group_positions(): array
    {
        return $this->db->order_by('pos ASC')->get(self::TABLE_GROUPS)->result();
    }

    public function update_group_positions(array $records): int
    {
        $count = 0;
        foreach ($records as $grcode => $fields) {
            $this->db->where('grcode', $grcode);
            if ($this->db->update(self::TABLE_GROUPS, ['pos' => (int) ($fields['pos'] ?? 0)])) {
                $count++;
            }
        }
        return $count;
    }

    public function get_head_positions(): array
    {
        return $this->db->order_by('pos ASC')->get(self::TABLE_HEADS)->result();
    }

    public function update_head_positions(array $records): int
    {
        $count = 0;
        foreach ($records as $hcode => $fields) {
            $this->db->where('hcode', $hcode);
            if ($this->db->update(self::TABLE_HEADS, ['pos' => (int) ($fields['pos'] ?? 0)])) {
                $count++;
            }
        }
        return $count;
    }

    public function get_accounts(array $filters = []): array
    {
        if (!empty($filters['search'])) {
            $this->db
                ->group_start()
                ->like('accode', $filters['search'])
                ->or_like('name', $filters['search'])
                ->group_end();
        }
        return $this->db->order_by('accode ASC')->get(self::TABLE_ACCOUNTS)->result();
    }

    public function get_account(string $accode)
    {
        return $this->db->where('accode', $accode)->get(self::TABLE_ACCOUNTS)->row();
    }

    public function save_account(array $data, ?string $accode = null)
    {
        $payload = [
            'name' => $data['name'],
            'actype1' => $data['actype1'],
            'reserve' => $data['reserve'] ?? 'N',
            'grcode' => $data['grcode'] ?? null,
            'opbal' => $data['opbal'] ?? 0,
            'opbalb' => $data['opbalb'] ?? 0,
            'control' => $data['control'] ?? 1,
            'hlp' => $data['hlp'] ?? 1,
            'tplpos' => $data['tplpos'] ?? 0,
            'bshead' => $data['bshead'] ?? null,
            'shepos' => $data['shepos'] ?? 0,
            'shedgrp' => $data['shedgrp'] ?? null,
            'sp' => $data['sp'] ?? 0,
            'removed' => $data['removed'] ?? 'N',
            'blocked' => $data['blocked'] ?? 'N',
            'note' => $data['note'] ?? null
        ];

        if ($accode) {
            $this->db->where('accode', $accode);
            return $this->db->update(self::TABLE_ACCOUNTS, $payload);
        }

        $payload['accode'] = $data['accode'];
        return $this->db->insert(self::TABLE_ACCOUNTS, $payload);
    }

    public function delete_account(string $accode): bool
    {
        $this->db->where('accode', $accode);
        return $this->db->delete(self::TABLE_ACCOUNTS);
    }

    public function get_groups(): array
    {
        return $this->db->order_by('grcode ASC')->get(self::TABLE_GROUPS)->result();
    }

    public function get_group(string $grcode)
    {
        return $this->db->where('grcode', $grcode)->get(self::TABLE_GROUPS)->row();
    }

    public function get_head(string $hcode)
    {
        return $this->db->where('hcode', $hcode)->get(self::TABLE_HEADS)->row();
    }

    public function delete_head(string $hcode): bool
    {
        $this->db->where('hcode', $hcode);
        return $this->db->delete(self::TABLE_HEADS);
    }

    public function save_group(array $data, ?string $grcode = null)
    {
        $payload = [
            'name' => $data['name'],
            'reserve' => $data['reserve'] ?? 'N',
            'actype1' => $data['actype1'],
            'position' => $data['position'] ?? 0,
            'pos' => $data['pos'] ?? 0,
            'mgrp' => $data['mgrp'] ?? null
        ];

        if ($grcode) {
            $this->db->where('grcode', $grcode);
            return $this->db->update(self::TABLE_GROUPS, $payload);
        }

        $payload['grcode'] = $data['grcode'];
        return $this->db->insert(self::TABLE_GROUPS, $payload);
    }

    public function delete_group(string $grcode): bool
    {
        $this->db->where('grcode', $grcode);
        return $this->db->delete(self::TABLE_GROUPS);
    }

    public function group_has_accounts(string $grcode): bool
    {
        $this->db->where('grcode', $grcode);
        return $this->db->count_all_results(self::TABLE_ACCOUNTS) > 0;
    }

    public function get_heads(): array
    {
        return $this->db->order_by('hcode ASC')->get(self::TABLE_HEADS)->result();
    }

    public function save_head(array $data, ?string $hcode = null): bool
    {
        if ($hcode) {
            $this->db->where('hcode', $hcode);
            return $this->db->update(self::TABLE_HEADS, $data);
        }

        return $this->db->insert(self::TABLE_HEADS, $data);
    }

    public function import_from_file(string $type, string $path): array
    {
        if (!file_exists($path)) {
            throw new RuntimeException("File not found: {$path}");
        }

        $handle = fopen($path, 'r');
        if (!$handle) {
            throw new RuntimeException("Unable to open file: {$path}");
        }

        $header = null;
        $imported = 0;
        while (($row = fgetcsv($handle)) !== false) {
            if (!$header) {
                $header = array_map(function ($col) {
                    return preg_replace('/^text/', '', strtolower(trim($col)));
                }, $row);
                continue;
            }

            if (count(array_filter($row)) === 0) {
                continue;
            }

            if (count($row) < count($header)) {
                $row = array_pad($row, count($header), null);
            } elseif (count($row) > count($header)) {
                $row = array_slice($row, 0, count($header));
            }

            $assoc = array_combine($header, $row);
            switch ($type) {
                case 'accounts':
                    $this->upsert_account_from_csv($assoc);
                    break;
                case 'groups':
                    $this->upsert_group_from_csv($assoc);
                    break;
                case 'heads':
                    $this->upsert_head_from_csv($assoc);
                    break;
            }
            $imported++;
        }

        fclose($handle);
        return ['imported' => $imported];
    }

    private function upsert_account_from_csv(array $row): void
    {
        if (empty($row['accode'])) {
            return;
        }

        $data = [
            'accode' => $row['accode'],
            'name' => $row['name'] ?? '',
            'actype1' => $row['actype1'] ?? 'A',
            'actype2' => $row['actype2'] ?? null,
            'reserve' => strtoupper($row['reserve'] ?? 'N'),
            'grcode' => $row['grcode'] ?? null,
            'opbal' => $row['opbal'] ?? 0,
            'opbalb' => $row['opbalb'] ?? 0,
            'tplpos' => $row['tplpos'] ?? 0,
            'bshead' => $row['bshead'] ?? null,
            'shepos' => $row['shepos'] ?? 0,
            'shedgrp' => $row['shedgrp'] ?? null,
            'sp' => $row['sp'] ?? 0,
            'removed' => strtoupper($row['removed'] ?? 'N'),
            'blocked' => strtoupper($row['blocked'] ?? 'N'),
            'note' => $row['note'] ?? null
        ];

        if ($this->get_account($data['accode'])) {
            $this->save_account($data, $data['accode']);
        } else {
            $this->save_account($data);
        }
    }

    private function upsert_group_from_csv(array $row): void
    {
        if (empty($row['grcode'])) {
            return;
        }

        $data = [
            'grcode' => $row['grcode'],
            'name' => $row['name'] ?? '',
            'reserve' => strtoupper($row['reserve'] ?? 'N'),
            'actype1' => $row['actype1'] ?? 'A',
            'position' => $row['position'] ?? 0,
            'pos' => $row['pos'] ?? 0,
            'mgrp' => $row['mgrp'] ?? null
        ];

        if ($this->get_group($data['grcode'])) {
            $this->save_group($data, $data['grcode']);
        } else {
            $this->save_group($data);
        }
    }

    private function upsert_head_from_csv(array $row): void
    {
        if (empty($row['hcode'])) {
            return;
        }

        $payload = [
            'hcode' => $row['hcode'],
            'hname' => $row['hname'] ?? '',
            'actype1' => $row['actype1'] ?? 'A',
            'pos' => $row['pos'] ?? 0,
            'reserve' => strtoupper($row['reserve'] ?? 'N'),
            'expand' => strtoupper($row['expand'] ?? 'N')
        ];

        if ($this->db->where('hcode', $payload['hcode'])->get(self::TABLE_HEADS)->row()) {
            $this->db->where('hcode', $payload['hcode'])->update(self::TABLE_HEADS, $payload);
        } else {
            $this->db->insert(self::TABLE_HEADS, $payload);
        }
    }

    public function get_schedule_groups(): array
    {
        $this->db->select('DISTINCT shedgrp', false);
        $this->db->from(self::TABLE_ACCOUNTS);
        $this->db->where("shedgrp IS NOT NULL AND shedgrp != ''");
        $this->db->order_by('shedgrp', 'ASC');
        return array_map(function ($row) {
            return $row->shedgrp;
        }, $this->db->get()->result());
    }
}
