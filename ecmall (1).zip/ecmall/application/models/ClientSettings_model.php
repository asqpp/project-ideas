<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ClientSettings_model extends CI_Model
{
    private $autocodeMap = [
        'customer' => 'CLIENT_AUTOCODE_CUSTOMER',
        'supplier' => 'CLIENT_AUTOCODE_SUPPLIER'
    ];

    private $defaultConfig = [
        'enabled' => true,
        'prefix' => 'CL',
        'next' => 1,
        'padding' => 4
    ];

    public function get_autocode(string $type): array
    {
        $key = $this->autocode_key($type);
        if (!$key) {
            return $this->defaultConfig;
        }

        $row = $this->db->get_where('generali', ['code' => $key])->row();
        if (!$row) {
            return $this->defaultConfig;
        }

        $payload = json_decode($row->cvalue ?? '', true);
        if (!is_array($payload)) {
            $payload = [];
        }

        return array_merge($this->defaultConfig, $payload);
    }

    public function save_autocode(string $type, array $config): void
    {
        $key = $this->autocode_key($type);
        if (!$key) {
            return;
        }

        $payload = [
            'enabled' => !empty($config['enabled']),
            'prefix' => strtoupper($config['prefix'] ?? $this->defaultConfig['prefix']),
            'next' => max(1, (int) ($config['next'] ?? 1)),
            'padding' => max(1, (int) ($config['padding'] ?? 4))
        ];

        $data = [
            'code' => $key,
            'cvalue' => json_encode($payload),
            'description' => ($type === 'customer') ? 'Auto-code settings for customers' : 'Auto-code settings for suppliers'
        ];

        $this->db->replace('generali', $data);
    }

    public function consume_code(string $type): ?string
    {
        $key = $this->autocode_key($type);
        if (!$key) {
            return null;
        }

        $this->db->trans_start();
        $row = $this->db->get_where('generali', ['code' => $key])->row();
        $config = array_merge($this->defaultConfig, $row ? (json_decode($row->cvalue ?? '', true) ?: []) : []);

        if (empty($config['enabled'])) {
            $this->db->trans_complete();
            return null;
        }

        $number = (int) $config['next'];
        $code = strtoupper($config['prefix']) . str_pad((string) $number, (int) $config['padding'], '0', STR_PAD_LEFT);
        $config['next'] = $number + 1;

        $this->db->replace('generali', [
            'code' => $key,
            'cvalue' => json_encode($config),
            'description' => ($type === 'customer') ? 'Auto-code settings for customers' : 'Auto-code settings for suppliers'
        ]);
        $this->db->trans_complete();

        return $code;
    }

    private function autocode_key(string $type): ?string
    {
        $type = strtolower($type);
        return $this->autocodeMap[$type] ?? null;
    }
}
