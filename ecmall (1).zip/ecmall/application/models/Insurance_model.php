<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Insurance_model
 *
 * Central place for insurance domain persistence (policies, claims, underwriting,
 * premium collections, commissions, renewals, endorsements). The constructor
 * auto-provisions lightweight tables so the UI can start saving data even on
 * a fresh database.
 */
class Insurance_model extends CI_Model
{
    const TABLE_POLICIES            = 'insurance_policies';
    const TABLE_CLAIMS              = 'insurance_claims';
    const TABLE_UNDERWRITING        = 'insurance_underwriting_reviews';
    const TABLE_PREMIUM_COLLECTIONS = 'insurance_premium_collections';
    const TABLE_COMMISSIONS         = 'insurance_commissions';
    const TABLE_RENEWALS            = 'insurance_renewals';
    const TABLE_ENDORSEMENTS        = 'insurance_endorsements';

    public function __construct()
    {
        parent::__construct();
        $this->load->dbforge();
        $this->ensure_tables();
    }

    /**
     * Ensure all auxiliary tables exist. Using DBForge keeps things idempotent.
     */
    private function ensure_tables(): void
    {
        $this->maybe_create_table(self::TABLE_POLICIES, [
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'policy_number'   => ['type' => 'VARCHAR', 'constraint' => 100],
            'customer_id'     => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'product_id'      => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'agent_id'        => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'effective_date'  => ['type' => 'DATE', 'null' => true],
            'expiry_date'     => ['type' => 'DATE', 'null' => true],
            'premium_amount'  => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'payment_mode'    => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'status'          => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'created_by'      => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
            'updated_at'      => ['type' => 'DATETIME', 'null' => true],
        ], ['policy_number']);

        $this->maybe_create_table(self::TABLE_CLAIMS, [
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'claim_number'   => ['type' => 'VARCHAR', 'constraint' => 100],
            'policy_id'      => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'policy_number'  => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'customer_id'    => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'loss_date'      => ['type' => 'DATE', 'null' => true],
            'loss_type'      => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'reserve_amount' => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'adjuster'       => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'status'         => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'narration'      => ['type' => 'TEXT', 'null' => true],
            'created_by'     => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ], ['claim_number']);

        $this->maybe_create_table(self::TABLE_UNDERWRITING, [
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'submission_ref' => ['type' => 'VARCHAR', 'constraint' => 100],
            'channel_type'   => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'channel_id'     => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'risk_category'  => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'sum_assured'    => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'base_rate'      => ['type' => 'DECIMAL', 'constraint' => '10,4', 'default' => '0.0000'],
            'loading'        => ['type' => 'DECIMAL', 'constraint' => '10,4', 'default' => '0.0000'],
            'decision'       => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'remarks'        => ['type' => 'TEXT', 'null' => true],
            'created_by'     => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ], ['submission_ref']);

        $this->maybe_create_table(self::TABLE_PREMIUM_COLLECTIONS, [
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'reference_type' => ['type' => 'VARCHAR', 'constraint' => 50],
            'reference_id'   => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'due_date'       => ['type' => 'DATE', 'null' => true],
            'installment_no' => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'due_amount'     => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'receipt_type'   => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'collection_owner' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'remarks'        => ['type' => 'TEXT', 'null' => true],
            'status'         => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'created_by'     => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ]);

        $this->maybe_create_table(self::TABLE_COMMISSIONS, [
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'partner_type'  => ['type' => 'VARCHAR', 'constraint' => 50],
            'partner_id'    => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'partner_name'  => ['type' => 'VARCHAR', 'constraint' => 191, 'null' => true],
            'policy_number' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'commission_pct'=> ['type' => 'DECIMAL', 'constraint' => '10,4', 'default' => '0.0000'],
            'commission_amount' => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'payable_on'    => ['type' => 'DATE', 'null' => true],
            'approval_status' => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'notes'         => ['type' => 'TEXT', 'null' => true],
            'created_by'    => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);

        $this->maybe_create_table(self::TABLE_RENEWALS, [
            'id'              => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'policy_number'   => ['type' => 'VARCHAR', 'constraint' => 100],
            'current_expiry'  => ['type' => 'DATE', 'null' => true],
            'category'        => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'assigned_to'     => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'proposed_premium'=> ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'follow_up_date'  => ['type' => 'DATE', 'null' => true],
            'feedback'        => ['type' => 'TEXT', 'null' => true],
            'status'          => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'created_by'      => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'      => ['type' => 'DATETIME', 'null' => true],
            'updated_at'      => ['type' => 'DATETIME', 'null' => true],
        ], ['policy_number']);

        $this->maybe_create_table(self::TABLE_ENDORSEMENTS, [
            'id'               => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'policy_number'    => ['type' => 'VARCHAR', 'constraint' => 100],
            'endorsement_type' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'effective_date'   => ['type' => 'DATE', 'null' => true],
            'premium_impact'   => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'approval_route'   => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'description'      => ['type' => 'TEXT', 'null' => true],
            'status'           => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'created_by'       => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'       => ['type' => 'DATETIME', 'null' => true],
            'updated_at'       => ['type' => 'DATETIME', 'null' => true],
        ], ['policy_number']);
    }

    /**
     * Helper to create table if needed.
     */
    private function maybe_create_table(string $table, array $fields, array $unique_keys = []): void
    {
        if ($this->db->table_exists($table)) {
            return;
        }

        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);

        foreach ($unique_keys as $key) {
            $this->dbforge->add_key($key, FALSE, TRUE);
        }

        $this->dbforge->create_table($table, TRUE);
    }

    // ---------------------------------------------------------------------
    // CRUD helpers
    // ---------------------------------------------------------------------

    public function create_policy(array $data)
    {
        return $this->insert_row(self::TABLE_POLICIES, $data);
    }

    public function create_claim(array $data)
    {
        return $this->insert_row(self::TABLE_CLAIMS, $data);
    }

    public function create_underwriting(array $data)
    {
        return $this->insert_row(self::TABLE_UNDERWRITING, $data);
    }

    public function create_premium_collection(array $data)
    {
        return $this->insert_row(self::TABLE_PREMIUM_COLLECTIONS, $data);
    }

    public function create_commission(array $data)
    {
        return $this->insert_row(self::TABLE_COMMISSIONS, $data);
    }

    public function create_renewal(array $data)
    {
        return $this->insert_row(self::TABLE_RENEWALS, $data);
    }

    public function create_endorsement(array $data)
    {
        return $this->insert_row(self::TABLE_ENDORSEMENTS, $data);
    }

    private function insert_row(string $table, array $data)
    {
        $now = date('Y-m-d H:i:s');
        if ($this->db->field_exists('created_at', $table) && !isset($data['created_at'])) {
            $data['created_at'] = $now;
        }
        if ($this->db->field_exists('created_by', $table) && isset($this->session) && $this->session->userdata('user_id')) {
            $data['created_by'] = $this->session->userdata('user_id');
        }
        if ($this->db->field_exists('updated_at', $table)) {
            $data['updated_at'] = $now;
        }

        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    // ---------------------------------------------------------------------
    // Query helpers for reports
    // ---------------------------------------------------------------------

    public function get_policy_metrics(): array
    {
        $metrics = [
            'total'   => $this->db->count_all(self::TABLE_POLICIES),
            'active'  => $this->count_where(self::TABLE_POLICIES, ['status' => 'Active']),
            'renewal_due' => $this->count_renewals_due(30),
            'pending_endorsements' => $this->count_where(self::TABLE_ENDORSEMENTS, ['status' => 'Pending']),
        ];

        $metrics['outstanding_premium'] = $this->sum_column(self::TABLE_PREMIUM_COLLECTIONS, 'due_amount', ['status' => 'Pending']);

        return $metrics;
    }

    public function count_where(string $table, array $where = []): int
    {
        if (!empty($where)) {
            $this->db->where($where);
        }
        return (int) $this->db->count_all_results($table);
    }

    private function count_renewals_due(int $days): int
    {
        $date = date('Y-m-d', strtotime("+{$days} days"));
        $this->db->where('current_expiry <=', $date);
        return (int) $this->db->count_all_results(self::TABLE_RENEWALS);
    }

    public function sum_column(string $table, string $column, array $where = []): float
    {
        $this->db->select_sum($column, 'sum_value');
        if (!empty($where)) {
            $this->db->where($where);
        }
        $row = $this->db->get($table)->row();
        return (float) ($row->sum_value ?? 0);
    }

    public function get_policies(array $filters = [], int $limit = 100, int $offset = 0)
    {
        return $this->apply_date_filters(self::TABLE_POLICIES, $filters, 'effective_date', $limit, $offset)->result();
    }

    public function get_claims(array $filters = [], int $limit = 100, int $offset = 0)
    {
        return $this->apply_date_filters(self::TABLE_CLAIMS, $filters, 'loss_date', $limit, $offset)->result();
    }

    public function get_premium_collections(array $filters = [], int $limit = 100, int $offset = 0)
    {
        return $this->apply_date_filters(self::TABLE_PREMIUM_COLLECTIONS, $filters, 'due_date', $limit, $offset)->result();
    }

    public function get_commissions(array $filters = [], int $limit = 100, int $offset = 0)
    {
        return $this->apply_date_filters(self::TABLE_COMMISSIONS, $filters, 'payable_on', $limit, $offset)->result();
    }

    public function get_renewals(array $filters = [], int $limit = 100, int $offset = 0)
    {
        return $this->apply_date_filters(self::TABLE_RENEWALS, $filters, 'current_expiry', $limit, $offset)->result();
    }

    public function get_endorsements(array $filters = [], int $limit = 100, int $offset = 0)
    {
        return $this->apply_date_filters(self::TABLE_ENDORSEMENTS, $filters, 'effective_date', $limit, $offset)->result();
    }

    private function apply_date_filters(string $table, array $filters, string $field, int $limit, int $offset)
    {
        $this->db->from($table);

        if (!empty($filters['from_date'])) {
            $this->db->where("{$field} >=", $filters['from_date']);
        }

        if (!empty($filters['to_date'])) {
            $this->db->where("{$field} <=", $filters['to_date']);
        }

        if (!empty($filters['status'])) {
            $this->db->where('status', $filters['status']);
        }

        $this->db->order_by($field ?: 'id', 'DESC');
        $this->db->limit($limit, $offset);

        return $this->db->get();
    }

    public function get_policy_dropdown(): array
    {
        $this->db->select('id, policy_number');
        $this->db->from(self::TABLE_POLICIES);
        $this->db->order_by('policy_number', 'ASC');

        return $this->db->get()->result();
    }

    public function get_policy_by_number(string $policy_number)
    {
        return $this->db
            ->where('policy_number', $policy_number)
            ->get(self::TABLE_POLICIES)
            ->row();
    }
}
