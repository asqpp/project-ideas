<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Accounting_operations_model
 *
 * Stores data for bank reconciliations, credit notes and debit notes that
 * come from the new Accounting forms.
 */
class Accounting_operations_model extends CI_Model
{
    const TABLE_BANK_RECON   = 'accounting_bank_reconciliations';
    const TABLE_CREDIT_NOTES = 'accounting_credit_notes';
    const TABLE_DEBIT_NOTES  = 'accounting_debit_notes';

    public function __construct()
    {
        parent::__construct();
        $this->load->dbforge();
        $this->ensure_tables();
    }

    private function ensure_tables(): void
    {
        $this->maybe_create_table(self::TABLE_BANK_RECON, [
            'id'                 => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'bank_account'       => ['type' => 'VARCHAR', 'constraint' => 150],
            'statement_date'     => ['type' => 'DATE'],
            'ledger_balance'     => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'statement_balance'  => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'unpresented_cheques'=> ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'deposits_in_transit'=> ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'notes'              => ['type' => 'TEXT', 'null' => true],
            'created_by'         => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'         => ['type' => 'DATETIME', 'null' => true],
            'updated_at'         => ['type' => 'DATETIME', 'null' => true],
        ]);

        $columns = [
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'reference_type' => ['type' => 'VARCHAR', 'constraint' => 100],
            'reference_number' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'entry_date'     => ['type' => 'DATE'],
            'account_code'   => ['type' => 'VARCHAR', 'constraint' => 50],
            'amount'         => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'reason'         => ['type' => 'TEXT', 'null' => true],
            'created_by'     => ['type' => 'INT', 'constraint' => 11, 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ];

        $this->maybe_create_table(self::TABLE_CREDIT_NOTES, $columns);
        $this->maybe_create_table(self::TABLE_DEBIT_NOTES, $columns);
    }

    private function maybe_create_table(string $table, array $fields): void
    {
        if ($this->db->table_exists($table)) {
            return;
        }

        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table, TRUE);
    }

    private function insert_row(string $table, array $data)
    {
        $now = date('Y-m-d H:i:s');
        if ($this->db->field_exists('created_at', $table) && !isset($data['created_at'])) {
            $data['created_at'] = $now;
        }
        if ($this->db->field_exists('updated_at', $table)) {
            $data['updated_at'] = $now;
        }
        if ($this->db->field_exists('created_by', $table) && $this->session->userdata('user_id')) {
            $data['created_by'] = $this->session->userdata('user_id');
        }

        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    public function create_bank_reconciliation(array $data)
    {
        return $this->insert_row(self::TABLE_BANK_RECON, $data);
    }

    public function create_credit_note(array $data)
    {
        return $this->insert_row(self::TABLE_CREDIT_NOTES, $data);
    }

    public function create_debit_note(array $data)
    {
        return $this->insert_row(self::TABLE_DEBIT_NOTES, $data);
    }

    public function get_bank_reconciliations(array $filters = [])
    {
        $this->db->from(self::TABLE_BANK_RECON);
        if (!empty($filters['from_date'])) {
            $this->db->where('statement_date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $this->db->where('statement_date <=', $filters['to_date']);
        }
        return $this->db->get()->result();
    }

    public function get_credit_notes()
    {
        return $this->db->get(self::TABLE_CREDIT_NOTES)->result();
    }

    public function get_debit_notes()
    {
        return $this->db->get(self::TABLE_DEBIT_NOTES)->result();
    }
}
