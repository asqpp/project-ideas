<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Hr_model
 *
 * Consolidates persistence logic for employee master, attendance, leave,
 * payroll, salary structures and performance reviews. Similar to
 * Insurance_model it auto-provisions its tables.
 */
class Hr_model extends CI_Model
{
    const TABLE_EMPLOYEES    = 'hr_employees';
    const TABLE_ATTENDANCE   = 'hr_attendance';
    const TABLE_LEAVES       = 'hr_leave_requests';
    const TABLE_PAYROLL      = 'hr_payroll_cycles';
    const TABLE_STRUCTURES   = 'hr_salary_structures';
    const TABLE_PERFORMANCE  = 'hr_performance_reviews';

    public function __construct()
    {
        parent::__construct();
        $this->load->dbforge();
        $this->ensure_tables();
    }

    private function ensure_tables(): void
    {
        $this->maybe_create_table(self::TABLE_EMPLOYEES, [
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'employee_code'  => ['type' => 'VARCHAR', 'constraint' => 50],
            'full_name'      => ['type' => 'VARCHAR', 'constraint' => 191],
            'department'     => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'designation'    => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'joining_date'   => ['type' => 'DATE', 'null' => true],
            'work_email'     => ['type' => 'VARCHAR', 'constraint' => 191, 'null' => true],
            'status'         => ['type' => 'VARCHAR', 'constraint' => 50, 'default' => 'Active'],
            'notes'          => ['type' => 'TEXT', 'null' => true],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ], ['employee_code']);

        $this->maybe_create_table(self::TABLE_ATTENDANCE, [
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'employee_id'   => ['type' => 'INT', 'constraint' => 11],
            'attendance_date' => ['type' => 'DATE'],
            'check_in'      => ['type' => 'TIME', 'null' => true],
            'check_out'     => ['type' => 'TIME', 'null' => true],
            'work_location' => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'remarks'       => ['type' => 'TEXT', 'null' => true],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ], ['employee_id', 'attendance_date']);

        $this->maybe_create_table(self::TABLE_LEAVES, [
            'id'          => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'employee_id' => ['type' => 'INT', 'constraint' => 11],
            'leave_type'  => ['type' => 'VARCHAR', 'constraint' => 100],
            'from_date'   => ['type' => 'DATE'],
            'to_date'     => ['type' => 'DATE'],
            'total_days'  => ['type' => 'DECIMAL', 'constraint' => '10,2', 'default' => '0.00'],
            'approver'    => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'reason'      => ['type' => 'TEXT', 'null' => true],
            'status'      => ['type' => 'VARCHAR', 'constraint' => 50, 'default' => 'Pending'],
            'created_at'  => ['type' => 'DATETIME', 'null' => true],
            'updated_at'  => ['type' => 'DATETIME', 'null' => true],
        ]);

        $this->maybe_create_table(self::TABLE_PAYROLL, [
            'id'            => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'payroll_month' => ['type' => 'VARCHAR', 'constraint' => 20],
            'pay_group'     => ['type' => 'VARCHAR', 'constraint' => 100, 'null' => true],
            'payment_date'  => ['type' => 'DATE', 'null' => true],
            'basic_salary'  => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'allowances'    => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'deductions'    => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'net_pay'       => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'remarks'       => ['type' => 'TEXT', 'null' => true],
            'status'        => ['type' => 'VARCHAR', 'constraint' => 50, 'default' => 'Draft'],
            'created_at'    => ['type' => 'DATETIME', 'null' => true],
            'updated_at'    => ['type' => 'DATETIME', 'null' => true],
        ]);

        $this->maybe_create_table(self::TABLE_STRUCTURES, [
            'id'               => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'grade'            => ['type' => 'VARCHAR', 'constraint' => 20],
            'basic_pct'        => ['type' => 'DECIMAL', 'constraint' => '10,2', 'default' => '0.00'],
            'housing_allowance'=> ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'transport_allowance' => ['type' => 'DECIMAL', 'constraint' => '15,2', 'default' => '0.00'],
            'other_benefits'   => ['type' => 'TEXT', 'null' => true],
            'created_at'       => ['type' => 'DATETIME', 'null' => true],
            'updated_at'       => ['type' => 'DATETIME', 'null' => true],
        ], ['grade']);

        $this->maybe_create_table(self::TABLE_PERFORMANCE, [
            'id'             => ['type' => 'INT', 'constraint' => 11, 'unsigned' => true, 'auto_increment' => true],
            'employee_id'    => ['type' => 'INT', 'constraint' => 11],
            'review_period'  => ['type' => 'VARCHAR', 'constraint' => 20],
            'rating'         => ['type' => 'VARCHAR', 'constraint' => 50, 'null' => true],
            'kpi_score'      => ['type' => 'DECIMAL', 'constraint' => '10,2', 'default' => '0.00'],
            'development_plan' => ['type' => 'TEXT', 'null' => true],
            'status'         => ['type' => 'VARCHAR', 'constraint' => 50, 'default' => 'Draft'],
            'created_at'     => ['type' => 'DATETIME', 'null' => true],
            'updated_at'     => ['type' => 'DATETIME', 'null' => true],
        ], ['employee_id', 'review_period']);
    }

    private function maybe_create_table(string $table, array $fields, array $unique = []): void
    {
        if ($this->db->table_exists($table)) {
            return;
        }

        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        foreach ($unique as $field) {
            $this->dbforge->add_key($field, FALSE, TRUE);
        }
        $this->dbforge->create_table($table, TRUE);
    }

    private function stamp_and_insert(string $table, array $data)
    {
        $now = date('Y-m-d H:i:s');

        if ($this->db->field_exists('created_at', $table) && !isset($data['created_at'])) {
            $data['created_at'] = $now;
        }

        if ($this->db->field_exists('updated_at', $table)) {
            $data['updated_at'] = $now;
        }

        $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    public function save_employee(array $data)
    {
        return $this->stamp_and_insert(self::TABLE_EMPLOYEES, $data);
    }

    public function save_attendance(array $data)
    {
        return $this->stamp_and_insert(self::TABLE_ATTENDANCE, $data);
    }

    public function save_leave(array $data)
    {
        return $this->stamp_and_insert(self::TABLE_LEAVES, $data);
    }

    public function save_payroll(array $data)
    {
        return $this->stamp_and_insert(self::TABLE_PAYROLL, $data);
    }

    public function save_salary_structure(array $data)
    {
        return $this->stamp_and_insert(self::TABLE_STRUCTURES, $data);
    }

    public function save_performance(array $data)
    {
        return $this->stamp_and_insert(self::TABLE_PERFORMANCE, $data);
    }

    // ------------------------------------------------------------------
    // Report helpers
    // ------------------------------------------------------------------

    public function get_employee_dropdown(): array
    {
        $this->db->select('id, employee_code, full_name');
        $this->db->from(self::TABLE_EMPLOYEES);
        $this->db->order_by('full_name', 'ASC');
        return $this->db->get()->result();
    }

    public function count_employees(string $status = null): int
    {
        if ($status) {
            $this->db->where('status', $status);
        }

        return (int) $this->db->count_all_results(self::TABLE_EMPLOYEES);
    }

    public function count_pending_leaves(): int
    {
        $this->db->where('status', 'Pending');
        return (int) $this->db->count_all_results(self::TABLE_LEAVES);
    }

    public function attendance_today(string $date): int
    {
        $this->db->where('attendance_date', $date);
        return (int) $this->db->count_all_results(self::TABLE_ATTENDANCE);
    }

    public function total_payroll_amount(string $month = null): float
    {
        if ($month) {
            $this->db->like('payroll_month', $month);
        }

        $this->db->select_sum('net_pay', 'total_net');
        $row = $this->db->get(self::TABLE_PAYROLL)->row();

        return (float) ($row->total_net ?? 0);
    }

    public function get_attendance_report(array $filters = [])
    {
        $this->db->from(self::TABLE_ATTENDANCE . ' a');
        $this->db->select('a.*, e.full_name');
        $this->db->join(self::TABLE_EMPLOYEES . ' e', 'e.id = a.employee_id', 'left');

        if (!empty($filters['from_date'])) {
            $this->db->where('a.attendance_date >=', $filters['from_date']);
        }

        if (!empty($filters['to_date'])) {
            $this->db->where('a.attendance_date <=', $filters['to_date']);
        }

        return $this->db->get()->result();
    }

    public function get_leave_report(array $filters = [])
    {
        $this->db->from(self::TABLE_LEAVES . ' l');
        $this->db->select('l.*, e.full_name');
        $this->db->join(self::TABLE_EMPLOYEES . ' e', 'e.id = l.employee_id', 'left');

        if (!empty($filters['from_date'])) {
            $this->db->where('l.from_date >=', $filters['from_date']);
        }
        if (!empty($filters['to_date'])) {
            $this->db->where('l.to_date <=', $filters['to_date']);
        }

        return $this->db->get()->result();
    }

    public function get_payroll_report()
    {
        return $this->db->get(self::TABLE_PAYROLL)->result();
    }

    public function get_salary_register()
    {
        return $this->db->get(self::TABLE_PAYROLL)->result();
    }
}
