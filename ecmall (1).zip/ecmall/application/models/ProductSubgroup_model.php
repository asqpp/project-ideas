<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductSubgroup_model extends MY_Model
{
    protected $table = 'product_subgroups';
    protected $primary_key = 'id';
    protected $timestamps = false;

    public function get_paginated(int $per_page = 25, int $page = 1, string $search = ''): object
    {
        $offset = ($page - 1) * $per_page;

        $this->db->select('sg.*, g.group_name');
        $this->db->from($this->table . ' sg');
        $this->db->join('product_groups g', 'g.id = sg.group_id', 'left');

        if ($search !== '') {
            $this->db->group_start()
                ->like('sg.subgroup_name', $search)
                ->or_like('sg.subgroup_code', $search)
                ->group_end();
        }

        $total = $this->db->count_all_results('', false);
        $this->db->order_by('sg.subgroup_name', 'ASC');
        $this->db->limit($per_page, $offset);
        $data = $this->db->get()->result();

        return (object) [
            'data' => $data,
            'total' => $total,
            'per_page' => $per_page,
            'current_page' => $page,
            'total_pages' => max(1, (int) ceil($total / $per_page))
        ];
    }

    public function get_for_dropdown(): array
    {
        return $this->db
            ->order_by('subgroup_name', 'ASC')
            ->get($this->table)
            ->result();
    }

    public function get_by_group(int $group_id): array
    {
        return $this->db
            ->where('group_id', $group_id)
            ->order_by('subgroup_name', 'ASC')
            ->get($this->table)
            ->result();
    }

    public function find_by_code(string $code)
    {
        return $this->db->where('subgroup_code', $code)->get($this->table)->row();
    }

    public function code_exists(string $code, ?int $ignore_id = null): bool
    {
        $this->db->where('subgroup_code', $code);
        if ($ignore_id) {
            $this->db->where($this->primary_key . ' !=', $ignore_id);
        }
        return $this->db->count_all_results($this->table) > 0;
    }
}
