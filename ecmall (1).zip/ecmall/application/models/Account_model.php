<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Account_model extends MY_Model {

    protected $table = 'accountm';
    protected $primary_key = 'accode';
    protected $timestamps = false;

    private $type_map = [
        'asset' => 'A',
        'liability' => 'L',
        'equity' => 'L',
        'income' => 'R',
        'expense' => 'E'
    ];

    private $reverse_type_map = [
        'A' => 'asset',
        'L' => 'liability',
        'E' => 'expense',
        'R' => 'income'
    ];

    public function get_paginated($per_page = 25, $page = 1, $search = '', $account_type = null) {
        $offset = ($page - 1) * $per_page;

        $this->db->select('accode, name, actype1, reserve, note, tplpos, shepos, shedgrp');
        $this->db->from($this->table);

        if (!empty($search)) {
            $this->db->group_start();
            $this->db->like('name', $search);
            $this->db->or_like('accode', $search);
            $this->db->group_end();
        }

        if ($account_type) {
            $this->db->where('actype1', $this->map_account_type_to_actype1($account_type));
        }

        $total = $this->db->count_all_results('', false);

        $this->db->limit($per_page, $offset);
        $this->db->order_by('accode', 'ASC');
        $rows = $this->db->get()->result();

        $rows = array_map(function ($row) {
            return $this->transform_row($row);
        }, $rows);

        return (object) [
            'data' => $rows,
            'total' => $total,
            'per_page' => $per_page,
            'current_page' => $page,
            'total_pages' => ceil($total / $per_page)
        ];
    }

    public function get_by_code($account_code) {
        $row = $this->db->where('accode', $account_code)->get($this->table)->row();
        return $row ? $this->transform_row($row) : null;
    }

    public function get_by_id($id) {
        return $this->get_by_code($id);
    }

    public function get_for_dropdown($account_type = null) {
        $this->db->select('accode, name, actype1');
        $this->db->from($this->table);

        if ($account_type) {
            $this->db->where('actype1', $this->map_account_type_to_actype1($account_type));
        }

        $this->db->order_by('accode', 'ASC');
        $rows = $this->db->get()->result();

        return array_map(function ($row) {
            return (object) [
                'account_id' => $row->accode,
                'account_code' => $row->accode,
                'account_name' => $row->name,
                'account_type' => $this->reverse_type_map[$row->actype1] ?? 'asset'
            ];
        }, $rows);
    }

    public function get_ledger($account_code, $from_date = null, $to_date = null) {
        $this->db->select('*');
        $this->db->from('daybook');
        $this->db->where('account_code', $account_code);

        if ($from_date) {
            $this->db->where('date >=', $from_date);
        }

        if ($to_date) {
            $this->db->where('date <=', $to_date);
        }

        $this->db->order_by('date', 'ASC');
        $this->db->order_by('id', 'ASC');

        $entries = $this->db->get()->result();

        $running_balance = 0;
        foreach ($entries as $entry) {
            $running_balance += ($entry->debit - $entry->credit);
            $entry->running_balance = $running_balance;
        }

        return $entries;
    }

    public function get_balance($account_code, $as_of_date = null) {
        $this->db->select_sum('debit');
        $this->db->select_sum('credit');
        $this->db->from('daybook');
        $this->db->where('account_code', $account_code);

        if ($as_of_date) {
            $this->db->where('date <=', $as_of_date);
        }

        $result = $this->db->get()->row();

        $debit_total = $result->debit ?? 0;
        $credit_total = $result->credit ?? 0;

        return $debit_total - $credit_total;
    }

    public function get_trial_balance($as_of_date = null) {
        $this->db->select('a.accode as account_code, a.name as account_name, a.actype1,
            COALESCE(SUM(d.debit), 0) as total_debit,
            COALESCE(SUM(d.credit), 0) as total_credit
        ');
        $this->db->from($this->table . ' a');
        $this->db->join('daybook d', 'a.accode = d.account_code', 'left');

        if ($as_of_date) {
            $this->db->where('d.date <=', $as_of_date);
        }

        $this->db->group_by('a.accode');
        $this->db->order_by('a.accode', 'ASC');

        $accounts = $this->db->get()->result();

        foreach ($accounts as $account) {
            $account->account_type = $this->reverse_type_map[$account->actype1] ?? 'asset';
            $account->balance = $account->total_debit - $account->total_credit;

            if ($account->balance >= 0) {
                $account->debit_balance = $account->balance;
                $account->credit_balance = 0;
            } else {
                $account->debit_balance = 0;
                $account->credit_balance = abs($account->balance);
            }
        }

        return $accounts;
    }

    public function get_account_types() {
        return [
            'asset' => 'Asset',
            'liability' => 'Liability',
            'equity' => 'Equity',
            'income' => 'Income',
            'expense' => 'Expense'
        ];
    }

    public function code_exists($account_code, $exclude_id = null) {
        $this->db->where('accode', $account_code);
        if ($exclude_id) {
            $this->db->where('accode !=', $exclude_id);
        }
        return $this->db->count_all_results($this->table) > 0;
    }

    public function insert($data) {
        $payload = [
            'accode' => strtoupper($data['account_code']),
            'name' => strtoupper($data['account_name']),
            'actype1' => $this->map_account_type_to_actype1($data['account_type'] ?? 'asset'),
            'reserve' => !empty($data['is_system']) ? 'Y' : 'N',
            'note' => $data['description'] ?? null
        ];

        $this->db->insert($this->table, $payload);
        return $payload['accode'];
    }

    public function update($id, $data) {
        $payload = [
            'name' => strtoupper($data['account_name'] ?? $data['name'] ?? ''),
            'actype1' => isset($data['account_type']) ? $this->map_account_type_to_actype1($data['account_type']) : ($data['actype1'] ?? 'A'),
            'reserve' => !empty($data['is_system']) ? 'Y' : 'N',
            'note' => $data['description'] ?? ($data['note'] ?? null)
        ];

        $this->db->where('accode', $id);
        return $this->db->update($this->table, $payload);
    }

    public function delete($id, $soft_delete = false) {
        $this->db->where('accode', $id);
        return $this->db->delete($this->table);
    }

    public function get_all($filters = [], $limit = null, $offset = 0) {
        $this->db->from($this->table);

        if (!empty($filters['actype1'])) {
            $this->db->where('actype1', $filters['actype1']);
        }

        if ($limit) {
            $this->db->limit($limit, $offset);
        }

        $rows = $this->db->order_by('accode', 'ASC')->get()->result();
        return array_map(function ($row) {
            return $this->transform_row($row);
        }, $rows);
    }

    private function transform_row($row) {
        $obj = clone $row;
        $obj->account_id = $row->accode;
        $obj->account_code = $row->accode;
        $obj->account_name = $row->name;
        $obj->account_type = $this->reverse_type_map[$row->actype1] ?? 'asset';
        $obj->description = $row->note ?? '';
        $obj->is_system = ($row->reserve ?? 'N') === 'Y';
        return $obj;
    }

    private function map_account_type_to_actype1(string $type): string {
        $type = strtolower($type);
        return $this->type_map[$type] ?? 'A';
    }
}
