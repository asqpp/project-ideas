<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Client_model extends CI_Model
{
    private $types = [];

    public function __construct()
    {
        parent::__construct();
        $this->load->model('ClientSettings_model');
        $this->load->model('Account_model');
        $this->types = [
            'customer' => [
                'label' => 'Customers',
                'singular' => 'Customer',
                'table' => 'customer_information',
                'primary_key' => 'customer_id',
                'code_column' => 'customer_code',
                'name_column' => 'customer_name',
                'mobile_column' => 'customer_mobile',
                'email_column' => 'customer_email',
                'address_columns' => [
                    'addr1' => 'customer_address_1',
                    'addr2' => 'customer_address_2',
                    'addr3' => null,
                    'city' => 'city',
                    'state' => 'state',
                    'pin' => 'zip'
                ],
                'default_country_column' => 'country',
                'salesman_column' => 'salesman_code',
                'actype1' => 'A',
                'actype2' => 'C',
                'group' => 'SUNDB',
                'bshead' => 'SUNDB',
                'auto_code' => true,
                'default_debit' => true
            ],
            'supplier' => [
                'label' => 'Suppliers',
                'singular' => 'Supplier',
                'table' => 'supplier_information',
                'primary_key' => 'supplier_id',
                'code_column' => 'supplier_code',
                'name_column' => 'supplier_name',
                'mobile_column' => 'supplier_mobile',
                'email_column' => 'supplier_email',
                'address_columns' => [
                    'addr1' => 'supplier_address_1',
                    'addr2' => 'supplier_address_2',
                    'addr3' => null,
                    'city' => 'city',
                    'state' => 'state',
                    'pin' => 'zip'
                ],
                'default_country_column' => 'country',
                'salesman_column' => 'salesman_code',
                'actype1' => 'L',
                'actype2' => 'S',
                'group' => 'SUNCR',
                'bshead' => 'SUNCR',
                'auto_code' => true,
                'default_debit' => false
            ],
            'staff' => [
                'label' => 'Staff',
                'singular' => 'Staff',
                'table' => 'hr_employees',
                'primary_key' => 'id',
                'code_column' => 'employee_code',
                'name_column' => 'full_name',
                'mobile_column' => 'mobile',
                'email_column' => 'work_email',
                'address_columns' => [],
                'default_country_column' => null,
                'salesman_column' => null,
                'actype1' => 'L',
                'actype2' => 'F',
                'group' => 'SUNCR',
                'bshead' => 'SUNCR',
                'auto_code' => false,
                'default_debit' => false
            ],
            'agent' => [
                'label' => 'Agents',
                'singular' => 'Agent',
                'table' => 'agent',
                'primary_key' => 'agent_id',
                'code_column' => 'agent_code',
                'name_column' => 'agent_name',
                'mobile_column' => 'mobile',
                'email_column' => 'email',
                'address_columns' => [
                    'addr1' => 'address'
                ],
                'default_country_column' => null,
                'salesman_column' => 'salesman_code',
                'actype1' => 'L',
                'actype2' => 'A',
                'group' => 'SUNCR',
                'bshead' => 'SUNCR',
                'auto_code' => false,
                'default_debit' => false
            ],
            'broker' => [
                'label' => 'Brokers',
                'singular' => 'Broker',
                'table' => 'broker',
                'primary_key' => 'broker_id',
                'code_column' => 'broker_code',
                'name_column' => 'broker_name',
                'mobile_column' => 'mobile',
                'email_column' => 'email',
                'address_columns' => [
                    'addr1' => 'address'
                ],
                'default_country_column' => null,
                'salesman_column' => 'salesman_code',
                'actype1' => 'L',
                'actype2' => 'A',
                'group' => 'SUNCR',
                'bshead' => 'SUNCR',
                'auto_code' => false,
                'default_debit' => false
            ],
        ];
    }

    public function get_types(): array
    {
        return $this->types;
    }

    public function get_type(string $slug): array
    {
        $slug = strtolower($slug);
        if (!isset($this->types[$slug])) {
            throw new InvalidArgumentException('Unknown client type: ' . $slug);
        }
        return $this->types[$slug];
    }

    public function list(string $slug, int $per_page, int $page, string $search = '')
    {
        $config = $this->get_type($slug);
        $per_page = max(1, $per_page);
        $page = max(1, $page);
        $offset = ($page - 1) * $per_page;

        $codeColumn = $config['code_column'];
        $nameColumn = $config['name_column'];
        $mobileColumn = $config['mobile_column'];
        $emailColumn = $config['email_column'];

        $this->db->from($config['table'] . ' c');
        $this->db->select('c.*');
        if ($codeColumn) {
            $this->db->select('c.' . $codeColumn . ' as client_code');
        }
        $this->db->select('account.clbal as account_balance');
        $this->db->join('accountm account', 'account.accode = c.' . $codeColumn, 'left');

        if ($search !== '') {
            $this->db->group_start();
            $this->db->like('c.' . $nameColumn, $search);
            if ($codeColumn) {
                $this->db->or_like('c.' . $codeColumn, $search);
            }
            if ($mobileColumn) {
                $this->db->or_like('c.' . $mobileColumn, $search);
            }
            if ($emailColumn) {
                $this->db->or_like('c.' . $emailColumn, $search);
            }
            $this->db->group_end();
        }

        $total = $this->db->count_all_results('', false);
        $this->db->order_by('c.' . $nameColumn, 'ASC');
        $this->db->limit($per_page, $offset);
        $rows = $this->db->get()->result();

        $data = array_map(function ($row) use ($config, $mobileColumn, $emailColumn, $nameColumn, $codeColumn) {
            $code = $codeColumn ? ($row->{$codeColumn} ?? '') : '';
            return (object) [
                'code' => $code,
                'name' => $row->{$nameColumn} ?? '',
                'mobile' => $mobileColumn ? ($row->{$mobileColumn} ?? '') : '',
                'email' => $emailColumn ? ($row->{$emailColumn} ?? '') : '',
                'city' => $row->city ?? '',
                'balance' => $row->account_balance ?? 0,
                'record_id' => $row->{$config['primary_key']} ?? null
            ];
        }, $rows);

        return (object) [
            'data' => $data,
            'total' => $total,
            'per_page' => $per_page,
            'current_page' => $page,
            'total_pages' => max(1, (int) ceil($total / $per_page))
        ];
    }

    public function get_client(string $slug, string $code): array
    {
        $config = $this->get_type($slug);
        $codeColumn = $config['code_column'];

        $row = $this->db
            ->where($codeColumn, $code)
            ->get($config['table'])
            ->row();

        if (!$row) {
            throw new RuntimeException('Client not found.');
        }

        $account = $this->db->where('accode', $code)->get('accountm')->row();
        $advancedRow = $this->db->where('client_code', $code)->get('clients_advanced')->row();
        $photo = $this->db->where('client_code', $code)->get('clientspict')->row();
        $phonebook = $this->db->where('client_code', $code)->get('phonebook')->row();
        $master = $this->db->where('code', $code)->get('clients')->row_array();
        $advanced = $advancedRow ? (json_decode($advancedRow->payload, true) ?: []) : [];
        if (!isset($advanced['flags']) || !is_array($advanced['flags'])) {
            $advanced['flags'] = [];
        }
        if (!isset($advanced['commissions']) || !is_array($advanced['commissions'])) {
            $advanced['commissions'] = [];
        }
        if (!isset($advanced['dates']) || !is_array($advanced['dates'])) {
            $advanced['dates'] = [];
        }
        if (!empty($config['salesman_column'])) {
            $salesmanValue = $row->{$config['salesman_column']} ?? null;
            if ($salesmanValue !== null) {
                $advanced['salesman'] = $salesmanValue;
            }
        }

        $payload = [
            'record_id' => $row->{$config['primary_key']},
            'code' => $row->{$codeColumn},
            'name' => $row->{$config['name_column']},
            'mobile' => $config['mobile_column'] ? ($row->{$config['mobile_column']} ?? '') : '',
            'email' => $config['email_column'] ? ($row->{$config['email_column']} ?? '') : '',
            'phone' => $row->phone ?? '',
            'fax' => $row->fax ?? '',
            'contact_person' => $row->contact ?? ($row->contact_person ?? ''),
            'address' => [
                'addr1' => $this->column_value($row, $config, 'addr1'),
                'addr2' => $this->column_value($row, $config, 'addr2'),
                'addr3' => $this->column_value($row, $config, 'addr3'),
                'city' => $this->column_value($row, $config, 'city'),
                'state' => $this->column_value($row, $config, 'state'),
                'pin' => $this->column_value($row, $config, 'pin'),
                'country' => $config['default_country_column'] ? ($row->{$config['default_country_column']} ?? '') : ''
            ],
            'opening_balance' => $account->opbal ?? 0,
            'secondary_balance' => $account->opbalb ?? 0,
            'balance_type' => ($account && ($account->opbal ?? 0) >= 0) ? 'cr' : 'dr',
            'secondary_balance_type' => ($account && ($account->opbalb ?? 0) >= 0) ? 'cr' : 'dr',
            'removed' => isset($account->removed) && $account->removed === 'Y',
            'blocked' => isset($account->blocked) && $account->blocked === 'Y',
            'advanced' => $advanced,
            'photo' => $photo ? base64_encode($photo->picture) : null,
            'photo_mime' => $photo->mime_type ?? null,
            'account_group' => $account->grcode ?? $config['group'],
            'bshead' => $account->bshead ?? $config['bshead'],
            'notes' => $advanced['notes'] ?? ''
        ];

        $payload = $this->overlay_master_data($payload, $master, (bool) $account, $slug);

        if (!isset($payload['advanced']['link_phonebook'])) {
            $payload['advanced']['link_phonebook'] = (bool) $phonebook;
        }

        return $payload;
    }

    public function save_client(string $slug, array $input, ?array $photo = null): array
    {
        $config = $this->get_type($slug);
        $this->db->trans_start();

        $isEdit = !empty($input['record_id']);
        $recordId = $input['record_id'] ?? null;
        $code = strtoupper(trim($input['code'] ?? ''));

        if (!$isEdit) {
            if ($config['auto_code'] && empty($code)) {
                $generated = $this->ClientSettings_model->consume_code($slug);
                if ($generated) {
                    $code = $generated;
                }
            }
            if ($code === '') {
                throw new RuntimeException('Client code is required.');
            }
            $this->ensure_unique_code($config, $code);
        } else {
            if ($code === '') {
                throw new RuntimeException('Client code is required.');
            }
            $existing = $this->db->where($config['primary_key'], $recordId)->get($config['table'])->row();
            if (!$existing) {
                throw new RuntimeException('Client record not found.');
            }
            if (strcasecmp($existing->{$config['code_column']}, $code) !== 0) {
                $this->ensure_unique_code($config, $code);
            }
        }

        $baseData = $this->build_base_payload($slug, $config, $input, $code);
        $balances = $this->normalize_balances($input, $config);

        if ($isEdit) {
            $this->db->where($config['primary_key'], $recordId)->update($config['table'], $baseData);
        } else {
            $this->db->insert($config['table'], $baseData);
            $recordId = $this->db->insert_id();
        }

        $this->sync_account($slug, $code, $input, $config, $balances);
        $this->persist_advanced($code, $input);
        $this->persist_photo($code, $photo);
        $this->sync_phonebook($code, $input, $config);
        $this->sync_clients_master($slug, $code, $input, $config, $balances);

        $this->db->trans_complete();

        if (!$this->db->trans_status()) {
            throw new RuntimeException('Failed saving client.');
        }

        return ['record_id' => $recordId, 'code' => $code];
    }

    public function delete_client(string $slug, string $code): void
    {
        $config = $this->get_type($slug);
        $codeColumn = $config['code_column'];

        $exists = $this->db->where($codeColumn, $code)->get($config['table'])->row();
        if (!$exists) {
            throw new RuntimeException('Client not found.');
        }

        $hasTransactions = $this->db->where('account_code', $code)->count_all_results('daybook') > 0;
        if ($hasTransactions) {
            throw new RuntimeException('Client has transactions and cannot be deleted.');
        }

        $this->db->trans_start();
        $this->db->where($codeColumn, $code)->delete($config['table']);
        $this->db->where('client_code', $code)->delete('clientspict');
        $this->db->where('client_code', $code)->delete('clients_advanced');
        $this->db->where('client_code', $code)->delete('phonebook');
        $this->db->where('code', $code)->delete('clients');
        $this->db->where('accode', $code)->delete('accountm');
        $this->db->trans_complete();

        if (!$this->db->trans_status()) {
            throw new RuntimeException('Failed to delete client.');
        }
    }

    private function ensure_unique_code(array $config, string $code): void
    {
        $exists = $this->db->where($config['code_column'], $code)->count_all_results($config['table']) > 0;
        if ($exists) {
            throw new RuntimeException('Client code already exists.');
        }
        $accountExists = $this->db->where('accode', $code)->count_all_results('accountm') > 0;
        if ($accountExists) {
            throw new RuntimeException('Account already exists for this code.');
        }
        $clientExists = $this->db->where('code', $code)->count_all_results('clients') > 0;
        if ($clientExists) {
            throw new RuntimeException('Client master already exists for this code.');
        }
    }

    private function build_base_payload(string $slug, array $config, array $input, string $code): array
    {
        switch ($slug) {
            case 'customer':
                return [
                    'customer_code' => $code,
                    'customer_name' => $input['name'] ?? '',
                    'customer_mobile' => $input['mobile'] ?? '',
                    'customer_email' => $input['email'] ?? '',
                    'customer_address_1' => $input['addr1'] ?? '',
                    'customer_address_2' => $input['addr2'] ?? '',
                    'city' => $input['city'] ?? '',
                    'state' => $input['state'] ?? '',
                    'zip' => $input['pin'] ?? '',
                    'country' => $input['country'] ?? '',
                    'phone' => $input['phone'] ?? '',
                    'contact' => $input['contact_person'] ?? '',
                    'fax' => $input['fax'] ?? '',
                    'salesman_code' => $input['salesman'] ?? '',
                    'status' => 1
                ];
            case 'supplier':
                return [
                    'supplier_code' => $code,
                    'supplier_name' => $input['name'] ?? '',
                    'supplier_mobile' => $input['mobile'] ?? '',
                    'supplier_email' => $input['email'] ?? '',
                    'supplier_address_1' => $input['addr1'] ?? '',
                    'supplier_address_2' => $input['addr2'] ?? '',
                    'city' => $input['city'] ?? '',
                    'state' => $input['state'] ?? '',
                    'zip' => $input['pin'] ?? '',
                    'country' => $input['country'] ?? '',
                    'contact' => $input['contact_person'] ?? '',
                    'fax' => $input['fax'] ?? '',
                    'salesman_code' => $input['salesman'] ?? '',
                    'status' => 1
                ];
            case 'staff':
                return [
                    'employee_code' => $code,
                    'full_name' => $input['name'] ?? '',
                    'department' => $input['department'] ?? '',
                    'designation' => $input['designation'] ?? '',
                    'joining_date' => $input['date'] ?? null,
                    'work_email' => $input['email'] ?? '',
                    'mobile' => $input['mobile'] ?? '',
                    'phone' => $input['phone'] ?? '',
                    'status' => $input['status'] ?? 'Active',
                    'notes' => $input['notes'] ?? ''
                ];
            case 'agent':
                return [
                    'agent_code' => $code,
                    'agent_name' => $input['name'] ?? '',
                    'contact_person' => $input['contact_person'] ?? '',
                    'mobile' => $input['mobile'] ?? '',
                    'email' => $input['email'] ?? '',
                    'fax' => $input['fax'] ?? '',
                    'address' => $this->compose_address($input),
                    'commission_rate' => (float) ($input['commission_pct'] ?? 0),
                    'salesman_code' => $input['salesman'] ?? '',
                    'status' => 1
                ];
            case 'broker':
                return [
                    'broker_code' => $code,
                    'broker_name' => $input['name'] ?? '',
                    'contact_person' => $input['contact_person'] ?? '',
                    'mobile' => $input['mobile'] ?? '',
                    'email' => $input['email'] ?? '',
                    'fax' => $input['fax'] ?? '',
                    'address' => $this->compose_address($input),
                    'commission_rate' => (float) ($input['commission_pct'] ?? 0),
                    'salesman_code' => $input['salesman'] ?? '',
                    'status' => 1
                ];
            default:
                return [];
        }
    }

    private function compose_address(array $input): string
    {
        $parts = array_filter([
            $input['addr1'] ?? '',
            $input['addr2'] ?? '',
            $input['addr3'] ?? '',
            $input['city'] ?? '',
            $input['state'] ?? '',
            $input['pin'] ?? ''
        ]);
        return implode(', ', $parts);
    }

    private function sync_account(string $slug, string $code, array $input, array $config, ?array $balances = null): void
    {
        $actype1 = $config['actype1'];
        $actype2 = $config['actype2'];
        $name = $input['name'] ?? $code;
        $group = $input['account_group'] ?? $config['group'];
        $bsHead = $input['bshead'] ?? $config['bshead'];

        $balances = $balances ?? $this->normalize_balances($input, $config);
        $opening = $balances['opening'];
        $secondary = $balances['secondary'];

        $payload = [
            'name' => strtoupper($name),
            'actype1' => $actype1,
            'actype2' => $actype2,
            'grcode' => $group,
            'bshead' => $bsHead,
            'opbal' => $opening,
            'opbalb' => $secondary,
            'amount' => $opening,
            'amount2' => $secondary,
            'tplpos' => $input['tplpos'] ?? 0,
            'shepos' => $input['shepos'] ?? 0,
            'shedgrp' => $input['shedgrp'] ?? null,
            'removed' => !empty($input['removed']) ? 'Y' : 'N',
            'blocked' => !empty($input['blocked']) ? 'Y' : 'N',
            'note' => $input['notes'] ?? null
        ];

        $exists = $this->db->where('accode', $code)->get('accountm')->row();
        if ($exists) {
            $this->db->where('accode', $code)->update('accountm', $payload);
        } else {
            $payload['accode'] = $code;
            $this->db->insert('accountm', $payload);
        }
    }

    private function sync_clients_master(string $slug, string $code, array $input, array $config, array $balances): void
    {
        $crValue = $input['cr_no'] ?? null;
        $homeMobile = null;
        if ($slug === 'staff') {
            $homeMobile = $crValue;
            $crValue = null;
        }

        $data = [
            'code' => $code,
            'name' => $input['name'] ?? $code,
            'ctype' => strtoupper($config['actype2'] ?? substr($slug, 0, 1)),
            'grp' => $input['group_code'] ?? null,
            'account_group' => $input['account_group'] ?? $config['group'],
            'bshead' => $input['bshead'] ?? $config['bshead'],
            'addr1' => $input['addr1'] ?? null,
            'addr2' => $input['addr2'] ?? null,
            'addr3' => $input['addr3'] ?? null,
            'city' => $input['city'] ?? null,
            'state' => $input['state'] ?? null,
            'pin' => $input['pin'] ?? null,
            'country' => $input['country'] ?? null,
            'route' => $input['route'] ?? null,
            'carea' => $input['area'] ?? null,
            'distance' => $this->numeric_or_null($input['distance'] ?? null),
            'telephone' => $input['phone'] ?? null,
            'mobile' => $input['mobile'] ?? null,
            'homemobile' => $homeMobile ?? ($input['homemobile'] ?? null),
            'email' => $input['email'] ?? null,
            'fax' => $input['fax'] ?? null,
            'tin' => $input['vat_no'] ?? null,
            'cst' => $crValue,
            'panadhar' => $input['pan'] ?? null,
            'notes' => $input['notes'] ?? null,
            'smcode' => $input['salesman'] ?? null,
            'cocode' => $input['care_of_code'] ?? null,
            'contact_person' => $input['contact_person'] ?? null,
            'care_of_party' => !empty($input['care_of_party']) ? 'Y' : 'N',
            'pcard' => $input['card_type'] ?? null,
            'pcardno' => $input['card_number'] ?? null,
            'oppcardpoints' => $this->numeric_or_null($input['card_points'] ?? null),
            'salary' => $this->numeric_or_null($input['salary'] ?? null),
            'cutrate' => $this->numeric_or_null($input['cut_rate'] ?? null),
            'commission_pct' => $this->numeric_or_null($input['commission_pct'] ?? null),
            'colncomn' => $this->numeric_or_null($input['commission_pct'] ?? null),
            'staff_commission' => $this->numeric_or_null($input['staff_commission'] ?? null),
            'id_number' => $input['id_number'] ?? null,
            'pospwd' => $input['pos_password'] ?? null,
            'approval' => $input['approval_authority'] ?? null,
            'agent' => $this->determine_agent_flag($slug, $input),
            'agentcode' => $input['agent_code'] ?? (in_array($slug, ['agent', 'broker'], true) ? $code : null),
            'contract_date' => $input['contract_date'] ?? null,
            'adate' => $input['date'] ?? null,
            'duedate' => $input['due_date'] ?? null,
            'opbalance' => $balances['opening'],
            'opbalanceb' => $balances['secondary'],
            'balance_type' => $balances['primary_type'],
            'secondary_balance_type' => $balances['secondary_type'],
            'control' => 1,
            'removed' => !empty($input['removed']) ? 'Y' : 'N',
            'blocked' => !empty($input['blocked']) ? 'Y' : 'N',
            'display' => !empty($input['display']) ? 'Y' : 'N',
            'link_phonebook' => !empty($input['link_phonebook']) ? 'Y' : 'N',
            'print_card' => !empty($input['print_card']) ? 'Y' : 'N',
            'show_camera' => !empty($input['show_camera']) ? 'Y' : 'N',
            'update_foreign' => !empty($input['update_foreign']) ? 'Y' : 'N',
            'agent_staff' => !empty($input['staff_agent']) ? 'Y' : 'N'
        ];

        $this->db->replace('clients', $data);
    }

    private function persist_advanced(string $code, array $input): void
    {
        $advanced = [
            'care_of_code' => $input['care_of_code'] ?? null,
            'card_type' => $input['card_type'] ?? null,
            'card_number' => $input['card_number'] ?? null,
            'card_points' => $input['card_points'] ?? null,
            'route' => $input['route'] ?? null,
            'area' => $input['area'] ?? null,
            'salesman' => $input['salesman'] ?? null,
            'vat_no' => $input['vat_no'] ?? null,
            'gstin' => $input['vat_no'] ?? null,
            'cr_no' => $input['cr_no'] ?? null,
            'cst' => $input['cr_no'] ?? null,
            'pan' => $input['pan'] ?? null,
            'aadhar' => $input['aadhar'] ?? null,
            'fax' => $input['fax'] ?? null,
            'contact_person' => $input['contact_person'] ?? null,
            'religion' => $input['religion'] ?? null,
            'distance' => $input['distance'] ?? null,
            'commissions' => [
                'percentage' => $input['commission_pct'] ?? null,
                'cut_rate' => $input['cut_rate'] ?? null,
                'staff_commission' => $input['staff_commission'] ?? null
            ],
            'flags' => [
                'display' => !empty($input['display']),
                'care_of_party' => !empty($input['care_of_party']),
                'agent_staff' => !empty($input['staff_agent']),
                'print_card' => !empty($input['print_card']),
                'show_camera' => !empty($input['show_camera']),
                'update_foreign' => !empty($input['update_foreign'])
            ],
            'dates' => [
                'reference_date' => $input['date'] ?? null,
                'due_date' => $input['due_date'] ?? null,
                'contract_date' => $input['contract_date'] ?? null
            ],
            'salary' => $input['salary'] ?? null,
            'id_number' => $input['id_number'] ?? null,
            'pos_password' => $input['pos_password'] ?? null,
            'approval' => $input['approval_authority'] ?? null,
            'care_of_name' => $input['care_of_name'] ?? null,
            'notes' => $input['notes'] ?? null,
            'link_phonebook' => !empty($input['link_phonebook']),
            'account_group' => $input['account_group'] ?? null,
            'bshead' => $input['bshead'] ?? null
        ];

        $payload = [
            'client_code' => $code,
            'payload' => json_encode($advanced)
        ];

        $this->db->replace('clients_advanced', $payload);
    }

    private function persist_photo(string $code, ?array $photo): void
    {
        if (!$photo || empty($photo['tmp_name'])) {
            return;
        }

        $content = file_get_contents($photo['tmp_name']);
        if ($content === false) {
            return;
        }

        $data = [
            'client_code' => $code,
            'mime_type' => $photo['type'] ?? 'image/jpeg',
            'picture' => $content
        ];

        $this->db->replace('clientspict', $data);
    }

    private function sync_phonebook(string $code, array $input, array $config): void
    {
        if (empty($input['link_phonebook'])) {
            $this->db->where('client_code', $code)->delete('phonebook');
            return;
        }

        $data = [
            'client_code' => $code,
            'name' => $input['name'] ?? $code,
            'resaddress' => $this->compose_address($input),
            'mobile' => $input['mobile'] ?? '',
            'email' => $input['email'] ?? '',
            'ptype' => $config['singular'],
            'grp' => $input['phonebook_group'] ?? ''
        ];

        $this->db->replace('phonebook', $data);
    }

    private function overlay_master_data(array $payload, ?array $master, bool $accountExists, string $slug): array
    {
        if (!$master) {
            return $payload;
        }

        $payload['phone'] = $master['telephone'] ?? $payload['phone'];
        $payload['mobile'] = $master['mobile'] ?? $payload['mobile'];
        $payload['email'] = $master['email'] ?? $payload['email'];
        $payload['fax'] = $master['fax'] ?? $payload['fax'];
        $payload['contact_person'] = $master['contact_person'] ?? $payload['contact_person'];

        $addressFields = ['addr1', 'addr2', 'addr3', 'city', 'state', 'pin', 'country'];
        foreach ($addressFields as $field) {
            if (!empty($master[$field])) {
                $payload['address'][$field] = $master[$field];
            }
        }

        if (!$accountExists) {
            if (isset($master['opbalance'])) {
                $payload['opening_balance'] = (float) $master['opbalance'];
            }
            if (isset($master['opbalanceb'])) {
                $payload['secondary_balance'] = (float) $master['opbalanceb'];
            }
            if (!empty($master['balance_type'])) {
                $payload['balance_type'] = strtolower($master['balance_type']);
            }
            if (!empty($master['secondary_balance_type'])) {
                $payload['secondary_balance_type'] = strtolower($master['secondary_balance_type']);
            }
        }

        if (!empty($master['account_group'])) {
            $payload['account_group'] = $master['account_group'];
        }
        if (!empty($master['bshead'])) {
            $payload['bshead'] = $master['bshead'];
        }

        $payload['notes'] = $master['notes'] ?? $payload['notes'];
        $payload['removed'] = $payload['removed'] || (($master['removed'] ?? 'N') === 'Y');
        $payload['blocked'] = $payload['blocked'] || (($master['blocked'] ?? 'N') === 'Y');

        $advanced = $payload['advanced'];
        $advanced['route'] = $master['route'] ?? ($advanced['route'] ?? '');
        $advanced['area'] = $master['carea'] ?? ($advanced['area'] ?? '');
        $advanced['salesman'] = $master['smcode'] ?? ($advanced['salesman'] ?? '');
        $advanced['vat_no'] = $master['tin'] ?? ($advanced['vat_no'] ?? ($advanced['gstin'] ?? ''));
        $advanced['gstin'] = $advanced['vat_no'];
        if ($slug === 'staff') {
            $advanced['cr_no'] = $master['homemobile'] ?? ($advanced['cr_no'] ?? ($advanced['cst'] ?? ''));
        } else {
            $advanced['cr_no'] = $master['cst'] ?? ($advanced['cr_no'] ?? ($advanced['cst'] ?? ''));
        }
        $advanced['cst'] = $advanced['cr_no'];
        $advanced['pan'] = $master['panadhar'] ?? ($advanced['pan'] ?? '');
        $advanced['fax'] = $master['fax'] ?? ($advanced['fax'] ?? '');
        $advanced['distance'] = isset($master['distance']) ? (string) $master['distance'] : ($advanced['distance'] ?? '');
        $advanced['care_of_code'] = $master['cocode'] ?? ($advanced['care_of_code'] ?? '');
        $advanced['card_type'] = $master['pcard'] ?? ($advanced['card_type'] ?? '');
        $advanced['card_number'] = $master['pcardno'] ?? ($advanced['card_number'] ?? '');
        if (isset($master['oppcardpoints'])) {
            $advanced['card_points'] = $master['oppcardpoints'];
        }
        $advanced['salary'] = $master['salary'] ?? ($advanced['salary'] ?? null);
        $advanced['id_number'] = $master['id_number'] ?? ($advanced['id_number'] ?? null);
        $advanced['pos_password'] = $master['pospwd'] ?? ($advanced['pos_password'] ?? null);
        $advanced['approval'] = $master['approval'] ?? ($advanced['approval'] ?? null);
        $advanced['notes'] = $master['notes'] ?? ($advanced['notes'] ?? null);
        if (!empty($master['account_group'])) {
            $advanced['account_group'] = $master['account_group'];
        }
        if (!empty($master['bshead'])) {
            $advanced['bshead'] = $master['bshead'];
        }
        $advanced['contact_person'] = $payload['contact_person'] ?? ($advanced['contact_person'] ?? null);

        $commissions = $advanced['commissions'];
        if (isset($master['commission_pct']) || isset($master['colncomn'])) {
            $commissions['percentage'] = $master['commission_pct'] ?? $master['colncomn'];
        } elseif (!isset($commissions['percentage'])) {
            $commissions['percentage'] = null;
        }
        if (isset($master['cutrate'])) {
            $commissions['cut_rate'] = $master['cutrate'];
        } elseif (!isset($commissions['cut_rate'])) {
            $commissions['cut_rate'] = null;
        }
        if (isset($master['staff_commission'])) {
            $commissions['staff_commission'] = $master['staff_commission'];
        } elseif (!isset($commissions['staff_commission'])) {
            $commissions['staff_commission'] = null;
        }
        $advanced['commissions'] = $commissions;

        $dates = $advanced['dates'];
        if (isset($master['adate'])) {
            $dates['reference_date'] = $master['adate'];
        } elseif (!isset($dates['reference_date'])) {
            $dates['reference_date'] = null;
        }
        if (isset($master['duedate'])) {
            $dates['due_date'] = $master['duedate'];
        } elseif (!isset($dates['due_date'])) {
            $dates['due_date'] = null;
        }
        if (isset($master['contract_date'])) {
            $dates['contract_date'] = $master['contract_date'];
        } elseif (!isset($dates['contract_date'])) {
            $dates['contract_date'] = null;
        }
        $advanced['dates'] = $dates;

        $flags = $advanced['flags'];
        $flags['display'] = isset($master['display']) ? ($master['display'] === 'Y') : ($flags['display'] ?? false);
        $flags['care_of_party'] = isset($master['care_of_party']) ? ($master['care_of_party'] === 'Y') : ($flags['care_of_party'] ?? false);
        $flags['agent_staff'] = isset($master['agent_staff']) ? ($master['agent_staff'] === 'Y') : ($flags['agent_staff'] ?? false);
        $flags['print_card'] = isset($master['print_card']) ? ($master['print_card'] === 'Y') : ($flags['print_card'] ?? false);
        $flags['show_camera'] = isset($master['show_camera']) ? ($master['show_camera'] === 'Y') : ($flags['show_camera'] ?? false);
        $flags['update_foreign'] = isset($master['update_foreign']) ? ($master['update_foreign'] === 'Y') : ($flags['update_foreign'] ?? false);
        $advanced['flags'] = $flags;

        if (isset($master['link_phonebook'])) {
            $advanced['link_phonebook'] = ($master['link_phonebook'] === 'Y');
        }

        $payload['advanced'] = $advanced;

        return $payload;
    }

    private function normalize_balances(array $input, array $config): array
    {
        $defaultPrimary = $config['default_debit'] ? 'dr' : 'cr';
        $primaryType = strtolower($input['balance_type'] ?? $defaultPrimary);
        if (!in_array($primaryType, ['dr', 'cr'], true)) {
            $primaryType = $defaultPrimary;
        }

        $secondaryType = strtolower($input['secondary_balance_type'] ?? 'cr');
        if (!in_array($secondaryType, ['dr', 'cr'], true)) {
            $secondaryType = 'cr';
        }

        $opening = (float) ($input['opening_balance'] ?? 0);
        $secondary = (float) ($input['secondary_balance'] ?? 0);
        $opening = $primaryType === 'dr' ? -abs($opening) : abs($opening);
        $secondary = $secondaryType === 'dr' ? -abs($secondary) : abs($secondary);

        return [
            'opening' => $opening,
            'secondary' => $secondary,
            'primary_type' => $primaryType,
            'secondary_type' => $secondaryType
        ];
    }

    private function numeric_or_null($value): ?float
    {
        if ($value === '' || $value === null) {
            return null;
        }
        return (float) $value;
    }

    private function determine_agent_flag(string $slug, array $input): string
    {
        if (in_array($slug, ['agent', 'broker'], true)) {
            return 'Y';
        }
        return !empty($input['staff_agent']) ? 'Y' : 'N';
    }

    private function column_value($row, array $config, string $index)
    {
        if (!isset($config['address_columns'][$index])) {
            return '';
        }
        $column = $config['address_columns'][$index];
        if (!$column) {
            return '';
        }
        return $row->{$column} ?? '';
    }
}
