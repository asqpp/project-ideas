<?php
$page_title = $page_title ?? 'Form';
$page_description = $page_description ?? '';
$form_title = $form_title ?? $page_title;
$form_subtitle = $form_subtitle ?? '';
$form_badge = $form_badge ?? '';
$form_fields = $form_fields ?? [];
$form_layout = $form_layout ?? 'grid-cols-1 md:grid-cols-2';
$form_actions = $form_actions ?? [
    ['label' => 'Save', 'variant' => 'primary'],
    ['label' => 'Reset', 'variant' => 'outline']
];
$meta_cards = $meta_cards ?? [];
$checklist = $checklist ?? [];
$activity_timeline = $activity_timeline ?? [];
$supporting_sections = $supporting_sections ?? [];
$form_action = $form_action ?? current_url();
$form_method = $form_method ?? 'post';

if (!function_exists('render_dynamic_field')) {
    /**
     * Helper to render different input types.
     */
    function render_dynamic_field($field) {
        $type = $field['type'] ?? 'text';
        $name = $field['name'] ?? strtolower(preg_replace('/\s+/', '_', $field['label'] ?? 'field'));
        $id = $field['id'] ?? $name . '_' . uniqid();
        $placeholder = $field['placeholder'] ?? '';
        $value = $field['value'] ?? '';
        $options = $field['options'] ?? [];

        switch ($type) {
            case 'select':
                echo '<select id="' . htmlspecialchars($id) . '" name="' . htmlspecialchars($name) . '" class="form-select">';
                echo '<option value="">' . htmlspecialchars($field['placeholder'] ?? 'Choose option') . '</option>';
                foreach ($options as $option) {
                    $optionValue = is_array($option) ? ($option['value'] ?? '') : $option;
                    $optionLabel = is_array($option) ? ($option['label'] ?? $optionValue) : $option;
                    $selected = $value === $optionValue ? ' selected' : '';
                    echo '<option value="' . htmlspecialchars($optionValue) . '"' . $selected . '>' . htmlspecialchars($optionLabel) . '</option>';
                }
                echo '</select>';
                break;
            case 'textarea':
                echo '<textarea id="' . htmlspecialchars($id) . '" name="' . htmlspecialchars($name) . '" class="form-input min-h-[120px]" placeholder="' . htmlspecialchars($placeholder) . '">' . htmlspecialchars($value) . '</textarea>';
                break;
            case 'date':
            case 'number':
            case 'email':
                echo '<input type="' . htmlspecialchars($type) . '" id="' . htmlspecialchars($id) . '" name="' . htmlspecialchars($name) . '" class="form-input" placeholder="' . htmlspecialchars($placeholder) . '" value="' . htmlspecialchars($value) . '">';
                break;
            case 'currency':
                echo '<div class="relative">';
                echo '<span class="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">' . htmlspecialchars($field['currency_symbol'] ?? 'AED') . '</span>';
                echo '<input type="number" step="0.01" id="' . htmlspecialchars($id) . '" name="' . htmlspecialchars($name) . '" class="form-input pl-12" placeholder="' . htmlspecialchars($placeholder) . '" value="' . htmlspecialchars($value) . '">';
                echo '</div>';
                break;
            case 'chips':
                echo '<div class="flex flex-wrap gap-2">';
                foreach ($options as $option) {
                    echo '<span class="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-medium">' . htmlspecialchars($option) . '</span>';
                }
                echo '</div>';
                break;
            default:
                echo '<input type="text" id="' . htmlspecialchars($id) . '" name="' . htmlspecialchars($name) . '" class="form-input" placeholder="' . htmlspecialchars($placeholder) . '" value="' . htmlspecialchars($value) . '">';
        }
    }
}
?>

<!-- Page Header -->
<div class="page-header mb-8">
    <div>
        <p class="text-sm uppercase tracking-wide text-primary-600 font-semibold mb-1">Insurance ERP</p>
        <h1 class="page-title"><?php echo htmlspecialchars($page_title); ?></h1>
        <?php if (!empty($page_description)): ?>
            <p class="text-gray-600 mt-1 max-w-3xl"><?php echo htmlspecialchars($page_description); ?></p>
        <?php endif; ?>
    </div>
    <div class="flex items-center gap-3">
        <button class="btn btn-outline">
            <i class="fas fa-bell"></i>
            Enable Notifications
        </button>
        <button class="btn btn-primary">
            <i class="fas fa-save"></i>
            Quick Save
        </button>
    </div>
</div>

<!-- Form + Insights -->
<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
    <div class="xl:col-span-2">
        <div class="card" data-aos="fade-up">
            <div class="card-header flex items-center justify-between">
                <div>
                    <h3 class="card-title"><?php echo htmlspecialchars($form_title); ?></h3>
                    <?php if (!empty($form_subtitle)): ?>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($form_subtitle); ?></p>
                    <?php endif; ?>
                </div>
                <?php if (!empty($form_badge)): ?>
                    <span class="px-3 py-1 rounded-full text-xs font-semibold bg-primary-50 text-primary-700">
                        <?php echo htmlspecialchars($form_badge); ?>
                    </span>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <form class="space-y-6" method="<?php echo htmlspecialchars($form_method); ?>" action="<?php echo htmlspecialchars($form_action); ?>">
                    <?php if (function_exists('validation_errors') && validation_errors()): ?>
                        <div class="alert alert-danger mb-4">
                            <i class="fas fa-exclamation-circle"></i>
                            <div>
                                <strong>Please fix the highlighted fields</strong>
                                <div class="text-sm"><?php echo validation_errors('', ''); ?></div>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="grid <?php echo htmlspecialchars($form_layout); ?> gap-4">
                        <?php foreach ($form_fields as $field): ?>
                            <?php
                            $name = $field['name'] ?? '';
                            $field_id = $field['id'] ?? ($name ?: ('field_' . uniqid()));
                            $field['id'] = $field_id;
                            if (!empty($name)) {
                                $field['value'] = set_value($name, $field['value'] ?? '');
                            }
                            $field_error = $name ? form_error($name) : '';
                            ?>
                            <div class="<?php echo htmlspecialchars($field['col_span'] ?? 'col-span-1'); ?>">
                                <label class="form-label" for="<?php echo htmlspecialchars($field_id); ?>">
                                    <?php echo htmlspecialchars($field['label'] ?? 'Field'); ?>
                                </label>
                                <?php render_dynamic_field($field); ?>
                                <?php if (!empty($field['helper'])): ?>
                                    <p class="text-xs text-gray-500 mt-1"><?php echo htmlspecialchars($field['helper']); ?></p>
                                <?php endif; ?>
                                <?php if (!empty($field_error)): ?>
                                    <p class="text-xs text-danger-600 mt-1"><?php echo strip_tags($field_error); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <div class="flex flex-wrap gap-3">
                        <?php foreach ($form_actions as $action): ?>
                            <?php
                            $variant = $action['variant'] ?? 'primary';
                            $baseClass = $variant === 'primary'
                                ? 'btn btn-primary'
                                : ($variant === 'danger' ? 'btn btn-danger' : 'btn btn-outline');
                            ?>
                            <button type="button" class="<?php echo $baseClass; ?>">
                                <?php if (!empty($action['icon'])): ?>
                                    <i class="<?php echo htmlspecialchars($action['icon']); ?>"></i>
                                <?php endif; ?>
                                <?php echo htmlspecialchars($action['label'] ?? 'Action'); ?>
                            </button>
                        <?php endforeach; ?>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Insights Column -->
    <div class="space-y-6">
        <?php foreach ($meta_cards as $card): ?>
            <div class="card border border-gray-100 shadow-sm" data-aos="fade-left">
                <div class="card-body flex items-center justify-between">
                    <div>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($card['label'] ?? 'Metric'); ?></p>
                        <p class="text-2xl font-semibold text-gray-900 mt-1"><?php echo htmlspecialchars($card['value'] ?? '--'); ?></p>
                        <?php if (!empty($card['trend'])): ?>
                            <p class="text-xs text-<?php echo !empty($card['trend_positive']) ? 'green' : 'gray'; ?>-600 mt-1">
                                <i class="fas fa-arrow-<?php echo !empty($card['trend_positive']) ? 'up' : 'right'; ?>"></i>
                                <?php echo htmlspecialchars($card['trend']); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <?php if (!empty($card['icon'])): ?>
                        <span class="w-12 h-12 rounded-full bg-primary-50 text-primary-600 flex items-center justify-center text-xl">
                            <i class="<?php echo htmlspecialchars($card['icon']); ?>"></i>
                        </span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <?php if (!empty($checklist)): ?>
            <div class="card" data-aos="fade-left" data-aos-delay="100">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        <i class="fas fa-tasks text-primary-500"></i>
                        Validation Checklist
                    </h3>
                </div>
                <div class="card-body">
                    <ul class="space-y-3">
                        <?php foreach ($checklist as $item): ?>
                            <li class="flex items-start gap-3">
                                <i class="fas fa-check-circle text-success-500 mt-1"></i>
                                <div>
                                    <p class="font-medium text-gray-900"><?php echo htmlspecialchars($item['label'] ?? 'Checklist Item'); ?></p>
                                    <?php if (!empty($item['description'])): ?>
                                        <p class="text-sm text-gray-600"><?php echo htmlspecialchars($item['description']); ?></p>
                                    <?php endif; ?>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        <?php endif; ?>

        <?php if (!empty($activity_timeline)): ?>
            <div class="card" data-aos="fade-left" data-aos-delay="150">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        <i class="fas fa-history text-primary-500"></i>
                        Activity Timeline
                    </h3>
                </div>
                <div class="card-body">
                    <div class="space-y-4">
                        <?php foreach ($activity_timeline as $activity): ?>
                            <div class="relative pl-6 border-l border-gray-200">
                                <span class="absolute -left-[7px] top-1 w-3 h-3 bg-primary-500 rounded-full"></span>
                                <p class="text-sm text-gray-500"><?php echo htmlspecialchars($activity['timestamp'] ?? ''); ?></p>
                                <p class="font-medium text-gray-900"><?php echo htmlspecialchars($activity['title'] ?? 'Activity'); ?></p>
                                <?php if (!empty($activity['description'])): ?>
                                    <p class="text-sm text-gray-600"><?php echo htmlspecialchars($activity['description']); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($supporting_sections)): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <?php foreach ($supporting_sections as $section): ?>
            <div class="card" data-aos="fade-up">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        <?php if (!empty($section['icon'])): ?>
                            <i class="<?php echo htmlspecialchars($section['icon']); ?>"></i>
                        <?php endif; ?>
                        <?php echo htmlspecialchars($section['title'] ?? 'Section'); ?>
                    </h3>
                </div>
                <div class="card-body space-y-3">
                    <?php if (!empty($section['description'])): ?>
                        <p class="text-sm text-gray-600"><?php echo htmlspecialchars($section['description']); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($section['items'])): ?>
                        <ul class="space-y-2">
                            <?php foreach ($section['items'] as $item): ?>
                                <li class="flex items-start gap-3">
                                    <span class="w-2 h-2 rounded-full bg-primary-400 mt-2"></span>
                                    <div>
                                        <p class="font-medium text-gray-900"><?php echo htmlspecialchars($item['label'] ?? 'Item'); ?></p>
                                        <?php if (!empty($item['description'])): ?>
                                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($item['description']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
