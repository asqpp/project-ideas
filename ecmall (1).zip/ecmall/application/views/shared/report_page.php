<?php
$page_title = $page_title ?? 'Report';
$page_description = $page_description ?? '';
$filters = $filters ?? [];
$summary_cards = $summary_cards ?? [];
$columns = $columns ?? [];
$rows = $rows ?? [];
$notes = $notes ?? [];
$actions = $actions ?? [
    ['label' => 'Export Excel', 'icon' => 'fas fa-file-excel', 'variant' => 'outline'],
    ['label' => 'Schedule Report', 'icon' => 'fas fa-clock', 'variant' => 'primary']
];
$empty_state = $empty_state ?? [
    'title' => 'No records yet',
    'description' => 'Start by refining your filters or capturing new transactions to populate this report.'
];
?>

<!-- Page Header -->
<div class="page-header mb-8">
    <div>
        <p class="text-sm uppercase tracking-wide text-primary-600 font-semibold mb-1">Reports Console</p>
        <h1 class="page-title"><?php echo htmlspecialchars($page_title); ?></h1>
        <?php if (!empty($page_description)): ?>
            <p class="text-gray-600 mt-1 max-w-3xl">
                <?php echo htmlspecialchars($page_description); ?>
            </p>
        <?php endif; ?>
    </div>
    <div class="flex items-center gap-3">
        <?php foreach ($actions as $action): ?>
            <?php
            $variant = $action['variant'] ?? 'outline';
            $baseClass = $variant === 'primary' ? 'btn btn-primary' : 'btn btn-outline';
            ?>
            <button class="<?php echo $baseClass; ?>">
                <?php if (!empty($action['icon'])): ?>
                    <i class="<?php echo htmlspecialchars($action['icon']); ?>"></i>
                <?php endif; ?>
                <?php echo htmlspecialchars($action['label'] ?? 'Action'); ?>
            </button>
        <?php endforeach; ?>
        <?php
        $export_query = $_GET ?? [];
        $export_query['export'] = 'csv';
        ?>
        <a href="?<?php echo http_build_query($export_query); ?>" class="btn btn-outline">
            <i class="fas fa-file-download"></i> Export CSV
        </a>
    </div>
</div>

<?php if (!empty($filters)): ?>
    <div class="card mb-6" data-aos="fade-up">
        <div class="card-header">
            <h3 class="card-title flex items-center gap-2">
                <i class="fas fa-filter text-primary-500"></i>
                Report Filters
            </h3>
        </div>
        <div class="card-body">
            <form class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <?php foreach ($filters as $filter): ?>
                    <div class="<?php echo htmlspecialchars($filter['col_span'] ?? 'col-span-1'); ?>">
                        <label class="form-label"><?php echo htmlspecialchars($filter['label'] ?? 'Filter'); ?></label>
                        <?php if (($filter['type'] ?? '') === 'select'): ?>
                            <select class="form-select">
                                <option value=""><?php echo htmlspecialchars($filter['placeholder'] ?? 'Choose option'); ?></option>
                                <?php foreach ($filter['options'] ?? [] as $option): ?>
                                    <?php
                                    $optionValue = is_array($option) ? ($option['value'] ?? '') : $option;
                                    $optionLabel = is_array($option) ? ($option['label'] ?? $optionValue) : $option;
                                    ?>
                                    <option value="<?php echo htmlspecialchars($optionValue); ?>">
                                        <?php echo htmlspecialchars($optionLabel); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php else: ?>
                            <input
                                type="<?php echo htmlspecialchars($filter['type'] ?? 'text'); ?>"
                                class="form-input"
                                placeholder="<?php echo htmlspecialchars($filter['placeholder'] ?? ''); ?>"
                                value="<?php echo htmlspecialchars($filter['value'] ?? ''); ?>"
                            >
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </form>
        </div>
    </div>
<?php endif; ?>

<?php if (!empty($summary_cards)): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 mb-6">
        <?php foreach ($summary_cards as $card): ?>
            <div class="card border border-gray-100" data-aos="fade-up">
                <div class="card-body">
                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($card['label'] ?? 'Metric'); ?></p>
                    <p class="text-2xl font-semibold text-gray-900 mt-1"><?php echo htmlspecialchars($card['value'] ?? '--'); ?></p>
                    <?php if (!empty($card['trend'])): ?>
                        <p class="text-xs mt-1 text-<?php echo !empty($card['trend_positive']) ? 'green' : 'gray'; ?>-600">
                            <i class="fas fa-arrow-<?php echo !empty($card['trend_positive']) ? 'up' : 'right'; ?>"></i>
                            <?php echo htmlspecialchars($card['trend']); ?>
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<!-- Report Table -->
<div class="card" data-aos="fade-up">
    <div class="card-header flex items-center justify-between">
        <div>
            <h3 class="card-title">Report Preview</h3>
            <p class="text-sm text-gray-500">Real-time data synced from your operational modules</p>
        </div>
        <div class="flex items-center gap-2">
            <button class="btn btn-outline btn-sm">
                <i class="fas fa-print"></i>
                Print
            </button>
            <button class="btn btn-outline btn-sm">
                <i class="fas fa-file-pdf"></i>
                PDF
            </button>
        </div>
    </div>
    <div class="card-body overflow-x-auto">
        <?php if (!empty($rows)): ?>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <?php foreach ($columns as $column): ?>
                            <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider">
                                <?php echo htmlspecialchars($column['label'] ?? 'Column'); ?>
                            </th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-100">
                    <?php foreach ($rows as $row): ?>
                        <tr class="hover:bg-gray-50 transition-colors">
                            <?php foreach ($columns as $column): ?>
                                <?php
                                $key = $column['key'] ?? '';
                                $align = $column['align'] ?? 'left';
                                ?>
                                <td class="px-4 py-3 text-sm text-gray-700 text-<?php echo htmlspecialchars($align); ?>">
                                    <?php echo htmlspecialchars($row[$key] ?? '--'); ?>
                                </td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="text-center py-16">
                <div class="w-16 h-16 rounded-full bg-primary-50 text-primary-500 flex items-center justify-center mx-auto mb-4">
                    <i class="fas fa-database text-2xl"></i>
                </div>
                <h3 class="text-lg font-semibold text-gray-900"><?php echo htmlspecialchars($empty_state['title']); ?></h3>
                <p class="text-gray-600 mt-2 max-w-xl mx-auto"><?php echo htmlspecialchars($empty_state['description']); ?></p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php if (!empty($notes)): ?>
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
        <?php foreach ($notes as $note): ?>
            <div class="card" data-aos="fade-up">
                <div class="card-header">
                    <h3 class="card-title flex items-center gap-2">
                        <?php if (!empty($note['icon'])): ?>
                            <i class="<?php echo htmlspecialchars($note['icon']); ?>"></i>
                        <?php endif; ?>
                        <?php echo htmlspecialchars($note['title'] ?? 'Notes'); ?>
                    </h3>
                </div>
                <div class="card-body space-y-3">
                    <?php if (!empty($note['description'])): ?>
                        <p class="text-sm text-gray-600"><?php echo htmlspecialchars($note['description']); ?></p>
                    <?php endif; ?>
                    <?php if (!empty($note['items'])): ?>
                        <ul class="space-y-2">
                            <?php foreach ($note['items'] as $item): ?>
                                <li class="flex items-start gap-3">
                                    <span class="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                                    <div>
                                        <p class="font-medium text-gray-900"><?php echo htmlspecialchars($item['label'] ?? 'Item'); ?></p>
                                        <?php if (!empty($item['description'])): ?>
                                            <p class="text-sm text-gray-600"><?php echo htmlspecialchars($item['description']); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (!empty($pagination)): ?>
    <div class="flex flex-col md:flex-row md:items-center md:justify-between mt-6 gap-3">
        <p class="text-sm text-gray-600">
            Showing <?php echo number_format($pagination['from'] ?? 0); ?> -
            <?php echo number_format($pagination['to'] ?? 0); ?> of
            <?php echo number_format($pagination['total'] ?? 0); ?>
        </p>
        <div class="flex items-center gap-2">
            <?php
            $current = $pagination['current_page'] ?? 1;
            $total_pages = $pagination['total_pages'] ?? 1;
            $query_base = $_GET ?? [];
            ?>
            <?php if ($current > 1): ?>
                <?php $prev_query = $query_base; $prev_query['page'] = $current - 1; ?>
                <a href="?<?php echo http_build_query($prev_query); ?>" class="btn btn-outline btn-sm">
                    <i class="fas fa-arrow-left"></i> Prev
                </a>
            <?php endif; ?>
            <?php if ($current < $total_pages): ?>
                <?php $next_query = $query_base; $next_query['page'] = $current + 1; ?>
                <a href="?<?php echo http_build_query($next_query); ?>" class="btn btn-outline btn-sm">
                    Next <i class="fas fa-arrow-right"></i>
                </a>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>
