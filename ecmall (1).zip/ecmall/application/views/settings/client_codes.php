<?php
$customer = $customer_config ?? ['enabled' => true, 'prefix' => 'C', 'next' => 1, 'padding' => 4];
$supplier = $supplier_config ?? ['enabled' => true, 'prefix' => 'S', 'next' => 1, 'padding' => 4];
?>

<div class="page-header mb-8">
    <div>
        <h1 class="page-title">Client Code Settings</h1>
        <p class="text-gray-600 mt-1">Control auto-generated codes for customers and suppliers.</p>
    </div>
</div>

<?php if ($this->session->flashdata('success')): ?>
    <div class="alert alert-success mb-4">
        <i class="fas fa-check-circle"></i>
        <div class="flex-1"><?php echo $this->session->flashdata('success'); ?></div>
    </div>
<?php endif; ?>

<form method="post">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Customer Codes</h3>
            </div>
            <div class="card-body space-y-4">
                <label class="flex items-center gap-2">
                    <input type="checkbox" name="customer_enabled" value="1" <?php echo !empty($customer['enabled']) ? 'checked' : ''; ?>>
                    Enable auto-code
                </label>
                <div>
                    <label class="form-label">Prefix</label>
                    <input type="text" name="customer_prefix" value="<?php echo htmlspecialchars($customer['prefix'] ?? 'C'); ?>" class="form-input">
                </div>
                <div>
                    <label class="form-label">Next Number</label>
                    <input type="number" name="customer_next" value="<?php echo htmlspecialchars($customer['next'] ?? 1); ?>" class="form-input">
                </div>
                <div>
                    <label class="form-label">Padding Digits</label>
                    <input type="number" name="customer_padding" value="<?php echo htmlspecialchars($customer['padding'] ?? 4); ?>" class="form-input">
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h3 class="card-title">Supplier Codes</h3>
            </div>
            <div class="card-body space-y-4">
                <label class="flex items-center gap-2">
                    <input type="checkbox" name="supplier_enabled" value="1" <?php echo !empty($supplier['enabled']) ? 'checked' : ''; ?>>
                    Enable auto-code
                </label>
                <div>
                    <label class="form-label">Prefix</label>
                    <input type="text" name="supplier_prefix" value="<?php echo htmlspecialchars($supplier['prefix'] ?? 'S'); ?>" class="form-input">
                </div>
                <div>
                    <label class="form-label">Next Number</label>
                    <input type="number" name="supplier_next" value="<?php echo htmlspecialchars($supplier['next'] ?? 1); ?>" class="form-input">
                </div>
                <div>
                    <label class="form-label">Padding Digits</label>
                    <input type="number" name="supplier_padding" value="<?php echo htmlspecialchars($supplier['padding'] ?? 4); ?>" class="form-input">
                </div>
            </div>
        </div>
    </div>

    <div class="mt-6 flex gap-3">
        <button class="btn btn-primary">
            <i class="fas fa-save"></i> Save Settings
        </button>
        <a href="<?php echo base_url('settings'); ?>" class="btn btn-outline">Cancel</a>
    </div>
</form>
