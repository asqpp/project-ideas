<?php
$account = $account ?? null;
$accounts_legacy = $accounts_legacy ?? [];
$groups_legacy = $groups_legacy ?? [];
$heads_legacy = $heads_legacy ?? [];
$is_edit = !empty($account);
$actype1_value = $account->actype1 ?? 'A';
?>

<div class="flex flex-col gap-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h1 class="page-title mb-1">Account Details</h1>
            <p class="text-gray-600">PowerBuilder-inspired account maintenance with position controls and schedule links.</p>
        </div>
        <div class="flex flex-wrap gap-2">
            <form method="post" enctype="multipart/form-data" action="<?php echo base_url('accounts/import_legacy_data'); ?>" class="flex gap-2 flex-wrap">
                <input type="hidden" name="redirect" value="accounts/add">
                <select name="type" class="form-select">
                    <option value="accounts">Import Accounts</option>
                    <option value="groups">Import Groups</option>
                    <option value="heads">Import BS Heads</option>
                </select>
                <input type="file" name="upload_file" accept=".csv,.txt" class="form-input">
                <button class="btn btn-secondary"><i class="fas fa-file-import"></i> Import</button>
            </form>
            <a href="<?php echo base_url('accounts/positions'); ?>" class="btn btn-outline">
                <i class="fas fa-sort-amount-up"></i> Manage Positions
            </a>
            <a href="<?php echo base_url('accounts/groups'); ?>" class="btn btn-outline">
                <i class="fas fa-layer-group"></i> Group Details
            </a>
            <a href="<?php echo base_url('accounts/heads'); ?>" class="btn btn-outline">
                <i class="fas fa-diagram-project"></i> BS Heads
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="lg:col-span-2">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Account Master <?php echo $is_edit ? '(Edit)' : '(Add)'; ?></h3>
                </div>
                <div class="card-body">
                    <form method="post" class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <input type="hidden" name="is_edit" value="<?php echo $is_edit ? '1' : '0'; ?>">
                        <div>
                            <label class="form-label">Account Code</label>
                            <input type="text" name="accode" class="form-input" value="<?php echo htmlspecialchars($account->accode ?? ''); ?>" <?php echo $is_edit ? 'readonly' : ''; ?>>
                        </div>
                        <div>
                            <label class="form-label">Account Name</label>
                            <input type="text" name="name" class="form-input" value="<?php echo htmlspecialchars($account->name ?? ''); ?>">
                        </div>
                        <div>
                            <label class="form-label">Primary Type</label>
                            <select name="actype1" class="form-select">
                                <?php foreach (['A' => 'Asset', 'L' => 'Liability', 'E' => 'Expense', 'R' => 'Revenue'] as $key => $label): ?>
                                    <option value="<?php echo $key; ?>" <?php echo ($actype1_value === $key) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="form-label">Group</label>
                            <select name="grcode" class="form-select">
                                <option value="">-- Select Group --</option>
                                <?php foreach ($groups_legacy as $group): ?>
                                    <option value="<?php echo $group->grcode; ?>" <?php echo (($account->grcode ?? '') === $group->grcode) ? 'selected' : ''; ?>>
                                        <?php echo $group->grcode . ' - ' . $group->name; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="form-label">BS Head</label>
                            <select name="bshead" class="form-select">
                                <option value="">-- Select Head --</option>
                                <?php foreach ($heads_legacy as $head): ?>
                                    <option value="<?php echo $head->hcode; ?>" <?php echo (($account->bshead ?? '') === $head->hcode) ? 'selected' : ''; ?>>
                                        <?php echo $head->hcode . ' - ' . $head->hname; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="form-label">Opening Balance (Dr)</label>
                            <input type="number" step="0.01" name="opbal" class="form-input" value="<?php echo htmlspecialchars($account->opbal ?? 0); ?>">
                        </div>
                        <div>
                            <label class="form-label">Opening Balance (Cr)</label>
                            <input type="number" step="0.01" name="opbalb" class="form-input" value="<?php echo htmlspecialchars($account->opbalb ?? 0); ?>">
                        </div>
                        <div>
                            <label class="form-label">Trade / Profit Position</label>
                            <input type="number" name="tplpos" class="form-input" value="<?php echo htmlspecialchars($account->tplpos ?? 0); ?>">
                        </div>
                        <div>
                            <label class="form-label">Schedule Position</label>
                            <input type="number" name="shepos" class="form-input" value="<?php echo htmlspecialchars($account->shepos ?? 0); ?>">
                        </div>
                        <div>
                            <label class="form-label">Schedule Group</label>
                            <input list="schedule-groups" name="shedgrp" class="form-input" value="<?php echo htmlspecialchars($account->shedgrp ?? ''); ?>">
                            <datalist id="schedule-groups">
                                <?php foreach ($schedule_groups as $grp): ?>
                                    <option value="<?php echo htmlspecialchars($grp); ?>">
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                        <div class="flex items-center gap-2">
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="reserve" <?php echo (($account->reserve ?? '') === 'Y') ? 'checked' : ''; ?>>
                                Reserved
                            </label>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="control" <?php echo (($account->control ?? 1) ? 'checked' : ''); ?>>
                                Display
                            </label>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="hlp" <?php echo (($account->hlp ?? 1) ? 'checked' : ''); ?>>
                                Help Visible
                            </label>
                        </div>
                        <div class="flex items-center gap-2">
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="sp" <?php echo (($account->sp ?? 0) ? 'checked' : ''); ?>>
                                Special
                            </label>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="removed" <?php echo (($account->removed ?? '') === 'Y') ? 'checked' : ''; ?>>
                                Removed
                            </label>
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="blocked" <?php echo (($account->blocked ?? '') === 'Y') ? 'checked' : ''; ?>>
                                Blocked
                            </label>
                        </div>
                        <div class="md:col-span-2">
                            <label class="form-label">Note</label>
                            <textarea name="note" class="form-input" rows="3"><?php echo htmlspecialchars($account->note ?? ''); ?></textarea>
                        </div>
                        <div class="md:col-span-2 flex flex-wrap gap-2">
                            <button class="btn btn-primary">
                                <i class="fas fa-save"></i> <?php echo $is_edit ? 'Update' : 'Save'; ?>
                            </button>
                            <?php if ($is_edit): ?>
                                <button name="action" value="delete" class="btn btn-danger" onclick="return confirm('Delete this account?')">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                                <a href="<?php echo base_url('accounts/add'); ?>" class="btn btn-outline">
                                    Cancel
                                </a>
                            <?php else: ?>
                                <button type="reset" class="btn btn-outline">Reset</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div>
            <div class="card h-full">
                <div class="card-header">
                    <h3 class="card-title">Existing Accounts</h3>
                </div>
                <div class="card-body max-h-[70vh] overflow-y-auto">
                    <table class="w-full text-sm">
                        <thead>
                        <tr class="text-left text-gray-500 text-xs uppercase">
                            <th class="pb-2">Code</th>
                            <th class="pb-2">Name</th>
                            <th class="pb-2">Type</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($accounts_legacy as $row): ?>
                            <tr class="border-b border-gray-100 hover:bg-gray-50">
                                <td class="py-1">
                                    <a href="<?php echo base_url('accounts/add?accode=' . $row->accode); ?>" class="text-primary-600 font-semibold">
                                        <?php echo htmlspecialchars($row->accode); ?>
                                    </a>
                                </td>
                                <td class="py-1"><?php echo htmlspecialchars($row->name); ?></td>
                                <td class="py-1"><?php echo htmlspecialchars($row->actype1); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
