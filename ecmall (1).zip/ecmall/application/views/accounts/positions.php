<?php
$context = $context ?? 'accounts';
$sort = $sort ?? 'tplpos';
?>

<div class="flex flex-col gap-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h1 class="page-title mb-1">Account Positions</h1>
            <p class="text-gray-600">Sort and update report positions for accounts, groups and balance sheet heads.</p>
        </div>
        <form method="get" class="flex flex-col md:flex-row gap-2">
            <select name="context" class="form-select">
                <option value="accounts" <?php echo $context === 'accounts' ? 'selected' : ''; ?>>Accounts Position</option>
                <option value="groups" <?php echo $context === 'groups' ? 'selected' : ''; ?>>Group Position</option>
                <option value="heads" <?php echo $context === 'heads' ? 'selected' : ''; ?>>BS Head Position</option>
            </select>
            <?php if ($context === 'accounts'): ?>
                <select name="sort" class="form-select">
                    <option value="tplpos" <?php echo $sort === 'tplpos' ? 'selected' : ''; ?>>Trade / Profit</option>
                    <option value="shepos" <?php echo $sort === 'shepos' ? 'selected' : ''; ?>>Schedule Position</option>
                    <option value="name" <?php echo $sort === 'name' ? 'selected' : ''; ?>>Alphabetical</option>
                </select>
            <?php else: ?>
                <input type="hidden" name="sort" value="<?php echo htmlspecialchars($sort); ?>">
            <?php endif; ?>
            <button class="btn btn-secondary"><i class="fas fa-filter"></i> Apply</button>
        </form>
    </div>

    <form method="post" action="<?php echo base_url('accounts/update_positions'); ?>">
        <input type="hidden" name="context" value="<?php echo htmlspecialchars($context); ?>">
        <div class="card">
            <div class="card-header flex justify-between items-center">
                <h3 class="card-title">Positions</h3>
                <button class="btn btn-primary btn-sm">
                    <i class="fas fa-save"></i>
                    Update
                </button>
            </div>
            <div class="card-body overflow-x-auto">
                <?php if (empty($records)): ?>
                    <p class="text-gray-500 text-center py-8">No records found.</p>
                <?php else: ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Code</th>
                            <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Name</th>
                            <?php if ($context === 'accounts'): ?>
                                <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Trade/PL</th>
                                <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Schedule</th>
                                <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Schedule Group</th>
                            <?php else: ?>
                                <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Position</th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                        <?php foreach ($records as $record): ?>
                            <tr>
                                <td class="px-4 py-2 font-semibold">
                                    <?php echo htmlspecialchars($record->accode ?? $record->grcode ?? $record->hcode); ?>
                                </td>
                                <td class="px-4 py-2">
                                    <?php
                                    $label = $record->name ?? ($record->hname ?? '');
                                    echo htmlspecialchars($label);
                                    ?>
                                </td>
                                <?php if ($context === 'accounts'): ?>
                                    <td class="px-4 py-2">
                                        <input type="number"
                                               name="records[<?php echo htmlspecialchars($record->accode); ?>][tplpos]"
                                               class="form-input"
                                               value="<?php echo (int) $record->tplpos; ?>">
                                    </td>
                                    <td class="px-4 py-2">
                                        <input type="number"
                                               name="records[<?php echo htmlspecialchars($record->accode); ?>][shepos]"
                                               class="form-input"
                                               value="<?php echo (int) $record->shepos; ?>">
                                    </td>
                                    <td class="px-4 py-2">
                                        <input type="text"
                                               name="records[<?php echo htmlspecialchars($record->accode); ?>][shedgrp]"
                                               class="form-input"
                                               value="<?php echo htmlspecialchars($record->shedgrp); ?>">
                                    </td>
                                <?php elseif ($context === 'groups'): ?>
                                    <td class="px-4 py-2">
                                        <input type="number"
                                               name="records[<?php echo htmlspecialchars($record->grcode); ?>][pos]"
                                               class="form-input"
                                               value="<?php echo (int) $record->pos; ?>">
                                    </td>
                                <?php else: ?>
                                    <td class="px-4 py-2">
                                        <input type="number"
                                               name="records[<?php echo htmlspecialchars($record->hcode); ?>][pos]"
                                               class="form-input"
                                               value="<?php echo (int) $record->pos; ?>">
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </form>
</div>
