<?php
$group = $group ?? null;
$groups_legacy = $groups_legacy ?? [];
$is_edit = !empty($group);
?>

<div class="flex flex-col gap-6">
    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
            <h1 class="page-title mb-1">Group Details</h1>
            <p class="text-gray-600">Manage account grouping used for the legacy reporting structure.</p>
        </div>
        <div class="flex gap-2">
            <a href="<?php echo base_url('accounts/add'); ?>" class="btn btn-outline">
                <i class="fas fa-arrow-left"></i> Back to Accounts
            </a>
            <a href="<?php echo base_url('accounts/heads'); ?>" class="btn btn-outline">
                BS Heads
            </a>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div class="md:col-span-1">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"><?php echo $is_edit ? 'Edit Group' : 'Add Group'; ?></h3>
                </div>
                <div class="card-body">
                    <form method="post" class="space-y-3">
                        <input type="hidden" name="is_edit" value="<?php echo $is_edit ? '1' : '0'; ?>">
                        <div>
                            <label class="form-label">Group Code</label>
                            <input type="text" name="grcode" class="form-input" value="<?php echo htmlspecialchars($group->grcode ?? ''); ?>" <?php echo $is_edit ? 'readonly' : ''; ?>>
                        </div>
                        <div>
                            <label class="form-label">Group Name</label>
                            <input type="text" name="name" class="form-input" value="<?php echo htmlspecialchars($group->name ?? ''); ?>">
                        </div>
                        <div>
                            <label class="form-label">Type</label>
                            <select name="actype1" class="form-select">
                                <?php foreach (['A' => 'Asset', 'L' => 'Liability', 'E' => 'Expense', 'R' => 'Revenue'] as $key => $label): ?>
                                    <option value="<?php echo $key; ?>" <?php echo (($group->actype1 ?? '') === $key) ? 'selected' : ''; ?>>
                                        <?php echo $label; ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="flex gap-2">
                            <label class="flex items-center gap-2">
                                <input type="checkbox" name="reserve" <?php echo (($group->reserve ?? '') === 'Y') ? 'checked' : ''; ?>>
                                Reserved
                            </label>
                        </div>
                        <div>
                            <label class="form-label">Position</label>
                            <input type="number" name="position" class="form-input" value="<?php echo htmlspecialchars($group->position ?? 0); ?>">
                        </div>
                        <div>
                            <label class="form-label">POS</label>
                            <input type="number" name="pos" class="form-input" value="<?php echo htmlspecialchars($group->pos ?? 0); ?>">
                        </div>
                        <div>
                            <label class="form-label">Main Group</label>
                            <input type="text" name="mgrp" class="form-input" value="<?php echo htmlspecialchars($group->mgrp ?? ''); ?>">
                        </div>
                        <div class="flex flex-wrap gap-2">
                            <button class="btn btn-primary">
                                <i class="fas fa-save"></i> <?php echo $is_edit ? 'Update' : 'Save'; ?>
                            </button>
                            <?php if ($is_edit): ?>
                                <button name="action" value="delete" class="btn btn-danger" onclick="return confirm('Delete this group?')">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                                <a href="<?php echo base_url('accounts/groups'); ?>" class="btn btn-outline">Cancel</a>
                            <?php else: ?>
                                <button type="reset" class="btn btn-outline">Reset</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="md:col-span-2">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Existing Groups</h3>
                </div>
                <div class="card-body overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200 text-sm">
                        <thead class="bg-gray-50">
                        <tr>
                            <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Code</th>
                            <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Name</th>
                            <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Type</th>
                            <th class="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Position</th>
                        </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100">
                        <?php foreach ($groups_legacy as $row): ?>
                            <tr class="hover:bg-gray-50">
                                <td class="px-4 py-2 font-semibold">
                                    <a href="<?php echo base_url('accounts/groups?grcode=' . $row->grcode); ?>" class="text-primary-600">
                                        <?php echo htmlspecialchars($row->grcode); ?>
                                    </a>
                                </td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($row->name); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($row->actype1); ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($row->pos); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
