<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>

A Database Error Occurred

<?php echo $message, "\n"; ?>
