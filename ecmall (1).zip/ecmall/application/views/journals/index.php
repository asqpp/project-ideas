<?php
$filters = $filters ?? [];
$journals = $journals ?? [];
$accounts = $accounts ?? [];

if (!function_exists('format_account_option')) {
    function format_account_option($account)
    {
        return ($account->account_code ?? '') . ' - ' . ($account->account_name ?? '');
    }
}
?>

<div class="page-header mb-8">
    <div>
        <h1 class="page-title">Journal Entries</h1>
        <p class="text-gray-600 mt-1">
            Double-entry workspace for accruals, adjustments and closing entries with validation alerts.
        </p>
    </div>
    <div class="flex items-center gap-3">
        <a href="<?php echo base_url('reports/general_ledger'); ?>" class="btn btn-outline">
            <i class="fas fa-book-open"></i>
            View General Ledger
        </a>
        <button class="btn btn-primary">
            <i class="fas fa-plus"></i>
            New Journal
        </button>
    </div>
</div>

<div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
    <div class="xl:col-span-2 space-y-6">
        <div class="card" data-aos="fade-up">
            <div class="card-header flex items-center justify-between">
                <div>
                    <h3 class="card-title">Recent Journal Vouchers</h3>
                    <p class="text-sm text-gray-500">Automated pagination and filters for accounting audits</p>
                </div>
                <div class="flex items-center gap-2">
                    <button class="btn btn-outline">
                        <i class="fas fa-file-export"></i>
                        Export
                    </button>
                </div>
            </div>
            <div class="card-body">
                <form class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <div>
                        <label class="form-label">From Date</label>
                        <input type="date" class="form-input" value="<?php echo htmlspecialchars($filters['from_date'] ?? ''); ?>">
                    </div>
                    <div>
                        <label class="form-label">To Date</label>
                        <input type="date" class="form-input" value="<?php echo htmlspecialchars($filters['to_date'] ?? ''); ?>">
                    </div>
                    <div class="flex items-end">
                        <button class="btn btn-primary w-full">
                            <i class="fas fa-search"></i>
                            Apply Filter
                        </button>
                    </div>
                </form>

                <div class="overflow-x-auto">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Date</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Voucher No</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Description</th>
                                <th class="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Created By</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-100">
                            <?php if (!empty($journals)): ?>
                                <?php foreach ($journals as $journal): ?>
                                    <tr class="hover:bg-gray-50 transition-colors">
                                        <td class="px-4 py-3 text-sm text-gray-700">
                                            <?php echo htmlspecialchars(date('d M Y', strtotime($journal->date ?? date('Y-m-d')))); ?>
                                        </td>
                                        <td class="px-4 py-3 text-sm font-semibold text-gray-900">
                                            <?php echo htmlspecialchars($journal->voucher_no ?? 'JV'); ?>
                                        </td>
                                        <td class="px-4 py-3 text-sm text-gray-700">
                                            <?php echo htmlspecialchars($journal->description ?? '---'); ?>
                                        </td>
                                        <td class="px-4 py-3 text-sm text-gray-500">
                                            <?php echo htmlspecialchars($journal->created_by ?? 'System'); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="4" class="px-4 py-6 text-center text-sm text-gray-500">
                                        No journal entries yet. Start by capturing a new voucher on the right.
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <div class="space-y-6">
        <div class="card" data-aos="fade-left">
            <div class="card-header">
                <h3 class="card-title flex items-center gap-2">
                    <i class="fas fa-pen-fancy text-primary-500"></i>
                    Quick Journal Entry
                </h3>
            </div>
            <div class="card-body space-y-4">
                <div>
                    <label class="form-label">Journal Date</label>
                    <input type="date" class="form-input" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div>
                    <label class="form-label">Reference</label>
                    <input type="text" class="form-input" placeholder="e.g. Accrual for commissions">
                </div>
                <div class="border rounded-lg p-3 space-y-3 bg-gray-50">
                    <div class="flex items-center justify-between">
                        <p class="text-sm font-semibold text-gray-700">Debit Line</p>
                        <button class="text-xs text-primary-600">Add Row</button>
                    </div>
                    <select class="form-select">
                        <option value="">Select Debit Account</option>
                        <?php foreach ($accounts as $account): ?>
                            <option value="<?php echo htmlspecialchars($account->account_code); ?>">
                                <?php echo htmlspecialchars(format_account_option($account)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="number" class="form-input" placeholder="Debit Amount">
                </div>
                <div class="border rounded-lg p-3 space-y-3 bg-gray-50">
                    <div class="flex items-center justify-between">
                        <p class="text-sm font-semibold text-gray-700">Credit Line</p>
                        <button class="text-xs text-primary-600">Add Row</button>
                    </div>
                    <select class="form-select">
                        <option value="">Select Credit Account</option>
                        <?php foreach ($accounts as $account): ?>
                            <option value="<?php echo htmlspecialchars($account->account_code); ?>">
                                <?php echo htmlspecialchars(format_account_option($account)); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <input type="number" class="form-input" placeholder="Credit Amount">
                </div>
                <div>
                    <label class="form-label">Narration</label>
                    <textarea class="form-input min-h-[100px]" placeholder="Explain the purpose or link to transaction"></textarea>
                </div>
                <div class="flex items-center gap-3">
                    <button class="btn btn-primary flex-1">
                        <i class="fas fa-check-circle"></i>
                        Validate Entry
                    </button>
                    <button class="btn btn-outline flex-1">
                        <i class="fas fa-save"></i>
                        Save Draft
                    </button>
                </div>
            </div>
        </div>

        <div class="card" data-aos="fade-left">
            <div class="card-header">
                <h3 class="card-title flex items-center gap-2">
                    <i class="fas fa-bell text-primary-500"></i>
                    Notifications
                </h3>
            </div>
            <div class="card-body space-y-3 text-sm text-gray-600">
                <div class="flex items-start gap-3">
                    <span class="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                    <p>Alerts trigger if debits and credits mismatch ensuring double-entry validation.</p>
                </div>
                <div class="flex items-start gap-3">
                    <span class="w-2 h-2 bg-primary-500 rounded-full mt-2"></span>
                    <p>Approvers receive push notifications for high value journal vouchers.</p>
                </div>
            </div>
        </div>
    </div>
</div>
