<?php card_start('Add Purchase'); ?>

<form method="post" action="<?php echo base_url('purchases/add'); ?>" id="purchaseForm">
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Purchase Details -->
        <div class="lg:col-span-2">
            <div class="space-y-6">
                <!-- Basic Info -->
                <div class="bg-gray-50 p-4 rounded-lg">
                    <h3 class="text-lg font-semibold mb-4">Purchase Information</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <?php echo form_select_group(
                            'supplier_id',
                            'Supplier',
                            $suppliers,
                            set_value('supplier_id'),
                            'supplier_id',
                            'supplier_name',
                            true,
                            'fas fa-truck'
                        ); ?>

                        <?php echo form_input_group(
                            'purchase_date',
                            'Purchase Date',
                            set_value('purchase_date', date('Y-m-d')),
                            true,
                            'date',
                            '',
                            'fas fa-calendar'
                        ); ?>

                        <?php echo form_input_group(
                            'chalan_no',
                            'Chalan No',
                            set_value('chalan_no', $generated_chalan ?? ''),
                            true,
                            'text',
                            '',
                            'fas fa-receipt'
                        ); ?>
                    </div>
                </div>

                <!-- Purchase Items -->
                <div class="bg-white border border-gray-200 rounded-lg p-4">
                    <div class="flex justify-between items-center mb-4">
                        <h3 class="text-lg font-semibold">Purchase Items</h3>
                        <button type="button" onclick="addItemRow()" class="btn btn-sm btn-primary">
                            <i class="fas fa-plus"></i> Add Item
                        </button>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full" id="itemsTable">
                            <thead class="bg-gray-50">
                                <tr>
                                    <th class="px-4 py-2 text-left">Product</th>
                                    <th class="px-4 py-2 text-left" style="width: 120px;">Batch No</th>
                                    <th class="px-4 py-2 text-left" style="width: 140px;">Expiry Date</th>
                                    <th class="px-4 py-2 text-left" style="width: 120px;">Quantity</th>
                                    <th class="px-4 py-2 text-left" style="width: 120px;">Rate</th>
                                    <th class="px-4 py-2 text-left" style="width: 120px;">Discount %</th>
                                    <th class="px-4 py-2 text-left" style="width: 140px;">Discount Value</th>
                                    <th class="px-4 py-2 text-left" style="width: 120px;">VAT %</th>
                                    <th class="px-4 py-2 text-left" style="width: 140px;">VAT Value</th>
                                    <th class="px-4 py-2 text-left" style="width: 140px;">Line Total</th>
                                    <th class="px-4 py-2 text-center" style="width: 60px;">Action</th>
                                </tr>
                            </thead>
                            <tbody id="itemsBody">
                                <!-- Items will be added here by JavaScript -->
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Notes -->
                <div>
                    <?php echo form_textarea_group(
                        'notes',
                        'Notes',
                        set_value('notes'),
                        false,
                        'Any additional notes...',
                        'fas fa-sticky-note'
                    ); ?>
                </div>

                <!-- Hidden field for items JSON -->
                <input type="hidden" name="items" id="itemsJson">
                <input type="hidden" name="payments" id="paymentsJson">
            </div>
        </div>

        <!-- Summary Sidebar -->
        <div class="lg:col-span-1 space-y-6">
            <div class="bg-primary-50 border border-primary-200 rounded-lg p-6 sticky top-4">
                <h3 class="text-lg font-semibold mb-4 text-primary-900">Purchase Summary</h3>

                <div class="space-y-3">
                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Items:</span>
                        <span id="summary-items" class="font-semibold">0</span>
                    </div>

                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Quantity:</span>
                        <span id="summary-quantity" class="font-semibold">0</span>
                    </div>

                    <div class="border-t pt-3"></div>

                    <div class="flex justify-between">
                        <span class="text-gray-900">Subtotal:</span>
                        <span id="summary-subtotal" class="font-semibold text-gray-900">AED 0.00</span>
                    </div>

                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Line Discount:</span>
                        <span id="summary-line-discount" class="font-semibold text-danger-600">AED 0.00</span>
                    </div>

                    <label class="block text-sm text-gray-600" for="purchaseDiscount">Purchase Discount</label>
                    <input type="number"
                           step="0.01"
                           min="0"
                           id="purchaseDiscount"
                           name="purchase_discount"
                           value="<?php echo set_value('purchase_discount', 0); ?>"
                           class="form-control mb-2"
                           placeholder="0.00">

                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Total Discount:</span>
                        <span id="summary-total-discount" class="font-semibold text-danger-600">AED 0.00</span>
                    </div>

                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Total VAT:</span>
                        <span id="summary-vat" class="font-semibold">AED 0.00</span>
                    </div>

                    <div class="border-t pt-3"></div>

                    <div class="flex justify-between text-lg">
                        <span class="font-bold text-primary-900">Grand Total:</span>
                        <span id="summary-grand-total" class="font-bold text-primary-600">AED 0.00</span>
                    </div>

                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Paid Amount:</span>
                        <span id="summary-paid" class="font-semibold text-success-600">AED 0.00</span>
                    </div>

                    <div class="flex justify-between text-sm">
                        <span class="text-gray-600">Due Amount:</span>
                        <span id="summary-due" class="font-semibold text-gray-900">AED 0.00</span>
                    </div>
                </div>

                <div class="mt-6 pt-6 border-t">
                    <button type="submit" class="btn btn-primary btn-block btn-lg">
                        <i class="fas fa-save"></i> Record Purchase
                    </button>
                    <a href="<?php echo base_url('purchases'); ?>" class="btn btn-outline btn-block mt-2">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>

                <div class="mt-4 text-xs text-gray-600">
                    <i class="fas fa-info-circle"></i> Stock will be updated automatically
                </div>
            </div>

            <div class="bg-white border border-gray-200 rounded-lg p-4">
                <div class="flex justify-between items-center mb-3">
                    <h3 class="text-lg font-semibold">Payment Breakdown</h3>
                    <button type="button" class="btn btn-sm btn-outline" onclick="addPaymentRow()">
                        <i class="fas fa-plus"></i> Add Payment
                    </button>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead class="bg-gray-50">
                            <tr>
                                <th class="px-3 py-2 text-left">Method</th>
                                <th class="px-3 py-2 text-left" style="width: 130px;">Amount</th>
                                <th class="px-3 py-2 text-center" style="width: 60px;">Action</th>
                            </tr>
                        </thead>
                        <tbody id="paymentsBody"></tbody>
                    </table>
                </div>

                <p class="text-xs text-gray-500 mt-3">
                    Paid amount must not exceed the grand total. Add multiple payment modes as needed.
                </p>
            </div>
        </div>
    </div>
</form>

<?php card_end(); ?>

<script>
const products = <?php echo json_encode($products ?? []); ?>;
let itemCounter = 0;
let paymentCounter = 0;
let currentGrandTotal = 0;

function addItemRow() {
    itemCounter++;
    const row = document.createElement('tr');
    row.id = `item-${itemCounter}`;
    row.innerHTML = `
        <td class="px-4 py-2">
            <select class="form-control" onchange="selectProduct(${itemCounter}, this.value)" required>
                <option value="">Select Product</option>
                ${products.map(p => `<option value="${p.product_id}">${p.product_name} ${p.product_model ? '(' + p.product_model + ')' : ''}</option>`).join('')}
            </select>
        </td>
        <td class="px-4 py-2">
            <input type="text" class="form-control" id="batch-${itemCounter}" placeholder="Batch #">
        </td>
        <td class="px-4 py-2">
            <input type="date" class="form-control" id="expiry-${itemCounter}">
        </td>
        <td class="px-4 py-2">
            <input type="number" class="form-control" id="qty-${itemCounter}" min="0" step="0.01" value="1" oninput="updateItemTotal(${itemCounter})" required>
        </td>
        <td class="px-4 py-2">
            <input type="number" class="form-control" id="rate-${itemCounter}" min="0" step="0.01" value="0" oninput="updateItemTotal(${itemCounter})" required>
        </td>
        <td class="px-4 py-2">
            <input type="number" class="form-control" id="discount-${itemCounter}" min="0" step="0.01" value="0" oninput="updateItemTotal(${itemCounter})">
        </td>
        <td class="px-4 py-2">
            <input type="text" class="form-control bg-gray-100" id="discount-value-${itemCounter}" value="0.00" readonly>
        </td>
        <td class="px-4 py-2">
            <input type="number" class="form-control" id="vat-${itemCounter}" min="0" step="0.01" value="5" oninput="updateItemTotal(${itemCounter})">
        </td>
        <td class="px-4 py-2">
            <input type="text" class="form-control bg-gray-100" id="vat-value-${itemCounter}" value="0.00" readonly>
        </td>
        <td class="px-4 py-2">
            <span id="line-total-${itemCounter}" class="font-semibold">AED 0.00</span>
        </td>
        <td class="px-4 py-2 text-center">
            <button type="button" onclick="removeItemRow(${itemCounter})" class="text-danger-600 hover:text-danger-800">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;

    document.getElementById('itemsBody').appendChild(row);
    updateItemTotal(itemCounter);
}

function selectProduct(itemId, productId) {
    const product = products.find(p => p.product_id == productId);
    if (product) {
        document.getElementById(`rate-${itemId}`).value = product.supplier_price || product.price || 0;
        updateItemTotal(itemId);
    }
}

function getLineValues(itemId) {
    const qty = parseFloat(document.getElementById(`qty-${itemId}`)?.value) || 0;
    const rate = parseFloat(document.getElementById(`rate-${itemId}`)?.value) || 0;
    const discountPct = Math.max(parseFloat(document.getElementById(`discount-${itemId}`)?.value) || 0, 0);
    const vatPct = Math.max(parseFloat(document.getElementById(`vat-${itemId}`)?.value) || 0, 0);

    const subtotal = qty * rate;
    const discountValue = subtotal * (discountPct / 100);
    const taxable = subtotal - discountValue;
    const vatValue = taxable * (vatPct / 100);
    const lineTotal = taxable + vatValue;

    return {
        qty,
        rate,
        discountPct,
        vatPct,
        subtotal,
        discountValue,
        vatValue,
        lineTotal
    };
}

function updateItemTotal(itemId) {
    const values = getLineValues(itemId);
    document.getElementById(`discount-value-${itemId}`).value = values.discountValue.toFixed(2);
    document.getElementById(`vat-value-${itemId}`).value = values.vatValue.toFixed(2);
    document.getElementById(`line-total-${itemId}`).textContent = `AED ${values.lineTotal.toFixed(2)}`;
    updateSummary();
}

function removeItemRow(itemId) {
    const row = document.getElementById(`item-${itemId}`);
    if (row) {
        row.remove();
        updateSummary();
    }
}

function updateSummary() {
    const rows = document.querySelectorAll('#itemsBody tr');
    let itemCount = 0;
    let totalQty = 0;
    let subtotal = 0;
    let lineDiscount = 0;
    let totalVat = 0;

    rows.forEach(row => {
        const rowId = parseInt(row.id.split('-')[1]);
        const values = getLineValues(rowId);
        if (values.qty > 0 && values.rate > 0) {
            itemCount++;
            totalQty += values.qty;
            subtotal += values.subtotal;
            lineDiscount += values.discountValue;
            totalVat += values.vatValue;
        }
    });

    const purchaseDiscount = Math.max(parseFloat(document.getElementById('purchaseDiscount')?.value) || 0, 0);
    const totalDiscount = lineDiscount + purchaseDiscount;
    const grandTotal = Math.max(subtotal - totalDiscount + totalVat, 0);
    currentGrandTotal = grandTotal;

    document.getElementById('summary-items').textContent = itemCount;
    document.getElementById('summary-quantity').textContent = totalQty.toFixed(2);
    document.getElementById('summary-subtotal').textContent = `AED ${subtotal.toFixed(2)}`;
    document.getElementById('summary-line-discount').textContent = `AED ${lineDiscount.toFixed(2)}`;
    document.getElementById('summary-total-discount').textContent = `AED ${totalDiscount.toFixed(2)}`;
    document.getElementById('summary-vat').textContent = `AED ${totalVat.toFixed(2)}`;
    document.getElementById('summary-grand-total').textContent = `AED ${grandTotal.toFixed(2)}`;

    updatePaymentSummary();
}

function addPaymentRow() {
    paymentCounter++;
    const row = document.createElement('tr');
    row.id = `payment-${paymentCounter}`;
    row.innerHTML = `
        <td class="px-3 py-2">
            <select class="form-control" id="payment-method-${paymentCounter}" onchange="updatePaymentSummary()">
                <option value="cash">Cash</option>
                <option value="bank">Bank</option>
                <option value="cheque">Cheque</option>
                <option value="credit">Credit</option>
                <option value="petty cash">Petty Cash</option>
                <option value="card">Card</option>
            </select>
        </td>
        <td class="px-3 py-2">
            <input type="number" class="form-control" id="payment-amount-${paymentCounter}" min="0" step="0.01" value="0" oninput="updatePaymentSummary()">
        </td>
        <td class="px-3 py-2 text-center">
            <button type="button" class="text-danger-600 hover:text-danger-800" onclick="removePaymentRow(${paymentCounter})">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    document.getElementById('paymentsBody').appendChild(row);
    updatePaymentSummary();
}

function removePaymentRow(rowId) {
    const row = document.getElementById(`payment-${rowId}`);
    if (row) {
        row.remove();
        updatePaymentSummary();
    }
}

function updatePaymentSummary() {
    const rows = document.querySelectorAll('#paymentsBody tr');
    let totalPaid = 0;
    rows.forEach(row => {
        const rowId = parseInt(row.id.split('-')[1]);
        const amount = Math.max(parseFloat(document.getElementById(`payment-amount-${rowId}`)?.value) || 0, 0);
        totalPaid += amount;
    });

    const due = Math.max(currentGrandTotal - totalPaid, 0);
    document.getElementById('summary-paid').textContent = `AED ${totalPaid.toFixed(2)}`;
    document.getElementById('summary-due').textContent = `AED ${due.toFixed(2)}`;
}

document.getElementById('purchaseDiscount').addEventListener('input', updateSummary);

document.getElementById('purchaseForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const itemRows = document.querySelectorAll('#itemsBody tr');
    const formItems = [];

    itemRows.forEach(row => {
        const rowId = parseInt(row.id.split('-')[1]);
        const selectEl = row.querySelector('select');
        const productId = selectEl.value;
        if (!productId) {
            return;
        }
        const values = getLineValues(rowId);
        if (values.qty <= 0 || values.rate <= 0) {
            return;
        }

        formItems.push({
            product_id: productId,
            quantity: values.qty,
            rate: values.rate,
            batch_no: document.getElementById(`batch-${rowId}`)?.value || '',
            expiry_date: document.getElementById(`expiry-${rowId}`)?.value || '',
            discount_pct: values.discountPct,
            discount_value: parseFloat(document.getElementById(`discount-value-${rowId}`)?.value) || values.discountValue,
            vat_pct: values.vatPct,
            vat_value: parseFloat(document.getElementById(`vat-value-${rowId}`)?.value) || values.vatValue,
            total_amount: values.subtotal,
            line_total: values.lineTotal
        });
    });

    if (formItems.length === 0) {
        Swal.fire('Error', 'Please add at least one item to the purchase.', 'error');
        return;
    }

    const paymentRows = document.querySelectorAll('#paymentsBody tr');
    const payments = [];
    let totalPaid = 0;

    paymentRows.forEach(row => {
        const rowId = parseInt(row.id.split('-')[1]);
        const method = document.getElementById(`payment-method-${rowId}`)?.value || 'cash';
        const amount = Math.max(parseFloat(document.getElementById(`payment-amount-${rowId}`)?.value) || 0, 0);
        if (amount > 0) {
            payments.push({ method, amount });
            totalPaid += amount;
        }
    });

    if (totalPaid > currentGrandTotal + 0.01) {
        Swal.fire('Error', 'Paid amount cannot exceed the grand total.', 'error');
        return;
    }

    document.getElementById('itemsJson').value = JSON.stringify(formItems);
    document.getElementById('paymentsJson').value = JSON.stringify(payments);
    this.submit();
});

window.addEventListener('DOMContentLoaded', function() {
    addItemRow();
    addPaymentRow();
    const chalanInput = document.getElementById('chalan_no');
    if (chalanInput) {
        chalanInput.readOnly = true;
        chalanInput.classList.add('bg-gray-100', 'cursor-not-allowed');
    }
});
</script>

<style>
.form-control {
    width: 100%;
    padding: 0.5rem;
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    font-size: 0.875rem;
}

.form-control:focus {
    outline: none;
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}
</style>
