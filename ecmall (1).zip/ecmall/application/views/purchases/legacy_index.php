<?php card_start('Legacy Purchases'); ?>
<div class="flex justify-between items-center">
    <form method="get" class="flex gap-2">
        <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search doc/bill/supplier" class="form-control">
        <button type="submit" class="btn btn-primary">Search</button>
    </form>
    <a href="<?php echo base_url('legacy_purchase/form'); ?>" class="btn btn-success">
        <i class="fas fa-plus"></i> Add Purchase
    </a>
</div>
<?php card_end(); ?>

<?php card_start(''); ?>
    <div class="overflow-x-auto">
        <?php table_start(['Doc No', 'Bill No', 'Supplier', 'Date', 'Bill Amount', 'Paid', 'Net', 'Status', 'Actions']); ?>
            <?php if (empty($purchases)): ?>
                <tr>
                    <td colspan="9" class="text-center py-6 text-gray-500">No purchases found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($purchases as $purchase): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($purchase->docno); ?></td>
                        <td><?php echo htmlspecialchars($purchase->billno); ?></td>
                        <td><?php echo htmlspecialchars($purchase->name); ?></td>
                        <td><?php echo format_date($purchase->tdate); ?></td>
                        <td><?php echo format_currency($purchase->billamt); ?></td>
                        <td><?php echo format_currency($purchase->pamt); ?></td>
                        <td><?php echo format_currency($purchase->netamt); ?></td>
                        <td>
                            <?php
                            switch ($purchase->status) {
                                case 3:
                                    echo badge('Paid', 'success');
                                    break;
                                case 2:
                                    echo badge('Partial', 'warning');
                                    break;
                                default:
                                    echo badge('Credit', 'danger');
                            }
                            ?>
                        </td>
                        <td>
                            <a href="<?php echo base_url('legacy_purchase/form/' . $purchase->slno); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php table_end(); ?>
    </div>
<?php card_end(); ?>

<?php render_pagination($pagination, 'legacy_purchase', ['search' => $search]); ?>
