<?php card_start($page_title, false, ''); ?>
<div class="space-y-4">
    <?php if ($this->session->flashdata('error')): ?>
        <div class="p-3 rounded bg-red-50 text-red-700"><?php echo $this->session->flashdata('error'); ?></div>
    <?php endif; ?>
    <?php if ($this->session->flashdata('success')): ?>
        <div class="p-3 rounded bg-green-50 text-green-700"><?php echo $this->session->flashdata('success'); ?></div>
    <?php endif; ?>

    <?php echo form_open('', ['id' => 'legacyPurchaseForm']); ?>
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 bg-gray-50 p-4 rounded">
        <div class="space-y-3">
            <label class="block text-sm text-gray-600">Doc No.</label>
            <input type="text" name="docno" class="form-control" readonly value="<?php echo htmlspecialchars($purchase['docno']); ?>">

            <label class="block text-sm text-gray-600">Bill No.</label>
            <input type="text" name="billno" class="form-control" value="<?php echo htmlspecialchars($purchase['billno']); ?>">

            <label class="block text-sm text-gray-600">Date</label>
            <input type="date" name="date" class="form-control" value="<?php echo htmlspecialchars($purchase['tdate']); ?>">

            <label class="block text-sm text-gray-600">Supplier Code</label>
            <input type="text" name="suppcode" class="form-control" value="<?php echo htmlspecialchars($purchase['suppcode']); ?>">

            <label class="block text-sm text-gray-600">Supplier Name</label>
            <input type="text" name="suppname" class="form-control" value="<?php echo htmlspecialchars($purchase['name']); ?>">

            <label class="block text-sm text-gray-600">Address</label>
            <input type="text" name="addr" class="form-control" value="<?php echo htmlspecialchars($purchase['addr']); ?>">
        </div>

        <div class="space-y-3">
            <label class="block text-sm text-gray-600">Mobile</label>
            <input type="text" name="mobile" class="form-control" value="<?php echo htmlspecialchars($purchase['mobile']); ?>">

            <label class="block text-sm text-gray-600">PAN/Aadhar</label>
            <input type="text" name="pan" class="form-control" value="<?php echo htmlspecialchars($purchase['pan']); ?>">

            <label class="block text-sm text-gray-600">Bill Type</label>
            <input type="text" name="billtype" class="form-control" value="<?php echo htmlspecialchars($purchase['billtype']); ?>">

            <label class="block text-sm text-gray-600">State Code</label>
            <input type="text" name="statecode" class="form-control" value="<?php echo htmlspecialchars($purchase['statecode']); ?>">

            <label class="block text-sm text-gray-600">Counter</label>
            <input type="text" name="counter" class="form-control" value="<?php echo htmlspecialchars($purchase['counter']); ?>">

            <label class="block text-sm text-gray-600">Duedate</label>
            <input type="date" name="duedate" class="form-control" value="<?php echo htmlspecialchars($purchase['duedate']); ?>">
        </div>
    </div>

    <h3 class="text-lg font-semibold mt-6">Items</h3>
    <div class="overflow-x-auto">
        <table class="table table-bordered" id="legacyItemsTable">
            <thead>
                <tr>
                    <th>Item Code</th>
                    <th>Qty</th>
                    <th>Rate</th>
                    <th>Amount</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($items)): ?>
                    <?php foreach ($items as $idx => $item): ?>
                        <tr>
                            <td><input type="text" name="items[<?php echo $idx; ?>][code]" value="<?php echo htmlspecialchars($item['code']); ?>" class="form-control"></td>
                            <td><input type="number" step="0.01" name="items[<?php echo $idx; ?>][qty]" value="<?php echo htmlspecialchars($item['qty']); ?>" class="form-control qty" oninput="legacyCalculateRow(this)"></td>
                            <td><input type="number" step="0.01" name="items[<?php echo $idx; ?>][rate]" value="<?php echo htmlspecialchars($item['rate']); ?>" class="form-control rate" oninput="legacyCalculateRow(this)"></td>
                            <td><input type="number" step="0.01" name="items[<?php echo $idx; ?>][amount]" value="<?php echo htmlspecialchars($item['amount']); ?>" class="form-control amount" readonly></td>
                            <td><button type="button" class="btn btn-danger btn-sm" onclick="legacyRemoveRow(this)">Delete</button></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td><input type="text" name="items[0][code]" class="form-control"></td>
                        <td><input type="number" step="0.01" name="items[0][qty]" class="form-control qty" oninput="legacyCalculateRow(this)"></td>
                        <td><input type="number" step="0.01" name="items[0][rate]" class="form-control rate" oninput="legacyCalculateRow(this)"></td>
                        <td><input type="number" step="0.01" name="items[0][amount]" class="form-control amount" readonly></td>
                        <td><button type="button" class="btn btn-danger btn-sm" onclick="legacyRemoveRow(this)">Delete</button></td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <button type="button" class="btn btn-success" onclick="legacyAddRow()">Add Item</button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        <div class="space-y-2">
            <label class="block text-sm text-gray-600">Bill Total</label>
            <input type="number" step="0.01" id="legacy-billtotal" name="billtotal" class="form-control" value="<?php echo htmlspecialchars($purchase['billamt']); ?>" readonly>

            <label class="block text-sm text-gray-600">Discount %</label>
            <input type="number" step="0.01" id="legacy-discperc" name="discperc" class="form-control" value="<?php echo htmlspecialchars($purchase['discperc']); ?>" oninput="legacyTotals()">

            <label class="block text-sm text-gray-600">Tax %</label>
            <input type="number" step="0.01" id="legacy-taxperc" name="taxperc" class="form-control" value="<?php echo htmlspecialchars($purchase['taxperc']); ?>" oninput="legacyTotals()">

            <label class="block text-sm text-gray-600">TCS %</label>
            <input type="number" step="0.01" id="legacy-tcsperc" name="tcsperc" class="form-control" value="<?php echo htmlspecialchars($purchase['tcsperc']); ?>" oninput="legacyTotals()">

            <label class="block text-sm text-gray-600">Others (Charges)</label>
            <input type="number" step="0.01" id="legacy-others" name="others" class="form-control" value="<?php echo htmlspecialchars($purchase['addamt']); ?>" oninput="legacyTotals()">
        </div>

        <div class="space-y-2">
            <label class="block text-sm text-gray-600">Discount</label>
            <input type="number" step="0.01" id="legacy-discount" name="discount" class="form-control" value="<?php echo htmlspecialchars($purchase['discount']); ?>" readonly>

            <label class="block text-sm text-gray-600">Tax</label>
            <input type="number" step="0.01" id="legacy-tax" name="tax" class="form-control" value="<?php echo htmlspecialchars($purchase['taxamt']); ?>" readonly>

            <label class="block text-sm text-gray-600">TCS Amount</label>
            <input type="number" step="0.01" id="legacy-tcsamt" name="tcsamt" class="form-control" value="<?php echo htmlspecialchars($purchase['tcsamt']); ?>" readonly>

            <label class="block text-sm text-gray-600">Net Total</label>
            <input type="number" step="0.01" id="legacy-nettot" name="nettot" class="form-control" value="<?php echo htmlspecialchars($purchase['netamt']); ?>" readonly>

            <label class="block text-sm text-gray-600">Paid Amount</label>
            <input type="number" step="0.01" id="legacy-paid" name="pamt" class="form-control" value="<?php echo htmlspecialchars($purchase['pamt']); ?>" oninput="legacyTotals()">

            <label class="block text-sm text-gray-600">Balance</label>
            <input type="number" step="0.01" id="legacy-balance" name="balance" class="form-control" value="<?php echo htmlspecialchars(($purchase['netamt'] + $purchase['addamt']) - $purchase['pamt']); ?>" readonly>
        </div>
    </div>

    <div class="flex gap-3 mt-6">
        <button type="submit" class="btn btn-primary">Save</button>
        <a href="<?php echo base_url('legacy_purchase'); ?>" class="btn btn-secondary">Cancel</a>
    </div>
    <?php echo form_close(); ?>
</div>
<?php card_end(); ?>

<script>
function legacyCalculateRow(el) {
    const row = el.closest('tr');
    const qty = parseFloat(row.querySelector('.qty').value) || 0;
    const rate = parseFloat(row.querySelector('.rate').value) || 0;
    row.querySelector('.amount').value = (qty * rate).toFixed(2);
    legacyTotals();
}

function legacyAddRow() {
    const tbody = document.querySelector('#legacyItemsTable tbody');
    const idx = tbody.querySelectorAll('tr').length;
    const tr = document.createElement('tr');
    tr.innerHTML = `
        <td><input type="text" name="items[${idx}][code]" class="form-control"></td>
        <td><input type="number" step="0.01" name="items[${idx}][qty]" class="form-control qty" oninput="legacyCalculateRow(this)"></td>
        <td><input type="number" step="0.01" name="items[${idx}][rate]" class="form-control rate" oninput="legacyCalculateRow(this)"></td>
        <td><input type="number" step="0.01" name="items[${idx}][amount]" class="form-control amount" readonly></td>
        <td><button type="button" class="btn btn-danger btn-sm" onclick="legacyRemoveRow(this)">Delete</button></td>
    `;
    tbody.appendChild(tr);
}

function legacyRemoveRow(btn) {
    const tbody = document.querySelector('#legacyItemsTable tbody');
    if (tbody.querySelectorAll('tr').length > 1) {
        btn.closest('tr').remove();
        legacyTotals();
    }
}

function legacyTotals() {
    let total = 0;
    document.querySelectorAll('#legacyItemsTable .amount').forEach(el => {
        total += parseFloat(el.value) || 0;
    });
    const discPerc = parseFloat(document.getElementById('legacy-discperc').value) || 0;
    const taxPerc = parseFloat(document.getElementById('legacy-taxperc').value) || 0;
    const tcsPerc = parseFloat(document.getElementById('legacy-tcsperc').value) || 0;
    const others = parseFloat(document.getElementById('legacy-others').value) || 0;
    const paid = parseFloat(document.getElementById('legacy-paid').value) || 0;

    const discount = (total * discPerc) / 100;
    const taxBase = total - discount;
    const tax = (taxBase * taxPerc) / 100;
    const tcs = (taxBase * tcsPerc) / 100;
    const nettot = total - discount + tax + tcs;
    const balance = nettot + others - paid;

    document.getElementById('legacy-billtotal').value = total.toFixed(2);
    document.getElementById('legacy-discount').value = discount.toFixed(2);
    document.getElementById('legacy-tax').value = tax.toFixed(2);
    document.getElementById('legacy-tcsamt').value = tcs.toFixed(2);
    document.getElementById('legacy-nettot').value = nettot.toFixed(2);
    document.getElementById('legacy-balance').value = balance.toFixed(2);
}

document.addEventListener('DOMContentLoaded', legacyTotals);
</script>
