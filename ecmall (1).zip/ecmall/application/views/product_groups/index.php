<?php card_start('Product Groups', true); ?>

<div class="flex justify-between items-center mb-6">
    <form method="get" action="<?php echo base_url('product_groups'); ?>" class="flex gap-2">
        <input type="text"
               name="search"
               value="<?php echo htmlspecialchars($search); ?>"
               placeholder="Search groups..."
               class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500">
        <button type="submit" class="btn btn-secondary">
            <i class="fas fa-search"></i> Search
        </button>
        <?php if ($search): ?>
            <a href="<?php echo base_url('product_groups'); ?>" class="btn btn-outline">
                <i class="fas fa-times"></i> Clear
            </a>
        <?php endif; ?>
    </form>

    <div class="flex gap-2">
        <a href="<?php echo base_url('product_groups/add'); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i> Add Group
        </a>
    </div>
</div>

<div class="overflow-x-auto">
    <?php table_start(['#', 'Code', 'Group Name', 'Category', 'Products', 'Status', 'Actions']); ?>
        <?php if (empty($groups)): ?>
            <tr>
                <td colspan="6" class="text-center py-8 text-gray-500">
                    <i class="fas fa-layer-group text-4xl mb-2"></i>
                    <p>No groups found.</p>
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($groups as $group): ?>
                <?php
                $this->db->where('group_id', $group->id);
                $product_count = $this->db->count_all_results('product_information');
                ?>
                <tr>
                    <td><?php echo $group->id; ?></td>
                    <td><code class="bg-gray-100 px-2 py-1 rounded"><?php echo htmlspecialchars($group->group_code); ?></code></td>
                    <td><strong><?php echo htmlspecialchars($group->group_name); ?></strong></td>
                    <td><?php echo htmlspecialchars($group->category_name ?? 'Unassigned'); ?></td>
                    <td>
                        <?php if ($product_count > 0): ?>
                            <span class="badge badge-info"><?php echo $product_count; ?> products</span>
                        <?php else: ?>
                            <span class="text-gray-500">No products</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $group->status ? status_badge('active', 'Active') : status_badge('inactive', 'Inactive'); ?>
                    </td>
                    <td>
                        <div class="flex gap-2">
                            <a href="<?php echo base_url('product_groups/edit/' . $group->id); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button class="btn btn-sm btn-danger"
                                    onclick="confirmDelete(<?php echo $group->id; ?>, '<?php echo addslashes($group->group_name); ?>', <?php echo $product_count; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php table_end(); ?>
</div>

<?php if ($pagination->total_pages > 1): ?>
    <div class="mt-4">
        <?php echo render_pagination($pagination, 'product_groups'); ?>
    </div>
<?php endif; ?>

<?php card_end(); ?>

<script>
function confirmDelete(id, name, products) {
    if (products > 0) {
        Swal.fire('Action blocked', 'This group is linked to existing products.', 'error');
        return;
    }
    Swal.fire({
        title: 'Delete Group?',
        text: `Remove "${name}" permanently?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#EF4444'
    }).then(result => {
        if (result.isConfirmed) {
            window.location.href = `<?php echo base_url('product_groups/delete/'); ?>${id}`;
        }
    });
}
</script>
