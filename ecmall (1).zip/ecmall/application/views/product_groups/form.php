<?php
$is_edit = !empty($group);
?>

<?php card_start($is_edit ? 'Edit Product Group' : 'Add Product Group'); ?>

<form method="post" class="space-y-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="form-label">Group Name</label>
            <input type="text" name="group_name" class="form-input" value="<?php echo set_value('group_name', $group->group_name ?? ''); ?>" required>
        </div>
        <div>
            <label class="form-label">Group Code</label>
            <input type="text" name="group_code" class="form-input uppercase" value="<?php echo set_value('group_code', $group->group_code ?? ''); ?>" required>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select">
                <option value="">Unassigned</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category->category_id; ?>" <?php echo set_select('category_id', $category->category_id, ($group->category_id ?? null) == $category->category_id); ?>>
                        <?php echo htmlspecialchars($category->category_name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="flex items-center gap-2">
            <label class="form-label mb-0">Active</label>
            <label class="switch">
                <input type="checkbox" name="status" value="1" <?php echo set_checkbox('status', '1', ($group->status ?? 1) == 1); ?>>
                <span class="slider"></span>
            </label>
        </div>
    </div>

    <div>
        <label class="form-label">Description</label>
        <textarea name="description" rows="4" class="form-input"><?php echo set_value('description', $group->description ?? ''); ?></textarea>
    </div>

    <div class="flex justify-end gap-2 pt-4 border-t">
        <a href="<?php echo base_url('product_groups'); ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><?php echo $is_edit ? 'Update' : 'Save'; ?></button>
    </div>
</form>

<?php card_end(); ?>
