<?php
$types = $types ?? [];
$active_type = $active_type ?? 'customer';
$search = $search ?? '';
$clients = $clients ?? [];
$pagination = $pagination ?? (object) ['total' => 0, 'per_page' => 25, 'current_page' => 1, 'total_pages' => 1];
?>

<div class="page-header mb-8">
    <div>
        <h1 class="page-title">Client Directory</h1>
        <p class="text-gray-600 mt-1">Unified maintenance console for customers, suppliers, staff, agents and brokers.</p>
    </div>
    <div class="flex items-center gap-3">
        <a href="<?php echo base_url('clients/form/' . $active_type); ?>" class="btn btn-primary">
            <i class="fas fa-plus"></i>
            Add <?php echo htmlspecialchars($types[$active_type]['singular'] ?? 'Client'); ?>
        </a>
    </div>
</div>

<div class="mb-6">
    <div class="flex flex-wrap gap-2">
        <?php foreach ($types as $key => $meta): ?>
            <a href="<?php echo base_url('clients?type=' . $key); ?>"
               class="px-4 py-2 rounded-full text-sm font-semibold <?php echo $key === $active_type ? 'bg-primary-600 text-white' : 'bg-gray-100 text-gray-600'; ?>">
                <?php echo htmlspecialchars($meta['label']); ?>
            </a>
        <?php endforeach; ?>
    </div>
</div>

<div class="card mb-6">
    <div class="card-body">
        <form method="get" action="<?php echo base_url('clients'); ?>" class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <input type="hidden" name="type" value="<?php echo htmlspecialchars($active_type); ?>">
            <div class="md:col-span-2">
                <label class="form-label">Search</label>
                <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Name, code, mobile or email" class="form-input">
            </div>
            <div class="md:col-span-1 flex items-end gap-2">
                <button class="btn btn-primary w-full">
                    <i class="fas fa-search"></i>
                    Search
                </button>
                <?php if ($search): ?>
                    <a class="btn btn-outline" href="<?php echo base_url('clients?type=' . $active_type); ?>">
                        Clear
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-body p-0">
        <?php if (empty($clients)): ?>
            <div class="p-10 text-center text-gray-500">
                <i class="fas fa-address-card text-5xl mb-4"></i>
                <p>No records found for this selection.</p>
            </div>
        <?php else: ?>
            <div class="overflow-x-auto">
                <table class="table">
                    <thead>
                    <tr>
                        <th>Code</th>
                        <th>Name</th>
                        <th>Contact</th>
                        <th>City</th>
                        <th class="text-right">Balance</th>
                        <th class="text-center">Actions</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($clients as $client): ?>
                        <tr>
                            <td class="font-semibold"><?php echo htmlspecialchars($client->code); ?></td>
                            <td><?php echo htmlspecialchars($client->name); ?></td>
                            <td>
                                <?php if (!empty($client->mobile)): ?>
                                    <div class="text-gray-900"><?php echo htmlspecialchars($client->mobile); ?></div>
                                <?php endif; ?>
                                <?php if (!empty($client->email)): ?>
                                    <div class="text-gray-500 text-sm"><?php echo htmlspecialchars($client->email); ?></div>
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($client->city ?? ''); ?></td>
                            <td class="text-right">
                                <?php
                                $balance = $client->balance ?? 0;
                                $badgeClass = $balance >= 0 ? 'text-success-600' : 'text-danger-600';
                                ?>
                                <span class="<?php echo $badgeClass; ?>">
                                    <?php echo format_currency(abs($balance)); ?> <?php echo $balance >= 0 ? 'Cr' : 'Dr'; ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <div class="flex justify-center gap-2">
                                    <a class="btn btn-sm btn-outline" href="<?php echo base_url('clients/form/' . $active_type . '/' . rawurlencode($client->code)); ?>">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger" onclick="return confirmDelete('<?php echo base_url('clients/delete/' . $active_type . '/' . rawurlencode($client->code)); ?>');">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="px-6 py-4 border-t border-gray-200">
                <?php echo render_pagination($pagination, 'clients', ['type' => $active_type, 'search' => $search]); ?>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
function confirmDelete(url) {
    if (!window.confirm('Delete this client? This action cannot be undone.')) {
        return false;
    }
    window.location.href = url;
    return true;
}
</script>
