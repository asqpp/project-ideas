<?php
$types = $types ?? [];
$active_type = $active_type ?? 'customer';
$meta = $types[$active_type];
$client = $client ?? [];
$address = $client['address'] ?? [];
$advanced = $client['advanced'] ?? [];
$advanced['vat_no'] = $advanced['vat_no'] ?? ($advanced['gstin'] ?? '');
$advanced['cr_no'] = $advanced['cr_no'] ?? ($advanced['cst'] ?? '');
$advanced['fax'] = $advanced['fax'] ?? ($client['fax'] ?? '');
$advanced['contact_person'] = $advanced['contact_person'] ?? ($client['contact_person'] ?? '');
$auto = $auto_code ?? ['enabled' => false, 'prefix' => '', 'next' => 1, 'padding' => 4];
$is_edit = !empty($client['record_id']);
$is_advanced_user = !empty($is_advanced_user);

function client_value($client, $key, $default = '')
{
    return htmlspecialchars($client[$key] ?? $default);
}

function client_adv(array $advanced, string $key, $default = '')
{
    return htmlspecialchars($advanced[$key] ?? $default);
}

$labelSets = [
    'customer' => [
        'name' => 'Customer Name',
        'mobile' => 'Mobile No',
        'email' => 'Email Address',
        'salesman' => 'Salesman Code'
    ],
    'supplier' => [
        'name' => 'Supplier Name',
        'mobile' => 'Mobile No',
        'email' => 'Email Address',
        'salesman' => 'Salesman Code'
    ],
    'agent' => [
        'name' => 'Agent Name',
        'mobile' => 'Mobile No',
        'email' => 'Email Address',
        'salesman' => 'Salesman Code'
    ],
    'broker' => [
        'name' => 'Broker Name',
        'mobile' => 'Mobile No',
        'email' => 'Email Address',
        'salesman' => 'Salesman Code'
    ],
    'staff' => [
        'name' => 'Staff Name',
        'mobile' => 'Mobile No',
        'email' => 'Email Address',
        'salesman' => 'Supervisor Code'
    ]
];
$activeLabels = $labelSets[$active_type] ?? [
    'name' => 'Client Name',
    'mobile' => 'Mobile',
    'email' => 'Email',
    'salesman' => 'Salesman Code'
];

function client_label(array $labels, string $key, string $default)
{
    return htmlspecialchars($labels[$key] ?? $default);
}
?>

<div class="page-header mb-8">
    <div>
        <a href="<?php echo base_url('clients?type=' . $active_type); ?>" class="text-primary-600 hover:underline flex items-center gap-2 mb-2">
            <i class="fas fa-arrow-left"></i> Back to <?php echo htmlspecialchars($meta['label']); ?>
        </a>
        <h1 class="page-title"><?php echo $is_edit ? 'Edit ' : 'Add '; ?><?php echo htmlspecialchars($meta['singular']); ?></h1>
        <p class="text-gray-600">PowerBuilder-inspired maintenance form with financial and account controls.</p>
    </div>
</div>

<?php if ($this->session->flashdata('error')): ?>
    <div class="alert alert-danger mb-4">
        <i class="fas fa-exclamation-circle"></i>
        <div class="flex-1"><?php echo $this->session->flashdata('error'); ?></div>
    </div>
<?php endif; ?>
<?php if ($this->session->flashdata('success')): ?>
    <div class="alert alert-success mb-4">
        <i class="fas fa-check-circle"></i>
        <div class="flex-1"><?php echo $this->session->flashdata('success'); ?></div>
    </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data">
    <input type="hidden" name="record_id" value="<?php echo htmlspecialchars($client['record_id'] ?? ''); ?>">
    <div class="grid grid-cols-1 xl:grid-cols-3 gap-6">
        <div class="xl:col-span-2 space-y-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Core Information</h3>
                </div>
                <div class="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label flex items-center gap-2">
                            Client Code
                            <?php if (!empty($meta['auto_code']) && !empty($auto['enabled']) && !$is_edit): ?>
                                <span class="badge badge-outline">Auto</span>
                            <?php endif; ?>
                        </label>
                        <input type="text" name="code" value="<?php echo client_value($client, 'code'); ?>" class="form-input" <?php echo ($is_edit && !empty($meta['auto_code'])) ? 'readonly' : ''; ?>>
                        <?php if (!empty($meta['auto_code'])): ?>
                            <p class="text-xs text-gray-500 mt-1">
                                Prefix <?php echo htmlspecialchars($auto['prefix'] ?? ''); ?> / Next <?php echo htmlspecialchars($auto['next'] ?? 1); ?>
                            </p>
                        <?php endif; ?>
                    </div>
                    <div>
                        <label class="form-label"><?php echo client_label($activeLabels, 'name', 'Client Name'); ?></label>
                        <input type="text" name="name" value="<?php echo client_value($client, 'name'); ?>" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label"><?php echo client_label($activeLabels, 'salesman', 'Salesman Code'); ?></label>
                        <input type="text" name="salesman" value="<?php echo client_adv($advanced, 'salesman'); ?>" class="form-input" required>
                    </div>
                    <div>
                        <label class="form-label">Reference Date</label>
                        <input type="date" name="date" value="<?php echo client_adv($advanced['dates'] ?? [], 'reference_date'); ?>" class="form-input">
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Address & Contact</h3>
                </div>
                <div class="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Address Line 1</label>
                        <input type="text" name="addr1" value="<?php echo htmlspecialchars($address['addr1'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Address Line 2</label>
                        <input type="text" name="addr2" value="<?php echo htmlspecialchars($address['addr2'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Address Line 3</label>
                        <input type="text" name="addr3" value="<?php echo htmlspecialchars($address['addr3'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">City</label>
                        <input type="text" name="city" value="<?php echo htmlspecialchars($address['city'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">State</label>
                        <input type="text" name="state" value="<?php echo htmlspecialchars($address['state'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">PIN / Postal Code</label>
                        <input type="text" name="pin" value="<?php echo htmlspecialchars($address['pin'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Country</label>
                        <input type="text" name="country" value="<?php echo htmlspecialchars($address['country'] ?? ''); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Route</label>
                        <input type="text" name="route" value="<?php echo client_adv($advanced, 'route'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Area</label>
                        <input type="text" name="area" value="<?php echo client_adv($advanced, 'area'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Phone</label>
                        <input type="text" name="phone" value="<?php echo client_value($client, 'phone'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label"><?php echo client_label($activeLabels, 'mobile', 'Mobile'); ?></label>
                        <input type="text" name="mobile" value="<?php echo client_value($client, 'mobile'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label"><?php echo client_label($activeLabels, 'email', 'Email'); ?></label>
                        <input type="email" name="email" value="<?php echo client_value($client, 'email'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Contact</label>
                        <input type="text" name="contact_person" value="<?php echo client_value($client, 'contact_person'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">VAT No</label>
                        <input type="text" name="vat_no" value="<?php echo client_adv($advanced, 'vat_no'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label"><?php echo $active_type === 'staff' ? 'Home Mobile' : 'CR No'; ?></label>
                        <input type="text" name="cr_no" value="<?php echo client_adv($advanced, 'cr_no'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Fax</label>
                        <input type="text" name="fax" value="<?php echo client_value($client, 'fax'); ?>" class="form-input">
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Financial & Account Mapping</h3>
                </div>
                <div class="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">Opening Balance</label>
                        <div class="flex gap-2">
                            <input type="number" step="0.01" name="opening_balance" value="<?php echo htmlspecialchars($client['opening_balance'] ?? 0); ?>" class="form-input">
                            <select name="balance_type" class="form-select w-24">
                                <option value="dr" <?php echo (($client['balance_type'] ?? '') === 'dr') ? 'selected' : ''; ?>>Dr</option>
                                <option value="cr" <?php echo (($client['balance_type'] ?? '') !== 'dr') ? 'selected' : ''; ?>>Cr</option>
                            </select>
                        </div>
                    </div>
                    <?php if ($is_advanced_user): ?>
                        <div>
                            <label class="form-label">Secondary Balance</label>
                            <div class="flex gap-2">
                                <input type="number" step="0.01" name="secondary_balance" value="<?php echo htmlspecialchars($client['secondary_balance'] ?? 0); ?>" class="form-input">
                                <select name="secondary_balance_type" class="form-select w-24">
                                    <option value="dr" <?php echo (($client['secondary_balance_type'] ?? '') === 'dr') ? 'selected' : ''; ?>>Dr</option>
                                    <option value="cr" <?php echo (($client['secondary_balance_type'] ?? '') !== 'dr') ? 'selected' : ''; ?>>Cr</option>
                                </select>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div>
                        <label class="form-label">Account Group</label>
                        <select name="account_group" class="form-select">
                            <option value="">Select group</option>
                            <?php foreach ($groups as $group): ?>
                                <option value="<?php echo htmlspecialchars($group->grcode); ?>" <?php echo (($advanced['account_group'] ?? $meta['group']) === $group->grcode) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($group->grcode . ' - ' . $group->name); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">BS Head</label>
                        <select name="bshead" class="form-select">
                            <option value="">Select head</option>
                            <?php foreach ($heads as $head): ?>
                                <option value="<?php echo htmlspecialchars($head->hcode); ?>" <?php echo (($advanced['bshead'] ?? $meta['bshead']) === $head->hcode) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($head->hcode . ' - ' . $head->hname); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="form-label">PAN / Aadhar</label>
                        <input type="text" name="pan" value="<?php echo client_adv($advanced, 'pan'); ?>" class="form-input">
                    </div>
                    <div>
                        <label class="form-label">Distance (KM)</label>
                        <input type="number" step="0.1" name="distance" value="<?php echo client_adv($advanced, 'distance'); ?>" class="form-input">
                    </div>
                </div>
            </div>

            <?php if ($active_type === 'customer'): ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Customer Specific</h3>
                    </div>
                    <div class="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Care-of Code</label>
                            <input type="text" name="care_of_code" value="<?php echo client_adv($advanced, 'care_of_code'); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Previous Card Type</label>
                            <input type="text" name="card_type" value="<?php echo client_adv($advanced, 'card_type'); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Card Number</label>
                            <input type="text" name="card_number" value="<?php echo client_adv($advanced, 'card_number'); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Card Points</label>
                            <input type="number" step="0.01" name="card_points" value="<?php echo client_adv($advanced, 'card_points'); ?>" class="form-input">
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if ($active_type === 'staff'): ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Staff Properties</h3>
                    </div>
                    <div class="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Salary</label>
                            <input type="number" step="0.01" name="salary" value="<?php echo htmlspecialchars($client['salary'] ?? ($advanced['salary'] ?? '')); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Cut Rate</label>
                            <input type="number" step="0.01" name="cut_rate" value="<?php echo htmlspecialchars($advanced['commissions']['cut_rate'] ?? ''); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Commission %</label>
                            <input type="number" step="0.01" name="staff_commission" value="<?php echo htmlspecialchars($advanced['commissions']['staff_commission'] ?? ''); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">ID Number</label>
                            <input type="text" name="id_number" value="<?php echo htmlspecialchars($advanced['id_number'] ?? ''); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">POS Password</label>
                            <input type="text" name="pos_password" value="<?php echo htmlspecialchars($advanced['pos_password'] ?? ''); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Approval Authority</label>
                            <input type="text" name="approval_authority" value="<?php echo htmlspecialchars($advanced['approval'] ?? ''); ?>" class="form-input">
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <?php if (in_array($active_type, ['agent', 'broker'], true)): ?>
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Commission & Contract</h3>
                    </div>
                    <div class="card-body grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">Commission Percentage</label>
                            <input type="number" step="0.01" name="commission_pct" value="<?php echo htmlspecialchars($advanced['commissions']['percentage'] ?? ''); ?>" class="form-input">
                        </div>
                        <div>
                            <label class="form-label">Contract Date</label>
                            <input type="date" name="contract_date" value="<?php echo htmlspecialchars(($advanced['dates']['contract_date'] ?? '')); ?>" class="form-input">
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Notes</h3>
                </div>
                <div class="card-body">
                    <textarea name="notes" rows="4" class="form-input"><?php echo htmlspecialchars($client['notes'] ?? ($advanced['notes'] ?? '')); ?></textarea>
                </div>
            </div>
        </div>

        <div class="space-y-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Photo</h3>
                </div>
                <div class="card-body space-y-4">
                    <?php if (!empty($client['photo'])): ?>
                        <div class="flex items-center gap-4">
                            <img src="data:<?php echo htmlspecialchars($client['photo_mime'] ?? 'image/jpeg'); ?>;base64,<?php echo $client['photo']; ?>" alt="Client Photo" class="w-32 h-32 rounded object-cover border">
                            <span class="text-sm text-gray-500">Existing photo</span>
                        </div>
                    <?php endif; ?>
                    <div>
                        <label class="form-label">Upload Photo</label>
                        <input type="file" name="photo" accept="image/*" class="form-input">
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Flags & Options</h3>
                </div>
                <div class="card-body grid grid-cols-1 gap-2">
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="display" <?php echo !empty($advanced['flags']['display']) ? 'checked' : ''; ?>>
                        Display in lookups
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="removed" <?php echo !empty($client['removed']) ? 'checked' : ''; ?>>
                        Mark as removed
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="blocked" <?php echo !empty($client['blocked']) ? 'checked' : ''; ?>>
                        Block transactions
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="care_of_party" <?php echo !empty($advanced['flags']['care_of_party']) ? 'checked' : ''; ?>>
                        Care-of party
                    </label>
                    <?php if ($active_type === 'staff'): ?>
                        <label class="flex items-center gap-2">
                            <input type="checkbox" name="staff_agent" <?php echo !empty($advanced['flags']['agent_staff']) ? 'checked' : ''; ?>>
                            Enable staff as agent
                        </label>
                    <?php endif; ?>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="link_phonebook" <?php echo !empty($advanced['link_phonebook']) ? 'checked' : ''; ?>>
                        Link to phonebook
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="print_card" <?php echo !empty($advanced['flags']['print_card']) ? 'checked' : ''; ?>>
                        Print previous card
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="show_camera" <?php echo !empty($advanced['flags']['show_camera']) ? 'checked' : ''; ?>>
                        Show camera on load
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="update_foreign" <?php echo !empty($advanced['flags']['update_foreign']) ? 'checked' : ''; ?>>
                        Update foreign systems
                    </label>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Actions</h3>
                </div>
                <div class="card-body flex flex-col gap-2">
                    <button class="btn btn-primary w-full">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                    <?php if ($is_edit): ?>
                        <a href="<?php echo base_url('clients/delete/' . $active_type . '/' . rawurlencode($client['code'] ?? '')); ?>" class="btn btn-danger w-full" onclick="return confirm('Delete this client?');">
                            <i class="fas fa-trash"></i> Delete
                        </a>
                    <?php endif; ?>
                    <a href="<?php echo base_url('clients?type=' . $active_type); ?>" class="btn btn-outline w-full">Cancel</a>
                </div>
            </div>
        </div>
    </div>
</form>
