<?php card_start('Document Numbers Configuration'); ?>
<p class="text-gray-600 mb-4">
    Adjust document counters and prefixes used across sales, purchases, returns, and voucher modules.
    Changes take effect immediately, so update them carefully.
</p>

<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">
    <div class="border rounded-lg p-4 bg-white">
        <h3 class="font-semibold text-lg mb-3">generali (Counters)</h3>
        <div class="space-y-2 max-h-[520px] overflow-y-auto">
            <?php foreach ($generali_codes as $code): ?>
                <label class="block text-sm font-medium text-gray-600 mb-1" for="doc-<?php echo $code; ?>">
                    <?php echo $code; ?>
                </label>
                <input type="number" step="1"
                       id="doc-<?php echo $code; ?>"
                       data-code="<?php echo $code; ?>"
                       data-table="generali"
                       class="form-control mb-2"
                       placeholder="Enter value">
            <?php endforeach; ?>
        </div>
    </div>

    <div class="border rounded-lg p-4 bg-white">
        <h3 class="font-semibold text-lg mb-3">generals (Prefixes / Lengths)</h3>
        <div class="space-y-2 max-h-[520px] overflow-y-auto">
            <?php foreach ($generals_codes as $code): ?>
                <label class="block text-sm font-medium text-gray-600 mb-1" for="doc-<?php echo $code; ?>">
                    <?php echo $code; ?>
                </label>
                <input type="text"
                       id="doc-<?php echo $code; ?>"
                       data-code="<?php echo $code; ?>"
                       data-table="generals"
                       class="form-control mb-2"
                       placeholder="Enter value">
            <?php endforeach; ?>
        </div>
    </div>
</div>

<div class="flex justify-end gap-3 mt-6">
    <button class="btn btn-outline" type="button" onclick="loadDocNumbers()">Reload</button>
    <button class="btn btn-primary" type="button" onclick="saveDocNumbers()">Save Changes</button>
</div>
<?php card_end(); ?>

<script>
const docNumbersApi = '<?php echo base_url('doc_numbers/api'); ?>';

function loadDocNumbers() {
    fetch(docNumbersApi)
        .then(res => res.json())
        .then(data => {
            Object.entries(data.generali || {}).forEach(([code, value]) => {
                const input = document.getElementById(`doc-${code}`);
                if (input) input.value = value ?? '';
            });
            Object.entries(data.generals || {}).forEach(([code, value]) => {
                const input = document.getElementById(`doc-${code}`);
                if (input) input.value = value ?? '';
            });
        })
        .catch(() => alert('Failed to load document numbers.'));
}

function saveDocNumbers() {
    const payload = { generali: {}, generals: {} };
    document.querySelectorAll('[data-table]').forEach(input => {
        const table = input.dataset.table;
        const code = input.dataset.code;
        payload[table][code] = input.value;
    });

    fetch(docNumbersApi, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
    })
        .then(res => res.json())
        .then(data => {
            if (data.error) throw new Error(data.error);
            alert('Document numbers updated successfully.');
        })
        .catch(err => alert(err.message || 'Failed to save document numbers.'));
}

document.addEventListener('DOMContentLoaded', loadDocNumbers);
</script>
