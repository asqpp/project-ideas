<?php card_start('User Access'); ?>
<div class="flex justify-between items-center mb-4">
    <div>
        <p class="text-gray-600">Manage ERP users and their menu permissions.</p>
    </div>
    <button class="btn btn-primary" onclick="openUserModal()">
        <i class="fas fa-user-plus mr-2"></i> Add User
    </button>
</div>

<div class="overflow-x-auto">
    <table class="table" id="userAccessTable">
        <thead>
            <tr>
                <th>Code</th>
                <th>Name</th>
                <th class="text-right">Actions</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="3" class="text-center text-gray-500 py-6">Loading users...</td>
            </tr>
        </tbody>
    </table>
</div>
<?php card_end(); ?>

<!-- Modal -->
<div id="userAccessModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center z-50">
    <div class="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto p-6">
        <div class="flex justify-between items-center mb-4">
            <h3 class="text-xl font-semibold" id="modalTitle">Add User</h3>
            <button class="text-gray-500 hover:text-gray-700" onclick="closeUserModal()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="userAccessForm" class="space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">User Code *</label>
                    <input type="text" name="code" id="userCode" class="form-control" required>
                </div>
                <div>
                    <label class="form-label">Name</label>
                    <input type="text" name="name" id="userName" class="form-control">
                </div>
                <div>
                    <label class="form-label">Password</label>
                    <input type="password" name="psw" id="userPassword" class="form-control" placeholder="Leave blank to keep existing">
                </div>
                <div>
                    <label class="form-label">Max Credit</label>
                    <input type="number" step="0.01" name="maxcredit" id="userMaxCredit" class="form-control">
                </div>
                <div>
                    <label class="form-label">Max Discount</label>
                    <input type="number" step="0.01" name="maxdisc" id="userMaxDisc" class="form-control">
                </div>
                <div>
                    <label class="form-label">Max Adj Wgt (BC)</label>
                    <input type="number" step="0.01" name="maxadjwgtbc" id="userMaxAdj" class="form-control">
                </div>
                <div>
                    <label class="form-label">Min VA %</label>
                    <input type="number" step="0.01" name="minvaperc" id="userMinVA" class="form-control">
                </div>
                <div>
                    <label class="form-label">Max Discount %</label>
                    <input type="number" step="0.01" name="maxdiscperc" id="userMaxDiscPerc" class="form-control">
                </div>
            </div>

            <div>
                <label class="form-label">Menu Items (one per line)</label>
                <textarea id="userMenuItems" class="form-control" rows="6" placeholder="Example:&#10;SALES_ADD&#10;PURCHASE_VIEW"></textarea>
                <p class="text-xs text-gray-500 mt-1">Jewellery-only menu keys are automatically filtered out.</p>
            </div>

            <div class="flex justify-between items-center mt-4">
                <button type="button" class="btn btn-danger hidden" id="deleteUserButton" onclick="deleteUser()">Delete User</button>
                <div class="ml-auto space-x-2">
                    <button type="button" class="btn btn-outline" onclick="closeUserModal()">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
const apiUrl = '<?php echo base_url('user_access/api'); ?>';
const tableBody = document.querySelector('#userAccessTable tbody');
const modal = document.getElementById('userAccessModal');
const form = document.getElementById('userAccessForm');
const deleteButton = document.getElementById('deleteUserButton');
let editingCode = null;

function openUserModal(code = null) {
    editingCode = code;
    document.getElementById('modalTitle').textContent = code ? `Edit User: ${code}` : 'Add User';
    deleteButton.classList.toggle('hidden', !code);
    form.reset();
    document.getElementById('userCode').readOnly = !!code;
    document.getElementById('userMenuItems').value = '';

    if (code) {
        fetch(`${apiUrl}?code=${encodeURIComponent(code)}`)
            .then(res => res.json())
            .then(data => {
                if (!data.user) throw new Error('User not found');
                const user = data.user;
                document.getElementById('userCode').value = user.code;
                document.getElementById('userName').value = user.name || '';
                document.getElementById('userMaxCredit').value = user.maxcredit ?? '';
                document.getElementById('userMaxDisc').value = user.maxdisc ?? '';
                document.getElementById('userMaxAdj').value = user.maxadjwgtbc ?? '';
                document.getElementById('userMinVA').value = user.minvaperc ?? '';
                document.getElementById('userMaxDiscPerc').value = user.maxdiscperc ?? '';
                document.getElementById('userMenuItems').value = (data.menuitems || []).join("\n");
                modal.classList.remove('hidden');
                modal.classList.add('flex');
            })
            .catch(err => alert(err.message));
    } else {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    }
}

function closeUserModal() {
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    editingCode = null;
}

function renderUsers(users) {
    if (!users.length) {
        tableBody.innerHTML = '<tr><td colspan="3" class="text-center text-gray-500 py-6">No users found.</td></tr>';
        return;
    }
    tableBody.innerHTML = users.map(user => `
        <tr>
            <td>${user.code}</td>
            <td>${user.name || ''}</td>
            <td class="text-right">
                <button class="btn btn-sm btn-primary" onclick="openUserModal('${user.code}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
            </td>
        </tr>
    `).join('');
}

function loadUsers() {
    tableBody.innerHTML = '<tr><td colspan="3" class="text-center text-gray-500 py-6">Loading users...</td></tr>';
    fetch(apiUrl)
        .then(res => res.json())
        .then(data => renderUsers(data.users || []))
        .catch(() => tableBody.innerHTML = '<tr><td colspan="3" class="text-center text-red-500 py-6">Failed to load users.</td></tr>');
}

form.addEventListener('submit', function (e) {
    e.preventDefault();
    const payload = {
        action: editingCode ? 'update' : 'create',
        user: {
            code: document.getElementById('userCode').value.trim(),
            name: document.getElementById('userName').value.trim(),
            psw: document.getElementById('userPassword').value,
            maxcredit: document.getElementById('userMaxCredit').value,
            maxdisc: document.getElementById('userMaxDisc').value,
            maxadjwgtbc: document.getElementById('userMaxAdj').value,
            minvaperc: document.getElementById('userMinVA').value,
            maxdiscperc: document.getElementById('userMaxDiscPerc').value
        },
        menuitems: document.getElementById('userMenuItems').value
            .split(/\r?\n/)
            .map(item => item.trim())
            .filter(item => item !== '')
    };

    fetch(apiUrl, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify(payload)
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) throw new Error(data.error);
        closeUserModal();
        loadUsers();
    })
    .catch(err => alert(err.message));
});

function deleteUser() {
    if (!editingCode || !confirm('Delete this user?')) return;

    fetch(apiUrl, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ action: 'delete', user: { code: editingCode } })
    })
    .then(res => res.json())
    .then(data => {
        if (data.error) throw new Error(data.error);
        closeUserModal();
        loadUsers();
    })
    .catch(err => alert(err.message));
}

document.addEventListener('DOMContentLoaded', loadUsers);
</script>
