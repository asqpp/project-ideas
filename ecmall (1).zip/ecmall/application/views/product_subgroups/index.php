<?php card_start('Product Subgroups', true); ?>

<div class="flex justify-between items-center mb-6">
    <form method="get" action="<?php echo base_url('product_subgroups'); ?>" class="flex gap-2">
        <input type="text"
               name="search"
               value="<?php echo htmlspecialchars($search); ?>"
               placeholder="Search subgroups..."
               class="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary-500">
        <button type="submit" class="btn btn-secondary">
            <i class="fas fa-search"></i> Search
        </button>
        <?php if ($search): ?>
            <a href="<?php echo base_url('product_subgroups'); ?>" class="btn btn-outline">
                <i class="fas fa-times"></i> Clear
            </a>
        <?php endif; ?>
    </form>

    <a href="<?php echo base_url('product_subgroups/add'); ?>" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add Subgroup
    </a>
</div>

<div class="overflow-x-auto">
    <?php table_start(['#', 'Code', 'Subgroup', 'Parent Group', 'Products', 'Status', 'Actions']); ?>
        <?php if (empty($subgroups)): ?>
            <tr>
                <td colspan="6" class="text-center py-8 text-gray-500">
                    <i class="fas fa-diagram-project text-4xl mb-2"></i>
                    <p>No subgroups defined.</p>
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($subgroups as $subgroup): ?>
                <?php
                $this->db->where('subgroup_id', $subgroup->id);
                $product_count = $this->db->count_all_results('product_information');
                ?>
                <tr>
                    <td><?php echo $subgroup->id; ?></td>
                    <td><code class="bg-gray-100 px-2 py-1 rounded"><?php echo htmlspecialchars($subgroup->subgroup_code); ?></code></td>
                    <td><strong><?php echo htmlspecialchars($subgroup->subgroup_name); ?></strong></td>
                    <td><?php echo htmlspecialchars($subgroup->group_name ?? 'N/A'); ?></td>
                    <td>
                        <?php if ($product_count > 0): ?>
                            <span class="badge badge-info"><?php echo $product_count; ?> products</span>
                        <?php else: ?>
                            <span class="text-gray-500">No products</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $subgroup->status ? status_badge('active', 'Active') : status_badge('inactive', 'Inactive'); ?>
                    </td>
                    <td>
                        <div class="flex gap-2">
                            <a href="<?php echo base_url('product_subgroups/edit/' . $subgroup->id); ?>" class="btn btn-sm btn-primary">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button class="btn btn-sm btn-danger"
                                    onclick="confirmDelete(<?php echo $subgroup->id; ?>, '<?php echo addslashes($subgroup->subgroup_name); ?>', <?php echo $product_count; ?>)">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    <?php table_end(); ?>
</div>

<?php if ($pagination->total_pages > 1): ?>
    <div class="mt-4">
        <?php echo render_pagination($pagination, 'product_subgroups'); ?>
    </div>
<?php endif; ?>

<?php card_end(); ?>

<script>
function confirmDelete(id, name, products) {
    if (products > 0) {
        Swal.fire('Action blocked', 'Products depend on this subgroup.', 'error');
        return;
    }
    Swal.fire({
        title: 'Delete Subgroup?',
        text: `Remove "${name}" permanently?`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Delete',
        confirmButtonColor: '#EF4444'
    }).then(result => {
        if (result.isConfirmed) {
            window.location.href = `<?php echo base_url('product_subgroups/delete/'); ?>${id}`;
        }
    });
}
</script>
