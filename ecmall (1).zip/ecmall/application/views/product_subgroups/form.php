<?php
$is_edit = !empty($subgroup);
?>

<?php card_start($is_edit ? 'Edit Subgroup' : 'Add Subgroup'); ?>

<form method="post" class="space-y-4">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="form-label">Subgroup Name</label>
            <input type="text" name="subgroup_name" class="form-input" value="<?php echo set_value('subgroup_name', $subgroup->subgroup_name ?? ''); ?>" required>
        </div>
        <div>
            <label class="form-label">Subgroup Code</label>
            <input type="text" name="subgroup_code" class="form-input uppercase" value="<?php echo set_value('subgroup_code', $subgroup->subgroup_code ?? ''); ?>" required>
        </div>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
            <label class="form-label">Parent Group</label>
            <select name="group_id" class="form-select" required>
                <option value="">Select group</option>
                <?php foreach ($groups as $group): ?>
                    <option value="<?php echo $group->id; ?>" <?php echo set_select('group_id', $group->id, ($subgroup->group_id ?? null) == $group->id); ?>>
                        <?php echo htmlspecialchars($group->group_name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="flex items-center gap-2">
            <label class="form-label mb-0">Active</label>
            <label class="switch">
                <input type="checkbox" name="status" value="1" <?php echo set_checkbox('status', '1', ($subgroup->status ?? 1) == 1); ?>>
                <span class="slider"></span>
            </label>
        </div>
    </div>

    <div>
        <label class="form-label">Description</label>
        <textarea name="description" rows="4" class="form-input"><?php echo set_value('description', $subgroup->description ?? ''); ?></textarea>
    </div>

    <div class="flex justify-end gap-2 pt-4 border-t">
        <a href="<?php echo base_url('product_subgroups'); ?>" class="btn btn-outline">Cancel</a>
        <button type="submit" class="btn btn-primary"><?php echo $is_edit ? 'Update' : 'Save'; ?></button>
    </div>
</form>

<?php card_end(); ?>
