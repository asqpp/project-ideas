<!DOCTYPE html>
<html lang="en" x-data="{ darkMode: $persist(false) }" :class="{ 'dark': darkMode }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo isset($page_title) ? $page_title . ' - ' : ''; ?>Insurance ERP</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo base_url('assets/images/favicon.ico'); ?>">

    <!-- Tailwind CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/output.css'); ?>">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <!-- AOS CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">

    <!-- Toastify CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/toastify-js@1.12.0/src/toastify.min.css">

    <!-- Additional CSS -->
    <?php if(isset($additional_css)): ?>
        <?php foreach($additional_css as $css): ?>
            <link rel="stylesheet" href="<?php echo $css; ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body class="bg-gray-50 antialiased" x-data="{ sidebarOpen: window.innerWidth >= 1024 }">

    <!-- Page Container -->
    <div class="flex h-screen overflow-hidden">

        <!-- Sidebar -->
        <aside
            class="bg-gray-900 text-white w-64 flex-shrink-0 overflow-y-auto transition-all duration-300 fixed lg:static z-40"
            :class="sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'"
            x-show="sidebarOpen"
            @click.away="if(window.innerWidth < 1024) sidebarOpen = false"
        >
            <!-- Logo -->
            <div class="p-6 border-b border-gray-800">
                <h1 class="text-2xl font-bold bg-gradient-to-r from-primary-400 to-primary-600 bg-clip-text text-transparent">
                    <i class="fas fa-shield-alt"></i> Insurance ERP
                </h1>
                <p class="text-sm text-gray-400 mt-1">NA-FIX Solutions</p>
            </div>

            <!-- Navigation -->
            <?php
            $segment1 = $this->uri->segment(1);
            $segment2 = $this->uri->segment(2);

            $masters_controllers = ['clients', 'products', 'accounts'];
            $masters_open = in_array($segment1, $masters_controllers);
            $current_client_type = $this->input->get('type') ?? 'customer';

            $transaction_controllers = ['sales', 'quotations', 'purchases', 'receipts', 'payments', 'journals'];
            $transactions_open = in_array($segment1, $transaction_controllers);

            $accounting_reports = ['general_ledger', 'day_book', 'cash_book', 'bank_book', 'trial_balance', 'balance_sheet', 'accounts_receivable', 'accounts_payable'];
            $accounting_open = in_array($segment1, ['accounts', 'receipts', 'payments', 'accounting', 'journals']) ||
                ($segment1 === 'reports' && in_array($segment2, $accounting_reports));

            $insurance_open = ($segment1 === 'insurance');
            $hr_open = ($segment1 === 'hr');
            $reports_open = ($segment1 === 'reports');
            $settings_open = in_array($segment1, ['settings', 'user_access', 'doc_numbers']);
            ?>
            <nav class="p-4 space-y-1">
                <!-- Dashboard -->
                <a href="<?php echo base_url('dashboard'); ?>" class="sidebar-link <?php echo $this->uri->segment(1) == 'dashboard' ? 'sidebar-link-active' : ''; ?>">
                    <i class="fas fa-home w-5"></i>
                    <span>Dashboard</span>
                </a>

                <!-- Masters -->
                <div x-data="{ open: <?php echo $masters_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-database w-5"></i>
                            <span>Masters</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-1">
                        <a href="<?php echo base_url('clients?type=customer'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'clients' && $current_client_type == 'customer') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-users w-4"></i> Customers
                        </a>
                        <a href="<?php echo base_url('clients?type=supplier'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'clients' && $current_client_type == 'supplier') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-truck w-4"></i> Suppliers
                        </a>
                        <a href="<?php echo base_url('clients?type=staff'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'clients' && $current_client_type == 'staff') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-id-card w-4"></i> Staff
                        </a>
                        <a href="<?php echo base_url('clients?type=agent'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'clients' && $current_client_type == 'agent') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-user-tie w-4"></i> Agents
                        </a>
                        <a href="<?php echo base_url('clients?type=broker'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'clients' && $current_client_type == 'broker') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-handshake w-4"></i> Brokers
                        </a>
                        <a href="<?php echo base_url('products'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'products' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-box w-4"></i> Product Management
                        </a>
                        <a href="<?php echo base_url('product_groups'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'product_groups' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-layer-group w-4"></i> Product Groups
                        </a>
                        <a href="<?php echo base_url('product_subgroups'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'product_subgroups' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-diagram-project w-4"></i> Product Subgroups
                        </a>
                        <a href="<?php echo base_url('accounts'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'accounts' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-chart-pie w-4"></i> Account Masters
                        </a>
                    </div>
                </div>

                <!-- Insurance -->
                <div x-data="{ open: <?php echo $insurance_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-shield-halved w-5"></i>
                            <span>Insurance</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-1">
                        <a href="<?php echo base_url('insurance/policy_management'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'policy_management') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-file-shield w-4"></i> Policy Management
                        </a>
                        <a href="<?php echo base_url('insurance/claims_management'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'claims_management') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-briefcase-medical w-4"></i> Claims Management
                        </a>
                        <a href="<?php echo base_url('insurance/underwriting'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'underwriting') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-scale-balanced w-4"></i> Underwriting
                        </a>
                        <a href="<?php echo base_url('insurance/premium_collection'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'premium_collection') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-sack-dollar w-4"></i> Premium Collection
                        </a>
                        <a href="<?php echo base_url('insurance/commission_processing'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'commission_processing') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-hand-holding-usd w-4"></i> Commission Processing
                        </a>
                        <a href="<?php echo base_url('insurance/renewals'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'renewals') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-rotate w-4"></i> Renewals
                        </a>
                        <a href="<?php echo base_url('insurance/endorsements'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'insurance' && $segment2 == 'endorsements') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-pen-to-square w-4"></i> Endorsements
                        </a>
                    </div>
                </div>

                <!-- Accounting -->
                <div x-data="{ open: <?php echo $accounting_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-calculator w-5"></i>
                            <span>Accounting</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-1">
                        <a href="<?php echo base_url('accounts'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'accounts' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-list-ol w-4"></i> Chart of Accounts
                        </a>
                        <a href="<?php echo base_url('accounts/add'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'accounts' && $segment2 == 'add') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-pen-nib w-4"></i> Account Details
                        </a>
                        <a href="<?php echo base_url('accounts/groups'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'accounts' && $segment2 == 'groups') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-layer-group w-4"></i> Group Details
                        </a>
                        <a href="<?php echo base_url('journals'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'journals' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-book-open w-4"></i> Journal Entries
                        </a>
                        <a href="<?php echo base_url('reports/general_ledger'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'reports' && $segment2 == 'general_ledger') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-book w-4"></i> General Ledger
                        </a>
                        <a href="<?php echo base_url('reports/day_book'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'reports' && $segment2 == 'day_book') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-calendar-day w-4"></i> Daybook
                        </a>
                        <a href="<?php echo base_url('receipts'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'receipts' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-hand-holding-dollar w-4"></i> Receipts
                        </a>
                        <a href="<?php echo base_url('payments'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'payments' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-credit-card w-4"></i> Payments
                        </a>
                        <a href="<?php echo base_url('accounting/bank_reconciliation'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'accounting' && $segment2 == 'bank_reconciliation') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-building-columns w-4"></i> Bank Reconciliation
                        </a>
                        <a href="<?php echo base_url('reports/trial_balance'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'reports' && $segment2 == 'trial_balance') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-balance-scale w-4"></i> Trial Balance
                        </a>
                        <a href="<?php echo base_url('accounts/positions'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'accounts' && $segment2 == 'positions') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-sort-amount-up w-4"></i> Account Positions
                        </a>
                        <a href="<?php echo base_url('reports/balance_sheet'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'reports' && $segment2 == 'balance_sheet') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-file-invoice-dollar w-4"></i> Balance Sheet
                        </a>
                        <a href="<?php echo base_url('accounting/credit_note'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'accounting' && $segment2 == 'credit_note') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-file-invoice w-4"></i> Credit Note
                        </a>
                        <a href="<?php echo base_url('accounting/debit_note'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'accounting' && $segment2 == 'debit_note') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-file-invoice-dollar w-4"></i> Debit Note
                        </a>
                    </div>
                </div>

                <!-- Transactions -->
                <div x-data="{ open: <?php echo $transactions_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-exchange-alt w-5"></i>
                            <span>Transactions</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-1">
                        <a href="<?php echo base_url('sales'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'sales' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-file-invoice w-4"></i> Sales Invoices
                        </a>
                        <a href="<?php echo base_url('quotations'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'quotations' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-file-alt w-4"></i> Quotations
                        </a>
                        <a href="<?php echo base_url('purchases'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'purchases' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-shopping-cart w-4"></i> Purchase Bills
                        </a>
                        <a href="<?php echo base_url('receipts'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'receipts' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-money-bill-wave w-4"></i> Receipts
                        </a>
                        <a href="<?php echo base_url('payments'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'payments' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-credit-card w-4"></i> Payments
                        </a>
                        <a href="<?php echo base_url('journals'); ?>" class="sidebar-link text-sm <?php echo $segment1 == 'journals' ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-book w-4"></i> Journal Entries
                        </a>
                    </div>
                </div>

                <!-- HR & Payroll -->
                <div x-data="{ open: <?php echo $hr_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-users-gear w-5"></i>
                            <span>HR &amp; Payroll</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-1">
                        <a href="<?php echo base_url('hr/employee_management'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'hr' && $segment2 == 'employee_management') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-id-card w-4"></i> Employee Management
                        </a>
                        <a href="<?php echo base_url('hr/attendance'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'hr' && $segment2 == 'attendance') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-user-check w-4"></i> Attendance
                        </a>
                        <a href="<?php echo base_url('hr/leave_management'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'hr' && $segment2 == 'leave_management') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-plane-departure w-4"></i> Leave Management
                        </a>
                        <a href="<?php echo base_url('hr/payroll_processing'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'hr' && $segment2 == 'payroll_processing') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-money-bill-trend-up w-4"></i> Payroll Processing
                        </a>
                        <a href="<?php echo base_url('hr/salary_structures'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'hr' && $segment2 == 'salary_structures') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-layer-group w-4"></i> Salary Structures
                        </a>
                        <a href="<?php echo base_url('hr/performance'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'hr' && $segment2 == 'performance') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-chart-simple w-4"></i> Performance
                        </a>
                    </div>
                </div>

                <!-- Reports -->
                <div x-data="{ open: <?php echo $reports_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-chart-bar w-5"></i>
                            <span>Reports</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-4">
                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">Financial Reports</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/balance_sheet'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'balance_sheet') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-scale-balanced w-4"></i> Balance Sheet
                                </a>
                                <a href="<?php echo base_url('reports/profit_loss'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'profit_loss') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-chart-pie w-4"></i> Profit &amp; Loss
                                </a>
                                <a href="<?php echo base_url('reports/cash_flow_statement'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'cash_flow_statement') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-droplet w-4"></i> Cash Flow Statement
                                </a>
                                <a href="<?php echo base_url('reports/trial_balance'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'trial_balance') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-list-check w-4"></i> Trial Balance
                                </a>
                                <a href="<?php echo base_url('reports/accounts_receivable'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'accounts_receivable') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-arrow-down w-4"></i> Accounts Receivable
                                </a>
                                <a href="<?php echo base_url('reports/accounts_payable'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'accounts_payable') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-arrow-up w-4"></i> Accounts Payable
                                </a>
                            </div>
                        </div>

                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">Books of Accounts</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/sales_book'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'sales_book') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-book-open w-4"></i> Sales Book
                                </a>
                                <a href="<?php echo base_url('reports/purchase_book'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'purchase_book') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-file-invoice-dollar w-4"></i> Purchase Book
                                </a>
                                <a href="<?php echo base_url('reports/cash_book'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'cash_book') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-wallet w-4"></i> Cash Book
                                </a>
                                <a href="<?php echo base_url('reports/bank_book'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'bank_book') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-piggy-bank w-4"></i> Bank Book
                                </a>
                                <a href="<?php echo base_url('reports/day_book'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'day_book') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-calendar-day w-4"></i> Day Book
                                </a>
                                <a href="<?php echo base_url('reports/quotation_book'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'quotation_book') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-file-signature w-4"></i> Quotation Book
                                </a>
                            </div>
                        </div>

                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">Sales Reports</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/sales_summary'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'sales_summary') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-chart-line w-4"></i> Sales Summary
                                </a>
                                <a href="<?php echo base_url('reports/customer_sales'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'customer_sales') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-users w-4"></i> Customer Wise Sales
                                </a>
                                <a href="<?php echo base_url('reports/product_sales'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'product_sales') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-boxes-stacked w-4"></i> Product Wise Sales
                                </a>
                                <a href="<?php echo base_url('reports/salesman_sales'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'salesman_sales') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-user-tie w-4"></i> Salesman Wise Sales
                                </a>
                                <a href="<?php echo base_url('reports/credit_sales_report'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'credit_sales_report') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-credit-card w-4"></i> Credit Sales Report
                                </a>
                            </div>
                        </div>

                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">Purchase Reports</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/purchase_summary'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'purchase_summary') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-clipboard-list w-4"></i> Purchase Summary
                                </a>
                                <a href="<?php echo base_url('reports/supplier_purchase'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'supplier_purchase') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-truck w-4"></i> Supplier Wise Purchase
                                </a>
                                <a href="<?php echo base_url('reports/product_purchase'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'product_purchase') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-tags w-4"></i> Product Wise Purchase
                                </a>
                            </div>
                        </div>

                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">Insurance Reports</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/policy_register'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'policy_register') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-shield-heart w-4"></i> Policy Register
                                </a>
                                <a href="<?php echo base_url('reports/claims_register'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'claims_register') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-briefcase-medical w-4"></i> Claims Register
                                </a>
                                <a href="<?php echo base_url('reports/premium_analysis'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'premium_analysis') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-layer-group w-4"></i> Premium Analysis
                                </a>
                                <a href="<?php echo base_url('reports/commission_report'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'commission_report') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-hand-holding-usd w-4"></i> Commission Report
                                </a>
                                <a href="<?php echo base_url('reports/loss_ratio_analysis'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'loss_ratio_analysis') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-percent w-4"></i> Loss Ratio Analysis
                                </a>
                                <a href="<?php echo base_url('reports/renewal_tracker'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'renewal_tracker') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-rotate w-4"></i> Renewal Tracker
                                </a>
                            </div>
                        </div>

                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">Customer Reports</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/customer_list'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'customer_list') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-address-book w-4"></i> Customer List
                                </a>
                                <a href="<?php echo base_url('reports/customer_ledger'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'customer_ledger') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-book w-4"></i> Customer Ledger
                                </a>
                                <a href="<?php echo base_url('reports/customer_ageing'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'customer_ageing') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-hourglass-half w-4"></i> Customer Ageing
                                </a>
                                <a href="<?php echo base_url('reports/outstanding_report'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'outstanding_report') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-exclamation-circle w-4"></i> Outstanding Report
                                </a>
                            </div>
                        </div>

                        <div>
                            <p class="text-[11px] uppercase tracking-wide text-gray-400 font-semibold mb-1">HR Reports</p>
                            <div class="space-y-1">
                                <a href="<?php echo base_url('reports/attendance_report'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'attendance_report') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-user-check w-4"></i> Attendance Report
                                </a>
                                <a href="<?php echo base_url('reports/leave_report'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'leave_report') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-plane-departure w-4"></i> Leave Report
                                </a>
                                <a href="<?php echo base_url('reports/payroll_report'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'payroll_report') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-money-check-alt w-4"></i> Payroll Report
                                </a>
                                <a href="<?php echo base_url('reports/salary_register'); ?>" class="sidebar-link text-sm <?php echo ($segment2 == 'salary_register') ? 'sidebar-link-active' : ''; ?>">
                                    <i class="fas fa-file-invoice w-4"></i> Salary Register
                                </a>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Settings -->
                <div x-data="{ open: <?php echo $settings_open ? 'true' : 'false'; ?> }">
                    <button @click="open = !open" class="sidebar-link w-full justify-between">
                        <div class="flex items-center gap-3">
                            <i class="fas fa-gear w-5"></i>
                            <span>Settings</span>
                        </div>
                        <i class="fas fa-chevron-down transform transition-transform" :class="open && 'rotate-180'"></i>
                    </button>
                    <div x-show="open" x-collapse class="ml-8 mt-1 space-y-1">
                        <a href="<?php echo base_url('settings'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'settings' && empty($segment2)) ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-sliders-h w-4"></i> General Settings
                        </a>
                        <a href="<?php echo base_url('settings/account_structure'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'settings' && $segment2 == 'account_structure') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-sitemap w-4"></i> Account Structure
                        </a>
                        <a href="<?php echo base_url('settings/notifications'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'settings' && $segment2 == 'notifications') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-bell w-4"></i> Notifications
                        </a>
                        <a href="<?php echo base_url('settings/client_codes'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'settings' && $segment2 == 'client_codes') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-hashtag w-4"></i> Client Codes
                        </a>
                        <a href="<?php echo base_url('user_access'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'user_access') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-users-cog w-4"></i> User Access
                        </a>
                        <a href="<?php echo base_url('doc_numbers'); ?>" class="sidebar-link text-sm <?php echo ($segment1 == 'doc_numbers') ? 'sidebar-link-active' : ''; ?>">
                            <i class="fas fa-list-ol w-4"></i> Document Numbers
                        </a>
                    </div>
                </div>
            </nav>

            <!-- User Info (Bottom) -->
            <div class="p-4 border-t border-gray-800 mt-auto">
                <div class="flex items-center gap-3 text-sm">
                    <div class="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center">
                        <i class="fas fa-user"></i>
                    </div>
                    <div class="flex-1">
                        <div class="font-medium"><?php echo $this->session->userdata('username'); ?></div>
                        <div class="text-gray-400 text-xs"><?php echo $this->session->userdata('usertype'); ?></div>
                    </div>
                </div>
            </div>
        </aside>

        <!-- Main Content Area -->
        <div class="flex-1 flex flex-col overflow-hidden">

            <!-- Top Header -->
            <header class="bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                <!-- Left: Menu Toggle & Breadcrumbs -->
                <div class="flex items-center gap-4">
                    <button @click="sidebarOpen = !sidebarOpen" class="lg:hidden text-gray-600 hover:text-gray-900">
                        <i class="fas fa-bars text-xl"></i>
                    </button>

                    <!-- Breadcrumbs -->
                    <?php if(isset($breadcrumbs) && !empty($breadcrumbs)): ?>
                    <nav class="hidden md:flex items-center gap-2 text-sm text-gray-600">
                        <a href="<?php echo base_url('dashboard'); ?>" class="hover:text-primary-600 transition-colors">
                            <i class="fas fa-home"></i>
                        </a>
                        <?php foreach($breadcrumbs as $crumb): ?>
                            <i class="fas fa-chevron-right text-xs text-gray-400"></i>
                            <?php if(isset($crumb['url'])): ?>
                                <a href="<?php echo $crumb['url']; ?>" class="hover:text-primary-600 transition-colors">
                                    <?php echo $crumb['title']; ?>
                                </a>
                            <?php else: ?>
                                <span class="text-gray-900"><?php echo $crumb['title']; ?></span>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </nav>
                    <?php endif; ?>
                </div>

                <!-- Right: Search & User Menu -->
                <div class="flex items-center gap-4">
                    <!-- Search -->
                    <div class="relative hidden lg:block">
                        <input
                            type="search"
                            placeholder="Search..."
                            class="w-64 pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:border-primary-500 focus:ring focus:ring-primary-200 focus:ring-opacity-50"
                        >
                        <i class="fas fa-search absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"></i>
                    </div>

                    <!-- Notifications -->
                    <button class="relative text-gray-600 hover:text-gray-900 transition-colors">
                        <i class="fas fa-bell text-xl"></i>
                        <span class="absolute -top-1 -right-1 w-5 h-5 bg-danger-500 text-white text-xs rounded-full flex items-center justify-center">3</span>
                    </button>

                    <!-- User Dropdown -->
                    <div x-data="{ open: false }" class="relative">
                        <button @click="open = !open" class="flex items-center gap-2 hover:bg-gray-100 rounded-lg px-3 py-2 transition-colors">
                            <div class="w-8 h-8 rounded-full bg-primary-600 text-white flex items-center justify-center">
                                <?php echo strtoupper(substr($this->session->userdata('username'), 0, 1)); ?>
                            </div>
                            <i class="fas fa-chevron-down text-sm text-gray-600"></i>
                        </button>

                        <div
                            x-show="open"
                            @click.away="open = false"
                            x-transition
                            class="dropdown"
                        >
                            <a href="<?php echo base_url('profile'); ?>" class="dropdown-item">
                                <i class="fas fa-user"></i> My Profile
                            </a>
                            <a href="<?php echo base_url('settings'); ?>" class="dropdown-item">
                                <i class="fas fa-cog"></i> Settings
                            </a>
                            <hr class="my-1">
                            <a href="<?php echo base_url('logout'); ?>" class="dropdown-item text-danger-600">
                                <i class="fas fa-sign-out-alt"></i> Logout
                            </a>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Content -->
            <main class="flex-1 overflow-y-auto bg-gray-50 p-6">
                <?php
                // Display flash messages
                if($this->session->flashdata('success')):
                ?>
                    <div class="alert alert-success alert-auto-dismiss mb-6" data-aos="fade-down">
                        <i class="fas fa-check-circle"></i>
                        <div>
                            <strong>Success!</strong>
                            <p><?php echo $this->session->flashdata('success'); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php
                if($this->session->flashdata('error')):
                ?>
                    <div class="alert alert-danger alert-auto-dismiss mb-6" data-aos="fade-down">
                        <i class="fas fa-exclamation-circle"></i>
                        <div>
                            <strong>Error!</strong>
                            <p><?php echo $this->session->flashdata('error'); ?></p>
                        </div>
                    </div>
                <?php endif; ?>

                <?php
                // Load main content
                if(isset($main_content)) {
                    $this->load->view($main_content);
                } else {
                    echo '<div class="card"><div class="card-body">No content specified.</div></div>';
                }
                ?>
            </main>

            <!-- Footer -->
            <footer class="bg-white border-t border-gray-200 px-6 py-4 text-sm text-gray-600">
                <div class="flex items-center justify-between">
                    <div>
                        &copy; <?php echo date('Y'); ?> NA-FIX ERP Solutions. All rights reserved.
                    </div>
                    <div class="flex items-center gap-4">
                        <span>Version 2.0.0</span>
                        <a href="#" class="hover:text-primary-600 transition-colors">Documentation</a>
                        <a href="#" class="hover:text-primary-600 transition-colors">Support</a>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Mobile Overlay -->
    <div
        x-show="sidebarOpen && window.innerWidth < 1024"
        @click="sidebarOpen = false"
        class="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
        x-transition:enter="transition-opacity ease-linear duration-300"
        x-transition:enter-start="opacity-0"
        x-transition:enter-end="opacity-100"
        x-transition:leave="transition-opacity ease-linear duration-300"
        x-transition:leave-start="opacity-100"
        x-transition:leave-end="opacity-0"
    ></div>

    <!-- Scripts -->
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/collapse@3.x.x/dist/cdn.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/@alpinejs/persist@3.x.x/dist/cdn.min.js"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.13.5/dist/cdn.min.js"></script>

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>

    <!-- AOS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>

    <!-- GSAP -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.12.5/gsap.min.js"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Toastify -->
    <script src="https://cdn.jsdelivr.net/npm/toastify-js@1.12.0/src/toastify.min.js"></script>

    <!-- Main App JS -->
    <script src="<?php echo base_url('assets/js/app.js'); ?>"></script>

    <!-- Additional JS -->
    <?php if(isset($additional_js)): ?>
        <?php foreach($additional_js as $js): ?>
            <script src="<?php echo $js; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
