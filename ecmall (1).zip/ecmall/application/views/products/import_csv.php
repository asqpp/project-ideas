<?php card_start('Import Products from CSV'); ?>

<div class="space-y-4">
    <p class="text-gray-600">
        Upload a CSV file containing the following headers: <code>product_code, product_name, product_model, category_code, group_code, subgroup_code, unit_id, default_qty, price, supplier_price, quantity, tax_percent, taxable, no_discount, status, product_details</code>.
        The importer will create new products or update existing ones based on the product code.
    </p>

    <form method="post" enctype="multipart/form-data" class="space-y-4">
        <div>
            <label class="form-label">CSV File</label>
            <input type="file" name="csv_file" accept=".csv" class="form-input" required>
        </div>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-file-import"></i> Import CSV
        </button>
    </form>

    <div class="bg-gray-50 border border-gray-200 rounded-lg p-4 text-sm">
        <p class="font-semibold mb-2">Sample Row</p>
        <pre class="bg-white border border-gray-200 p-3 rounded text-xs overflow-auto">PROD-00010,Travel Shield,TS-2024,TRAVEL,TRAVEL-CORE,TRAVEL-FAMILY,1,1,250.00,150.00,100,10,5,1,0,1,Travel package for families</pre>
    </div>
</div>

<?php card_end(); ?>
